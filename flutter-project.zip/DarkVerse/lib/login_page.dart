import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'video_splash_page.dart';
import 'package:flutter/services.dart';

const String baseUrl = "http://nodeminzxzephyrine.sistems.my.id:2196";

// ─── PALETTE ────────────────────────────────────────────────
// 🔥 DIROMAK MENJADI MERAH ORANGE PEKAT 🔥
class _C {
  static const bg      = Color(0xFF000000);
  static const surface = Color(0xFF080808);
  static const card    = Color(0xFF0C0C0C);
  
  // 🔥 PRIMARY: RED ORANGE PEKAT
  static const red     = Color(0xFFFF3D00);  // ORANGE PEKAT
  static const redDark = Color(0xFFBF360C); // ORANGE TUA
  static const redLight = Color(0xFFFF6D00); // ORANGE TERANG
  static const orange  = Color(0xFFFF6D00);
  static const orangeDark = Color(0xFFE65100);
  
  static const line    = Color(0xFF1A1A1A);
  static const muted   = Color(0xFF6D6D6D);
  static const dim     = Color(0xFF2D2D2D);
  static const white   = Color(0xFFFFFFFF);
  static const gold    = Color(0xFFFFD700);
  static const green   = Color(0xFF00E676);
  static const purple  = Color(0xFF9C27B0);
  static const pink    = Color(0xFFFF1744);
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage>
    with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePass = true;
  String? androidId;

  late AnimationController _entryCtrl;
  late AnimationController _orbitCtrl;
  late AnimationController _pulseCtrl;

  late Animation<double> _logoFade;
  late Animation<double> _logoScale;
  late Animation<double> _formFade;
  late Animation<Offset> _formSlide;
  late Animation<double> _orbit;
  late Animation<double> _pulse;

  // ============================================================
  // 🔥 HARGA LIST (UPDATED)
  // ============================================================
  final List<Map<String, dynamic>> _priceList = [
    {'role': 'MEMBER', 'price': '25K', 'priceFull': '25.000', 'color': _C.white},
    {'role': 'RESELLER', 'price': '45K', 'priceFull': '45.000', 'color': _C.gold},
    {'role': 'ADMIN', 'price': '60K', 'priceFull': '60.000', 'color': _C.orange},
    {'role': 'PARTNER', 'price': '75K', 'priceFull': '75.000', 'color': _C.purple},
    {'role': 'MODERATOR', 'price': '90K', 'priceFull': '90.000', 'color': _C.green},
    {'role': 'VIP', 'price': '115K', 'priceFull': '115.000', 'color': const Color(0xFF9C27B0)},
    {'role': 'OWNER', 'price': '150K', 'priceFull': '150.000', 'color': _C.orangeDark},
    {'role': 'HIGH OWNER', 'price': '200K', 'priceFull': '200.000', 'color': _C.pink},
  ];

  final String qrisImageUrl = "https://files.catbox.moe/ygdun9.jpg"; // GANTI DENGAN LINK QRIS LU

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _initAutoLogin();
  }

  void _setupAnimations() {
    _entryCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1400),
    )..forward();

    _orbitCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 10),
    )..repeat();

    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2200),
    )..repeat(reverse: true);

    _logoFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.5, curve: Curves.easeOut),
      ),
    );
    _logoScale = Tween<double>(begin: 0.88, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.0, 0.6, curve: Curves.easeOutCubic),
      ),
    );
    _formFade = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(
        parent: _entryCtrl,
        curve: const Interval(0.35, 0.85, curve: Curves.easeOut),
      ),
    );
    _formSlide = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _entryCtrl,
      curve: const Interval(0.3, 0.9, curve: Curves.easeOutCubic),
    ));
    _orbit = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _orbitCtrl, curve: Curves.linear),
    );
    _pulse = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );
  }

  Future<void> _initAutoLogin() async {
    androidId = await _getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final u = prefs.getString("username");
    final p = prefs.getString("password");
    final k = prefs.getString("key");

    if (u != null && p != null && k != null) {
      try {
        final res = await http.get(Uri.parse(
            "http://nodeminzxzephyrine.sistems.my.id:2196/myInfo?username=$u&password=$p&androidId=$androidId&key=$k"));
        final data = jsonDecode(res.body);
        if (data['valid'] == true) _goToSplash(_buildArgs(data, u, p));
      } catch (_) {}
    }
  }

  Future<String> _getAndroidId() async {
    final android = await DeviceInfoPlugin().androidInfo;
    return android.id ?? "unknown_device";
  }

  Map<String, dynamic> _buildArgs(dynamic data, String u, String p) => {
        "username": u,
        "password": p,
        "role": data['role'],
        "key": data['key'],
        "expiredDate": data['expiredDate'],
        "listBug": (data['listBug'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
        "listDoos": (data['listDDoS'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
        "news": (data['news'] as List? ?? [])
            .map((e) => Map<String, dynamic>.from(e as Map))
            .toList(),
      };

  void _goToSplash(Map<String, dynamic> args) {
    if (!mounted) return;
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => VideoSplashPage(dashboardArgs: args)));
  }

  Future<void> _login() async {
    if (!_formKey.currentState!.validate()) return;
    final u = userController.text.trim();
    final p = passController.text.trim();
    setState(() => isLoading = true);

    try {
      final res = await http.post(
        Uri.parse("http://nodeminzxzephyrine.sistems.my.id:2196/validate"),
        body: {"username": u, "password": p, "androidId": androidId ?? "unknown"},
      );
      final data = jsonDecode(res.body);

      if (data['expired'] == true) {
        _showAlert("Access Expired",
            "Masa akses Anda telah habis.\nSilakan perpanjang akses.",
            showContact: true);
      } else if (data['valid'] != true) {
        final msg = (data['message'] ?? "").toLowerCase();
        _showAlert(
          "Login Gagal",
          msg.contains("perangkat") || msg.contains("device")
              ? "Akun ini sedang login di perangkat lain."
              : "Username atau password salah.",
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", u);
        prefs.setString("password", p);
        prefs.setString("key", data['key']);
        _goToSplash(_buildArgs(data, u, p));
      }
    } catch (_) {
      _showAlert("Connection Error", "Gagal terhubung ke server.");
    }
    if (mounted) setState(() => isLoading = false);
  }

  void _showAlert(String title, String message, {bool showContact = false}) {
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.red.withValues(alpha: 0.2)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: _C.red.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.warning_amber_rounded,
                    color: _C.red, size: 26),
              ),
              const SizedBox(height: 16),
              Text(title,
                  style: const TextStyle(
                    color: _C.red,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 14,
                    letterSpacing: 1,
                  )),
              const SizedBox(height: 10),
              Text(message,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: _C.muted,
                    fontSize: 13,
                    height: 1.6,
                    fontFamily: 'ShareTechMono',
                  )),
              const SizedBox(height: 22),
              Row(
                children: [
                  if (showContact) ...[
                    Expanded(
                      child: _DialogBtn(
                        label: "CONTACT",
                        onTap: () => launchUrl(
                          Uri.parse("https://t.me/Fahri_Reals01"),
                          mode: LaunchMode.externalApplication,
                        ),
                        isPrimary: false,
                      ),
                    ),
                    const SizedBox(width: 10),
                  ],
                  Expanded(
                    child: _DialogBtn(
                      label: "TUTUP",
                      onTap: () => Navigator.pop(context),
                      isPrimary: true,
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // 🔥 SHOW PRICE LIST
  // ============================================================
  void _showPriceList() {
    HapticFeedback.mediumImpact();
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => _PriceListSheet(
        priceList: _priceList,
        qrisImageUrl: qrisImageUrl,
      ),
    );
  }

  @override
  void dispose() {
    _entryCtrl.dispose();
    _orbitCtrl.dispose();
    _pulseCtrl.dispose();
    userController.dispose();
    passController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;

    return Scaffold(
      backgroundColor: _C.bg,
      resizeToAvoidBottomInset: true,
      body: Stack(
        children: [
          // ── Ambient glow background ────────────────────
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Positioned(
              top: -100,
              left: -60,
              child: Container(
                width: 320,
                height: 320,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      _C.red.withValues(alpha: _pulse.value * 0.08),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Positioned(
              bottom: -80,
              right: -60,
              child: Container(
                width: 260,
                height: 260,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      _C.red.withValues(alpha: (_pulse.value * 0.05)),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ),

          // ── Rotating orbit ring (background) ──────────
          AnimatedBuilder(
            animation: _orbit,
            builder: (_, __) => Positioned(
              top: h * 0.06,
              left: MediaQuery.of(context).size.width * 0.5 - 140,
              child: Transform.rotate(
                angle: _orbit.value * 2 * math.pi,
                child: Container(
                  width: 280,
                  height: 280,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: SweepGradient(
                      colors: [
                        Colors.transparent,
                        _C.red.withValues(alpha: 0.05),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),

          // ── Main content ───────────────────────────────
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  children: [
                    SizedBox(height: h * 0.04),

                    // ── Logo ──────────────────────────
                    FadeTransition(
                      opacity: _logoFade,
                      child: ScaleTransition(
                        scale: _logoScale,
                        child: Column(
                          children: [
                            // Logo image
                            SizedBox(
                              width: 110,
                              height: 110,
                              child: Stack(
                                alignment: Alignment.center,
                                children: [
                                  // Glow ring behind logo
                                  AnimatedBuilder(
                                    animation: _pulse,
                                    builder: (_, __) => Container(
                                      width: 110,
                                      height: 110,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        boxShadow: [
                                          BoxShadow(
                                            color: _C.red.withValues(
                                                alpha: _pulse.value * 0.25),
                                            blurRadius: 30,
                                            spreadRadius: 0,
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  ClipOval(
                                    child: Image.asset(
                                      'assets/images/logo.png',
                                      width: 100,
                                      height: 100,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ],
                              ),
                            ),

                            const SizedBox(height: 20),

                            // App name
                            const Text(
                              "DarkCrasher",
                              style: TextStyle(
                                color: _C.white,
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 28,
                                letterSpacing: 6,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              "A P P S   S Y S T E M",
                              style: TextStyle(
                                color: _C.red.withValues(alpha: 0.7),
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                                letterSpacing: 4,
                              ),
                            ),
                            const SizedBox(height: 18),

                            // Thin red divider
                            Container(
                              width: 40,
                              height: 1.5,
                              decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [
                                  Colors.transparent,
                                  _C.red,
                                  Colors.transparent,
                                ]),
                                borderRadius: BorderRadius.circular(1),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    SizedBox(height: h * 0.04),

                    // ── Form ──────────────────────────
                    FadeTransition(
                      opacity: _formFade,
                      child: SlideTransition(
                        position: _formSlide,
                        child: Form(
                          key: _formKey,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // Section label
                              Row(
                                children: [
                                  Container(
                                    width: 3,
                                    height: 12,
                                    decoration: BoxDecoration(
                                      color: _C.red,
                                      borderRadius: BorderRadius.circular(2),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Text(
                                    "SIGN IN",
                                    style: TextStyle(
                                      color: _C.muted,
                                      fontFamily: 'ShareTechMono',
                                      fontSize: 10,
                                      letterSpacing: 3,
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 20),

                              // Username field
                              _ModernField(
                                controller: userController,
                                hint: "Username",
                                icon: Icons.person_outline_rounded,
                                validator: (v) => (v == null || v.trim().isEmpty)
                                    ? "Username wajib diisi"
                                    : null,
                              ),

                              const SizedBox(height: 12),

                              // Password field
                              _ModernField(
                                controller: passController,
                                hint: "Password",
                                icon: Icons.lock_outline_rounded,
                                obscure: _obscurePass,
                                validator: (v) => (v == null || v.trim().isEmpty)
                                    ? "Password wajib diisi"
                                    : null,
                                suffix: GestureDetector(
                                  onTap: () => setState(
                                      () => _obscurePass = !_obscurePass),
                                  child: Icon(
                                    _obscurePass
                                        ? Icons.visibility_off_outlined
                                        : Icons.visibility_outlined,
                                    color: _C.muted,
                                    size: 18,
                                  ),
                                ),
                              ),

                              const SizedBox(height: 28),

                              // Login button
                              _LoginButton(
                                  isLoading: isLoading, onTap: _login),

                              const SizedBox(height: 14),

                              // ============================================================
                              // 🔥 BUTTON CLIK HARGA
                              // ============================================================
                              _buildPriceButton(),

                              const SizedBox(height: 14),

                              // Purchase link
                              Center(
                                child: GestureDetector(
                                  onTap: () => launchUrl(
                                    Uri.parse("https://t.me/ikyfamouss"),
                                    mode: LaunchMode.externalApplication,
                                  ),
                                  child: Row(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Text(
                                        "Belum punya akses? ",
                                        style: TextStyle(
                                          color: _C.muted,
                                          fontSize: 12,
                                          fontFamily: 'ShareTechMono',
                                        ),
                                      ),
                                      Text(
                                        "Beli Disini",
                                        style: TextStyle(
                                          color: _C.red,
                                          fontSize: 12,
                                          fontFamily: 'ShareTechMono',
                                          fontWeight: FontWeight.w700,
                                          decoration: TextDecoration.underline,
                                          decorationColor: _C.red,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    SizedBox(height: h * 0.06),

                    // Footer
                    FadeTransition(
                      opacity: _formFade,
                      child: Column(
                        children: [
                          Container(
                            height: 1,
                            decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [
                                Colors.transparent,
                                _C.line,
                                Colors.transparent,
                              ]),
                            ),
                          ),
                          const SizedBox(height: 14),
                          Text(
                            "By continuing you agree to our Terms of Service",
                            style: TextStyle(
                              color: _C.muted.withValues(alpha: 0.5),
                              fontSize: 10,
                              letterSpacing: 0.5,
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 6),
                          Text(
                            "v 7.5",
                            style: TextStyle(
                              color: _C.red.withValues(alpha: 0.3),
                              fontSize: 10,
                              fontFamily: 'ShareTechMono',
                              letterSpacing: 3,
                            ),
                          ),
                        ],
                      ),
                    ),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // 🔥 WIDGET BUTTON CLIK HARGA
  // ============================================================
  Widget _buildPriceButton() {
    return GestureDetector(
      onTap: _showPriceList,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        height: 48,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _C.surface,
          border: Border.all(
            color: _C.gold.withValues(alpha: 0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: _C.gold.withValues(alpha: 0.05),
              blurRadius: 20,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.price_change_rounded, color: _C.gold, size: 18),
              const SizedBox(width: 10),
              Text(
                "CLIK HARGA",
                style: TextStyle(
                  color: _C.gold,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 13,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.gold.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _C.gold.withValues(alpha: 0.2)),
                ),
                child: Text(
                  "HARGA",
                  style: TextStyle(
                    color: _C.gold,
                    fontFamily: 'ShareTechMono',
                    fontSize: 8,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// 🔥 PRICE LIST SHEET (DENGAN QRIS & TIMER)
// ════════════════════════════════════════════════════════════
class _PriceListSheet extends StatefulWidget {
  final List<Map<String, dynamic>> priceList;
  final String qrisImageUrl;

  const _PriceListSheet({
    required this.priceList,
    required this.qrisImageUrl,
  });

  @override
  State<_PriceListSheet> createState() => _PriceListSheetState();
}

class _PriceListSheetState extends State<_PriceListSheet>
    with SingleTickerProviderStateMixin {
  Map<String, dynamic>? _selectedPrice;
  bool _showQris = false;
  bool _showBuyAccess = false;
  late AnimationController _animCtrl;
  late Animation<double> _fadeAnim;

  // ============================================================
  // 🔥 TIMER 8 MENIT
  // ============================================================
  static const int _totalSeconds = 480; // 8 menit
  int _remainingSeconds = _totalSeconds;
  Timer? _timer;
  bool _isTimerRunning = false;

  @override
  void initState() {
    super.initState();
    _animCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeAnim = CurvedAnimation(
      parent: _animCtrl,
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _animCtrl.dispose();
    _timer?.cancel();
    super.dispose();
  }

  void _selectPrice(Map<String, dynamic> price) {
    setState(() {
      _selectedPrice = price;
      _showQris = false;
      _showBuyAccess = false;
      _remainingSeconds = _totalSeconds;
      _isTimerRunning = false;
      _timer?.cancel();
    });
    _animCtrl.reset();
    Future.delayed(const Duration(milliseconds: 300), () {
      setState(() {
        _showQris = true;
        _showBuyAccess = true;
      });
      _animCtrl.forward();
    });
  }

  void _startTimer() {
    if (_isTimerRunning) return;
    setState(() => _isTimerRunning = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _remainingSeconds--;
        if (_remainingSeconds <= 0) {
          _remainingSeconds = 0;
          _isTimerRunning = false;
          timer.cancel();
          _showExpiredDialog();
        }
      });
    });
  }

  void _showExpiredDialog() {
    showDialog(
      context: context,
      barrierColor: Colors.black.withValues(alpha: 0.85),
      builder: (_) => Dialog(
        backgroundColor: Colors.transparent,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: _C.card,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: _C.red.withValues(alpha: 0.3)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: _C.red.withValues(alpha: 0.1),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.timer_off_rounded, color: _C.red, size: 32),
              ),
              const SizedBox(height: 16),
              const Text(
                "WAKTU HABIS!",
                style: TextStyle(
                  color: _C.red,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  fontSize: 18,
                  letterSpacing: 1.5,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "Sesi pembelian telah berakhir.\nSilakan pilih role lagi.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: _C.muted,
                  fontSize: 13,
                  fontFamily: 'ShareTechMono',
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () {
                  Navigator.pop(context);
                  setState(() {
                    _showQris = false;
                    _showBuyAccess = false;
                    _selectedPrice = null;
                    _remainingSeconds = _totalSeconds;
                    _isTimerRunning = false;
                    _timer?.cancel();
                  });
                  _animCtrl.reset();
                },
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _C.red.withValues(alpha: 0.3)),
                    color: _C.red.withValues(alpha: 0.05),
                  ),
                  child: const Text(
                    "KEMBALI",
                    style: TextStyle(
                      color: _C.red,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _cancelTransaction() {
    setState(() {
      _showQris = false;
      _showBuyAccess = false;
      _selectedPrice = null;
      _remainingSeconds = _totalSeconds;
      _isTimerRunning = false;
      _timer?.cancel();
    });
    _animCtrl.reset();
  }

  void _copyMessage() {
    Clipboard.setData(
      const ClipboardData(text: "KIRIM BUKTI TRANSFER KE @ikyfamouss !!!"),
    );
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text("📋 Pesan disalin ke clipboard!"),
        backgroundColor: Color(0xFF00E676),
        duration: Duration(seconds: 2),
      ),
    );
  }

  String _formatTime(int seconds) {
    final minutes = (seconds ~/ 60).toString().padLeft(2, '0');
    final secs = (seconds % 60).toString().padLeft(2, '0');
    return "$minutes:$secs";
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.95),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        border: Border(
          top: BorderSide(color: _C.red.withValues(alpha: 0.3)),
          left: BorderSide(color: _C.red.withValues(alpha: 0.3)),
          right: BorderSide(color: _C.red.withValues(alpha: 0.3)),
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle
          Container(
            width: 36,
            height: 3,
            margin: const EdgeInsets.only(bottom: 18),
            decoration: BoxDecoration(
              color: _C.dim,
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.gold.withValues(alpha: 0.15),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: _C.gold.withValues(alpha: 0.3)),
                ),
                child: Icon(Icons.price_change_rounded, color: _C.gold, size: 22),
              ),
              const SizedBox(width: 14),
              const Text(
                "HARGA ROLE",
                style: TextStyle(
                  color: _C.gold,
                  fontFamily: 'Orbitron',
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),

          const SizedBox(height: 18),

          // Price Grid
          if (!_showQris)
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: widget.priceList.map((price) {
                final isSelected = _selectedPrice == price;
                return GestureDetector(
                  onTap: () => _selectPrice(price),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: (MediaQuery.of(context).size.width - 70) / 2,
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: isSelected
                          ? (price['color'] as Color).withValues(alpha: 0.15)
                          : _C.surface,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(
                        color: isSelected
                            ? (price['color'] as Color).withValues(alpha: 0.5)
                            : _C.line,
                        width: isSelected ? 1.5 : 1,
                      ),
                      boxShadow: isSelected
                          ? [
                              BoxShadow(
                                color: (price['color'] as Color).withValues(alpha: 0.1),
                                blurRadius: 20,
                              ),
                            ]
                          : [],
                    ),
                    child: Column(
                      children: [
                        Text(
                          price['role'],
                          style: TextStyle(
                            color: price['color'] as Color,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 14,
                            letterSpacing: 0.5,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          price['price'],
                          style: TextStyle(
                            color: _C.white,
                            fontFamily: 'ShareTechMono',
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1,
                          ),
                        ),
                        const SizedBox(height: 6),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                          decoration: BoxDecoration(
                            color: (price['color'] as Color).withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(6),
                            border: Border.all(
                              color: (price['color'] as Color).withValues(alpha: 0.2),
                            ),
                          ),
                          child: Text(
                            "Rp ${price['priceFull']}",
                            style: TextStyle(
                              color: (price['color'] as Color).withValues(alpha: 0.7),
                              fontSize: 10,
                              fontFamily: 'ShareTechMono',
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),

          // ============================================================
          // 🔥 QRIS SECTION (FULL IMAGE - TIDAK TERPOTONG)
          // ============================================================
          if (_showQris && _selectedPrice != null) ...[
            FadeTransition(
              opacity: _fadeAnim,
              child: Column(
                children: [
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: _C.surface,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: _C.gold.withValues(alpha: 0.2)),
                    ),
                    child: Column(
                      children: [
                        // Selected role badge
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                          decoration: BoxDecoration(
                            color: (_selectedPrice!['color'] as Color).withValues(alpha: 0.15),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(
                              color: (_selectedPrice!['color'] as Color).withValues(alpha: 0.3),
                            ),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text(
                                "✅ ${_selectedPrice!['role']}",
                                style: TextStyle(
                                  color: _selectedPrice!['color'] as Color,
                                  fontFamily: 'Orbitron',
                                  fontWeight: FontWeight.w900,
                                  fontSize: 14,
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                _selectedPrice!['price'],
                                style: TextStyle(
                                  color: _C.white,
                                  fontFamily: 'ShareTechMono',
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(height: 16),

                        // ============================================================
                        // 🔥 QRIS IMAGE (FULL - TIDAK TERPOTONG)
                        // ============================================================
                        Container(
                          width: double.infinity,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(16),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.3),
                                blurRadius: 20,
                              ),
                            ],
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Image.network(
                              widget.qrisImageUrl,
                              width: double.infinity,
                              fit: BoxFit.contain,
                              loadingBuilder: (context, child, progress) {
                                if (progress == null) return child;
                                return Container(
                                  height: 280,
                                  decoration: BoxDecoration(
                                    color: _C.surface,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                  child: const Center(
                                    child: CircularProgressIndicator(
                                      color: _C.gold,
                                      strokeWidth: 2,
                                    ),
                                  ),
                                );
                              },
                              errorBuilder: (_, __, ___) => Container(
                                height: 280,
                                decoration: BoxDecoration(
                                  color: _C.surface,
                                  borderRadius: BorderRadius.circular(16),
                                  border: Border.all(color: _C.red.withValues(alpha: 0.3)),
                                ),
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.qr_code_scanner, color: _C.muted, size: 50),
                                    const SizedBox(height: 8),
                                    Text(
                                      "QRIS tidak tersedia",
                                      style: TextStyle(color: _C.muted),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 16),

                        // ============================================================
                        // 🔥 TIMER + BUTTON BUY ACCESS
                        // ============================================================
                        if (_showBuyAccess) ...[
                          // Timer
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: _C.red.withValues(alpha: 0.05),
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(
                                color: _remainingSeconds > 0 
                                    ? _C.red.withValues(alpha: 0.3)
                                    : _C.red.withValues(alpha: 0.6),
                              ),
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  _remainingSeconds > 0 
                                      ? Icons.timer_rounded
                                      : Icons.timer_off_rounded,
                                  color: _remainingSeconds > 0 ? _C.red : _C.muted,
                                  size: 20,
                                ),
                                const SizedBox(width: 10),
                                Text(
                                  _remainingSeconds > 0
                                      ? "⏳ ${_formatTime(_remainingSeconds)}"
                                      : "⏰ WAKTU HABIS!",
                                  style: TextStyle(
                                    color: _remainingSeconds > 0 ? _C.red : _C.muted,
                                    fontFamily: 'Orbitron',
                                    fontWeight: FontWeight.w900,
                                    fontSize: 16,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Buttons Row
                          Row(
                            children: [
                              // BUY ACCESS Button
                              Expanded(
                                child: GestureDetector(
                                  onTap: _remainingSeconds > 0 
                                      ? () {
                                          _startTimer();
                                          _copyMessage();
                                        }
                                      : null,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      gradient: LinearGradient(
                                        colors: _remainingSeconds > 0
                                            ? [_C.gold, _C.gold.withValues(alpha: 0.7)]
                                            : [_C.muted, _C.dim],
                                        begin: Alignment.topLeft,
                                        end: Alignment.bottomRight,
                                      ),
                                      boxShadow: _remainingSeconds > 0
                                          ? [
                                              BoxShadow(
                                                color: _C.gold.withValues(alpha: 0.3),
                                                blurRadius: 20,
                                                spreadRadius: 0,
                                              ),
                                            ]
                                          : [],
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.shopping_cart_rounded,
                                          color: _remainingSeconds > 0 ? Colors.black : _C.muted,
                                          size: 18,
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          "BUY ACCESS",
                                          style: TextStyle(
                                            color: _remainingSeconds > 0 ? Colors.black : _C.muted,
                                            fontFamily: 'Orbitron',
                                            fontWeight: FontWeight.w900,
                                            fontSize: 12,
                                            letterSpacing: 1.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),

                              // BATAL Button
                              Expanded(
                                child: GestureDetector(
                                  onTap: _cancelTransaction,
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(vertical: 12),
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(12),
                                      border: Border.all(
                                        color: _C.red.withValues(alpha: 0.3),
                                      ),
                                      color: _C.red.withValues(alpha: 0.05),
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(
                                          Icons.close_rounded,
                                          color: _C.red,
                                          size: 18,
                                        ),
                                        const SizedBox(width: 8),
                                        Text(
                                          "BATAL",
                                          style: TextStyle(
                                            color: _C.red,
                                            fontFamily: 'Orbitron',
                                            fontWeight: FontWeight.w700,
                                            fontSize: 12,
                                            letterSpacing: 1.5,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],

                        const SizedBox(height: 12),

                        // Message
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: _C.red.withValues(alpha: 0.05),
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: _C.red.withValues(alpha: 0.2)),
                          ),
                          child: Row(
                            children: [
                              Icon(Icons.info_outline_rounded, color: _C.red, size: 18),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  "KIRIM BUKTI TRANSFER KE @ikyfamouss !!!",
                                  style: TextStyle(
                                    color: _C.red,
                                    fontFamily: 'Orbitron',
                                    fontSize: 11,
                                    fontWeight: FontWeight.w700,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ),
                              GestureDetector(
                                onTap: _copyMessage,
                                child: Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: _C.red.withValues(alpha: 0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: Icon(
                                    Icons.copy_rounded,
                                    color: _C.red,
                                    size: 16,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],

          const SizedBox(height: 16),

          // Footer
          Text(
            _showQris ? "Lakukan pembayaran sebelum waktu habis" : "Pilih role yang ingin dibeli",
            style: TextStyle(
              color: _C.muted.withValues(alpha: 0.5),
              fontSize: 10,
              fontFamily: 'ShareTechMono',
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: double.infinity,
              height: 44,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: _C.line),
              ),
              child: Center(
                child: Text(
                  "TUTUP",
                  style: TextStyle(
                    color: _C.muted,
                    fontFamily: 'Orbitron',
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════════
// WIDGET COMPONENTS (SAMA PERSIS)
// ════════════════════════════════════════════════════════════

class _ModernField extends StatefulWidget {
  final TextEditingController controller;
  final String hint;
  final IconData icon;
  final bool obscure;
  final Widget? suffix;
  final String? Function(String?)? validator;

  const _ModernField({
    required this.controller,
    required this.hint,
    required this.icon,
    this.obscure = false,
    this.suffix,
    this.validator,
  });

  @override
  State<_ModernField> createState() => _ModernFieldState();
}

class _ModernFieldState extends State<_ModernField> {
  bool _focused = false;

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 200),
      decoration: BoxDecoration(
        color: _C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: _focused
              ? _C.red.withValues(alpha: 0.45)
              : _C.line,
          width: _focused ? 1.5 : 1,
        ),
        boxShadow: _focused
            ? [
                BoxShadow(
                  color: _C.red.withValues(alpha: 0.08),
                  blurRadius: 20,
                  spreadRadius: 0,
                )
              ]
            : [],
      ),
      child: Focus(
        onFocusChange: (v) => setState(() => _focused = v),
        child: TextFormField(
          controller: widget.controller,
          obscureText: widget.obscure,
          style: const TextStyle(
            color: _C.white,
            fontSize: 15,
            fontFamily: 'ShareTechMono',
          ),
          cursorColor: _C.red,
          cursorWidth: 1.5,
          validator: widget.validator,
          decoration: InputDecoration(
            hintText: widget.hint,
            hintStyle: TextStyle(
              color: _C.muted.withValues(alpha: 0.6),
              fontSize: 14,
              fontFamily: 'ShareTechMono',
            ),
            prefixIcon: Padding(
              padding: const EdgeInsets.only(left: 16, right: 12),
              child: Icon(
                widget.icon,
                color: _focused ? _C.red : _C.muted,
                size: 18,
              ),
            ),
            prefixIconConstraints: const BoxConstraints(),
            suffixIcon: widget.suffix != null
                ? Padding(
                    padding: const EdgeInsets.only(right: 14),
                    child: widget.suffix,
                  )
                : null,
            suffixIconConstraints: const BoxConstraints(),
            border: InputBorder.none,
            contentPadding: const EdgeInsets.symmetric(
                horizontal: 16, vertical: 18),
            errorStyle: const TextStyle(
              color: _C.red,
              fontSize: 11,
              fontFamily: 'ShareTechMono',
            ),
          ),
        ),
      ),
    );
  }
}

// ─── Login Button ────────────────────────────────────────────
class _LoginButton extends StatefulWidget {
  final bool isLoading;
  final VoidCallback onTap;
  const _LoginButton({required this.isLoading, required this.onTap});

  @override
  State<_LoginButton> createState() => _LoginButtonState();
}

class _LoginButtonState extends State<_LoginButton> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        if (!widget.isLoading) widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 130),
        height: 56,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          gradient: LinearGradient(
            colors: widget.isLoading
                ? [_C.redDark, _C.redDark]
                : _pressed
                    ? [_C.red.withValues(alpha: 0.7), _C.redDark]
                    : [_C.red, _C.redDark],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: (widget.isLoading || _pressed)
              ? []
              : [
                  BoxShadow(
                    color: _C.red.withValues(alpha: 0.3),
                    blurRadius: 24,
                    offset: const Offset(0, 8),
                  ),
                  BoxShadow(
                    color: _C.red.withValues(alpha: 0.1),
                    blurRadius: 50,
                    spreadRadius: 5,
                  ),
                ],
        ),
        child: Center(
          child: widget.isLoading
              ? SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(
                        Colors.white.withValues(alpha: 0.8)),
                  ),
                )
              : const Text(
                  "LOGIN",
                  style: TextStyle(
                    color: _C.white,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w900,
                    fontSize: 15,
                    letterSpacing: 4,
                  ),
                ),
        ),
      ),
    );
  }
}

// ─── Dialog Button ───────────────────────────────────────────
class _DialogBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  final bool isPrimary;
  const _DialogBtn(
      {required this.label, required this.onTap, required this.isPrimary});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 44,
        decoration: BoxDecoration(
          color: isPrimary ? _C.red.withValues(alpha: 0.12) : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isPrimary
                ? _C.red.withValues(alpha: 0.35)
                : _C.line,
          ),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: isPrimary ? _C.red : _C.muted,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 11,
              letterSpacing: 1.5,
            ),
          ),
        ),
      ),
    );
  }
}