import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class QuranToolPage extends StatefulWidget {
  const QuranToolPage({super.key});

  @override
  State<QuranToolPage> createState() => _QuranToolPageState();
}

class _QuranToolPageState extends State<QuranToolPage> {
  List<dynamic> _surahs = [];
  List<dynamic> _ayahs = [];
  bool _isLoading = true;
  int? _selectedSurah;
  String _translationLang = 'id.indonesian';

  final Map<String, String> translations = {
    'id.indonesian': 'Bahasa Indonesia',
    'en.asad': 'English',
    'ms.abdullah': 'Melayu',
  };

  @override
  void initState() {
    super.initState();
    fetchSurahs();
  }

  Future<void> fetchSurahs() async {
    try {
      final response = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/surah'),
      );
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _surahs = data['data'];
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  Future<void> fetchAyahs(int surahNumber) async {
    setState(() => _isLoading = true);
    try {
      final arabic = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/surah/$surahNumber'),
      );
      final translation = await http.get(
        Uri.parse('https://api.alquran.cloud/v1/surah/$surahNumber/$_translationLang'),
      );
      
      if (arabic.statusCode == 200 && translation.statusCode == 200) {
        final arabicData = jsonDecode(arabic.body);
        final translationData = jsonDecode(translation.body);
        
        final ayahs = <Map<String, String>>[];
        for (int i = 0; i < arabicData['data']['ayahs'].length; i++) {
          ayahs.add({
            'arabic': arabicData['data']['ayahs'][i]['text'],
            'translation': translationData['data']['ayahs'][i]['text'],
            'number': (i + 1).toString(),
          });
        }
        setState(() {
          _ayahs = ayahs;
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0A0E2A),
      appBar: AppBar(
        title: const Text('📖 Al-Qur\'an'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          DropdownButton(
            value: _translationLang,
            dropdownColor: const Color(0xFF1A1E3A),
            icon: const Icon(Icons.language, color: Colors.white),
            onChanged: (String? newValue) {
              setState(() => _translationLang = newValue!);
              if (_selectedSurah != null) fetchAyahs(_selectedSurah!);
            },
            items: translations.entries.map((e) {
              return DropdownMenuItem(
                value: e.key,
                child: Text(e.value, style: const TextStyle(color: Colors.white)),
              );
            }).toList(),
          ),
          const SizedBox(width: 10),
        ],
      ),
      body: _selectedSurah == null ? _buildSurahList() : _buildAyahList(),
    );
  }

  Widget _buildSurahList() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _surahs.length,
      itemBuilder: (context, index) {
        final surah = _surahs[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 10),
          color: Colors.white.withOpacity(0.05),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
          child: ListTile(
            leading: Container(
              width: 45,
              height: 45,
              decoration: BoxDecoration(
                gradient: const LinearGradient(colors: [Colors.teal, Colors.green]),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Center(
                child: Text(
                  '${surah['number']}',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            title: Text(
              surah['name'],
              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
            ),
            subtitle: Text(
              '${surah['englishName']} • ${surah['ayahs'].length} ayat',
              style: TextStyle(color: Colors.grey[400]),
            ),
            trailing: Text(
              surah['name'],
              style: const TextStyle(color: Colors.teal, fontSize: 18),
            ),
            onTap: () {
              setState(() {
                _selectedSurah = surah['number'];
                fetchAyahs(_selectedSurah!);
              });
            },
          ),
        );
      },
    );
  }

  Widget _buildAyahList() {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(16),
          color: Colors.teal.withOpacity(0.2),
          child: Row(
            children: [
              IconButton(
                icon: const Icon(Icons.arrow_back, color: Colors.white),
                onPressed: () => setState(() => _selectedSurah = null),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  'Surah ${_selectedSurah}: ${_surahs.firstWhere((s) => s['number'] == _selectedSurah)['name']}',
                  style: const TextStyle(color: Colors.white, fontSize: 18),
                ),
              ),
            ],
          ),
        ),
        Expanded(
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: _ayahs.length,
                  itemBuilder: (context, index) {
                    final ayah = _ayahs[index];
                    return Container(
                      margin: const EdgeInsets.only(bottom: 16),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.03),
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: Colors.teal.withOpacity(0.3)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            ayah['arabic']!,
                            style: const TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontFamily: 'Amiri',
                            ),
                            textAlign: TextAlign.right,
                          ),
                          const Divider(color: Colors.grey, height: 20),
                          Row(
                            children: [
                              Container(
                                width: 30,
                                height: 30,
                                decoration: BoxDecoration(
                                  color: Colors.teal,
                                  shape: BoxShape.circle,
                                ),
                                child: Center(
                                  child: Text(
                                    ayah['number']!,
                                    style: const TextStyle(color: Colors.white, fontSize: 12),
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              Expanded(
                                child: Text(
                                  ayah['translation']!,
                                  style: TextStyle(color: Colors.grey[300]),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    );
                  },
                ),
        ),
      ],
    );
  }
}