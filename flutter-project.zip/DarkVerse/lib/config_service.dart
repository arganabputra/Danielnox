import 'dart:convert';
import 'package:http/http.dart' as http;

class ConfigService {
  static String baseUrl = "";

  static Future<void> loadConfig() async {
    final res = await http.get(
      Uri.parse(
        'https://github.com/asha18381/basepano/raw/refs/heads/main/config.json',
      ),
    );

    if (res.statusCode == 200) {
      final data = jsonDecode(res.body);
      baseUrl = data['baseUrl'];
    }
  }
}