// lib/spam_pair.dart
// OTAX SPAM PAIR - FULL FUNCTIONAL FIXED VERSION

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

// ============================================================
// KONSTAN WARNA
// ============================================================
const Color kPrimaryColor = Color(0xFF29B6F6);
const Color kBackgroundColor = Color(0xFF0A0A0A);
const Color kCardColor = Color(0xFF1A1A1A);
const Color kBlueDark = Color(0xFF0D47A1);

class SpamPairingPage extends StatefulWidget {
  final String username;
  final String role;
  final String sessionKey;

  const SpamPairingPage({
    super.key,
    required this.username,
    required this.role,
    required this.sessionKey,
  });

  @override
  State<SpamPairingPage> createState() => _SpamPairingPageState();
}

class _SpamPairingPageState extends State<SpamPairingPage> {
  // ============================================================
  // VARIABLES
  // ============================================================
  
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _delayController = TextEditingController();
  final TextEditingController _jumlahController = TextEditingController();
  
  bool _isConnected = true;
  bool _isSpamming = false;
  int _totalApi = 0;
  int _successCount = 0;
  int _failCount = 0;
  int _currentProgress = 0;
  String _statusMessage = "";
  
  static const String BASE_URL = "http://nodeminzxzephyrine.sistems.my.id:2196";
  
  List<String> _logs = [];
  final ScrollController _logScrollController = ScrollController();
  int _selectedTab = 0;
  
  @override
  void initState() {
    super.initState();
    _loadSettings();
    _checkConnection();
    _fetchTotalApi();
  }
  
  @override
  void dispose() {
    _stopSpam();
    _phoneController.dispose();
    _delayController.dispose();
    _jumlahController.dispose();
    _logScrollController.dispose();
    super.dispose();
  }
  
  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _phoneController.text = prefs.getString('spam_phone') ?? '+62';
      _delayController.text = prefs.getInt('spam_delay')?.toString() ?? '1000';
      _jumlahController.text = prefs.getInt('spam_jumlah')?.toString() ?? '2';
    });
  }
  
  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('spam_phone', _phoneController.text);
    await prefs.setInt('spam_delay', int.tryParse(_delayController.text) ?? 1000);
    await prefs.setInt('spam_jumlah', int.tryParse(_jumlahController.text) ?? 2);
  }
  
  Future<void> _checkConnection() async {
    try {
      final response = await http.get(
        Uri.parse("http://nodeminzxzephyrine.sistems.my.id:2196/api/status"),
        headers: {'x-session-key': widget.sessionKey},
      ).timeout(const Duration(seconds: 5));
      
      setState(() {
        _isConnected = response.statusCode == 200;
      });
    } catch (e) {
      setState(() {
        _isConnected = false;
      });
    }
  }
  
  Future<void> _fetchTotalApi() async {
    try {
      final response = await http.get(
        Uri.parse("http://nodeminzxzephyrine.sistems.my.id:2196/api/pairing/stats"),
        headers: {'x-session-key': widget.sessionKey},
      );
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _totalApi = data['total_api'] ?? 0;
        });
      }
    } catch (e) {
      debugPrint("Error fetching API stats: $e");
    }
  }
  
  Future<bool> _sendPairingCode(String phoneNumber) async {
    try {
      final response = await http.post(
        Uri.parse("http://nodeminzxzephyrine.sistems.my.id:2196/api/pairing/send"),
        headers: {
          'Content-Type': 'application/json',
          'x-session-key': widget.sessionKey,
        },
        body: jsonEncode({
          'phone': phoneNumber,
          'username': widget.username,
        }),
      ).timeout(const Duration(seconds: 30));
      
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['success'] == true) {
          setState(() {
            _successCount++;
          });
          _addToLog("✅ Pairing code sent to $phoneNumber");
          return true;
        } else {
          setState(() {
            _failCount++;
          });
          _addToLog("❌ Failed: ${data['message'] ?? 'Unknown error'}");
          return false;
        }
      } else {
        setState(() {
          _failCount++;
        });
        _addToLog("❌ HTTP Error: ${response.statusCode}");
        return false;
      }
    } catch (e) {
      setState(() {
        _failCount++;
      });
      _addToLog("❌ Error: $e");
      return false;
    }
  }
  
  Future<void> _startSpam() async {
    String phone = _phoneController.text.trim();
    int delay = int.tryParse(_delayController.text) ?? 1000;
    int jumlah = int.tryParse(_jumlahController.text) ?? 2;
    
    if (phone.isEmpty) {
      _showSnackbar("Masukkan nomor WhatsApp!");
      return;
    }
    
    if (!phone.startsWith('+')) {
      _showSnackbar("Format nomor harus dengan + (contoh: +6283183517744)");
      return;
    }
    
    if (jumlah > 20) {
      _showSnackbar("Maksimal 20 spam per eksekusi!");
      return;
    }
    
    if (delay < 500) {
      _showSnackbar("Delay minimal 500ms untuk menghindari ban!");
      return;
    }
    
    if (!_isConnected) {
      _showSnackbar("Tidak terhubung ke server!");
      return;
    }
    
    await _saveSettings();
    
    setState(() {
      _isSpamming = true;
      _successCount = 0;
      _failCount = 0;
      _currentProgress = 0;
      _statusMessage = "Memulai spam ke $phone...";
    });
    
    _addToLog("🚀 Memulai spam ke $phone");
    _addToLog("📊 Delay: ${delay}ms, Jumlah: $jumlah");
    
    for (int i = 0; i < jumlah; i++) {
      if (!_isSpamming) break;
      
      setState(() {
        _currentProgress = i + 1;
        _statusMessage = "Mengirim ${i + 1}/$jumlah...";
      });
      
      await _sendPairingCode(phone);
      
      if (i < jumlah - 1 && _isSpamming) {
        await Future.delayed(Duration(milliseconds: delay));
      }
    }
    
    if (_isSpamming) {
      setState(() {
        _isSpamming = false;
        _statusMessage = "Spam selesai!";
      });
      _addToLog("✅ Spam selesai! Berhasil: $_successCount, Gagal: $_failCount");
      _showSnackbar("Spam selesai! Berhasil: $_successCount");
    }
  }
  
  void _stopSpam() {
    if (_isSpamming) {
      setState(() {
        _isSpamming = false;
        _statusMessage = "Spam dihentikan!";
      });
      _addToLog("⚠️ Spam dihentikan oleh user");
      _showSnackbar("Spam dihentikan");
    }
  }
  
  void _addToLog(String message) {
    final now = DateTime.now();
    final timestamp = "${now.hour.toString().padLeft(2, '0')}:${now.minute.toString().padLeft(2, '0')}:${now.second.toString().padLeft(2, '0')}";
    setState(() {
      _logs.insert(0, "$timestamp - $message");
      if (_logs.length > 50) {
        _logs.removeLast();
      }
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_logScrollController.hasClients) {
        _logScrollController.animateTo(
          0,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }
  
  void _clearLogs() {
    setState(() {
      _logs.clear();
    });
  }
  
  void _showSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: kPrimaryColor,
        duration: const Duration(seconds: 2),
      ),
    );
  }
  
  Future<void> _openWhatsApp(String phone) async {
    String cleanPhone = phone.replaceAll('+', '').replaceAll(' ', '');
    final url = "https://wa.me/$cleanPhone";
    await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  }
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBackgroundColor,
      appBar: AppBar(
        backgroundColor: kBackgroundColor,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_rounded, color: Colors.white),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text(
          "SPAM PAIR",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            letterSpacing: 1,
          ),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildTabSelector(),
            const SizedBox(height: 20),
            if (_selectedTab == 0) _buildWhatsAppSection(),
            const SizedBox(height: 20),
            _buildSettingsSection(),
            const SizedBox(height: 20),
            _buildActionButtons(),
            const SizedBox(height: 20),
            _buildInfoSection(),
            const SizedBox(height: 20),
            _buildLogSection(),
            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
  
  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [kBlueDark, kPrimaryColor.withOpacity(0.7)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kPrimaryColor.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 10,
                height: 10,
                decoration: BoxDecoration(
                  color: _isConnected ? Colors.green : Colors.red,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: (_isConnected ? Colors.green : Colors.red).withOpacity(0.5),
                      blurRadius: 8,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Text(
                _isConnected ? "Terhubung ke server" : "Tidak terhubung ke server",
                style: TextStyle(
                  color: _isConnected ? Colors.green : Colors.red,
                  fontSize: 12,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Status Server",
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _isConnected ? "Online" : "Offline",
                    style: TextStyle(
                      color: _isConnected ? Colors.green : Colors.red,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text(
                    "Total API",
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "$_totalApi",
                    style: const TextStyle(
                      color: kPrimaryColor,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              if (_isSpamming)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    const Text(
                      "Progress",
                      style: TextStyle(color: Colors.white70, fontSize: 12),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      "$_currentProgress/${_jumlahController.text}",
                      style: const TextStyle(
                        color: kPrimaryColor,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
            ],
          ),
          if (_isSpamming) ...[
            const SizedBox(height: 12),
            LinearProgressIndicator(
              value: _currentProgress / (int.tryParse(_jumlahController.text) ?? 1),
              backgroundColor: Colors.white24,
              color: kPrimaryColor,
            ),
            const SizedBox(height: 8),
            Text(
              _statusMessage,
              style: const TextStyle(color: Colors.white70, fontSize: 11),
            ),
          ],
        ],
      ),
    );
  }
  
  Widget _buildTabSelector() {
    return Container(
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: kCardColor,
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        children: [
          _buildTabButton(0, FontAwesomeIcons.whatsapp, "WhatsApp"),
          _buildTabButton(1, FontAwesomeIcons.telegram, "Telegram"),
          _buildTabButton(2, Icons.api, "API"),
        ],
      ),
    );
  }
  
  Widget _buildTabButton(int index, IconData icon, String label) {
    final isSelected = _selectedTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() => _selectedTab = index);
        },
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            color: isSelected ? kPrimaryColor : Colors.transparent,
            borderRadius: BorderRadius.circular(26),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: isSelected ? Colors.black : Colors.white70, size: 18),
              const SizedBox(width: 6),
              Text(
                label,
                style: TextStyle(
                  color: isSelected ? Colors.black : Colors.white70,
                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  
  Widget _buildWhatsAppSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kCardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kPrimaryColor.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "SPAM WHATSAPP",
            style: TextStyle(
              color: kPrimaryColor,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            "Kirim kode pairing ke nomor WhatsApp",
            style: TextStyle(color: Colors.white54, fontSize: 11),
          ),
          const SizedBox(height: 16),
          const Text(
            "Nomor WhatsApp",
            style: TextStyle(color: Colors.white70, fontSize: 12),
          ),
          const SizedBox(height: 8),
          Container(
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: kPrimaryColor.withOpacity(0.3)),
            ),
            child: TextField(
              controller: _phoneController,
              style: const TextStyle(color: Colors.white),
              keyboardType: TextInputType.phone,
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.phone_android, color: kPrimaryColor, size: 20),
                hintText: "+6283183517744",
                hintStyle: TextStyle(color: Colors.white.withOpacity(0.4)),
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: kPrimaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const Icon(Icons.info_outline, color: kPrimaryColor, size: 14),
                const SizedBox(width: 6),
                const Text(
                  "Format: +[kode negara][nomor]",
                  style: TextStyle(color: Colors.white54, fontSize: 10),
                ),
                const Spacer(),
                GestureDetector(
                  onTap: () => _openWhatsApp(_phoneController.text),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: kPrimaryColor.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      "Contoh: +62, +1, +44",
                      style: TextStyle(color: kPrimaryColor, fontSize: 10),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildSettingsSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kCardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kPrimaryColor.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "PENGATURAN",
            style: TextStyle(
              color: kPrimaryColor,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text(
                "DELAY (ms)",
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: kBackgroundColor,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: kPrimaryColor.withOpacity(0.3)),
                  ),
                  child: TextField(
                    controller: _delayController,
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () {
                  setState(() {
                    int current = int.tryParse(_delayController.text) ?? 1000;
                    _delayController.text = (current + 500).toString();
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: kPrimaryColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.add, color: kPrimaryColor, size: 18),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    int current = int.tryParse(_delayController.text) ?? 1000;
                    if (current > 500) {
                      _delayController.text = (current - 500).toString();
                    }
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: kPrimaryColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.remove, color: kPrimaryColor, size: 18),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              const Text(
                "JUMLAH",
                style: TextStyle(color: Colors.white70, fontSize: 12),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: kBackgroundColor,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: kPrimaryColor.withOpacity(0.3)),
                  ),
                  child: TextField(
                    controller: _jumlahController,
                    style: const TextStyle(color: Colors.white),
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 10),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              GestureDetector(
                onTap: () {
                  setState(() {
                    int current = int.tryParse(_jumlahController.text) ?? 2;
                    if (current < 20) {
                      _jumlahController.text = (current + 1).toString();
                    }
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: kPrimaryColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.add, color: kPrimaryColor, size: 18),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    int current = int.tryParse(_jumlahController.text) ?? 2;
                    if (current > 1) {
                      _jumlahController.text = (current - 1).toString();
                    }
                  });
                },
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: kPrimaryColor.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.remove, color: kPrimaryColor, size: 18),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          const Text(
            "Maksimal 20 spam per eksekusi",
            style: TextStyle(color: Colors.white38, fontSize: 10),
          ),
        ],
      ),
    );
  }
  
  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: GestureDetector(
            onTap: _isSpamming ? _stopSpam : _startSpam,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _isSpamming
                      ? [Colors.redAccent, Colors.red]
                      : [kPrimaryColor, kBlueDark],
                ),
                borderRadius: BorderRadius.circular(30),
                boxShadow: [
                  BoxShadow(
                    color: (_isSpamming ? Colors.red : kPrimaryColor).withOpacity(0.4),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Center(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      _isSpamming ? Icons.stop : Icons.send,
                      color: Colors.white,
                    ),
                    const SizedBox(width: 8),
                    Text(
                      _isSpamming ? "HENTIKAN SPAM" : "MULAI SPAM WHATSAPP",
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }
  
  Widget _buildInfoSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kCardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kPrimaryColor.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "INFORMASI PENTING",
            style: TextStyle(
              color: kPrimaryColor,
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          _buildBulletPoint("Gunakan format internasional: +[kode negara][nomor]"),
          _buildBulletPoint("Maksimal 20 spam per eksekusi"),
          _buildBulletPoint("Delay minimal 500ms untuk menghindari banned"),
          _buildBulletPoint("Pastikan koneksi internet stabil"),
        ],
      ),
    );
  }
  
  Widget _buildBulletPoint(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 6),
            width: 4,
            height: 4,
            decoration: BoxDecoration(
              color: kPrimaryColor,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(color: Colors.white54, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }
  
  Widget _buildLogSection() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: kCardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: kPrimaryColor.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "LOG AKTIVITAS",
                style: TextStyle(
                  color: kPrimaryColor,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 1,
                ),
              ),
              if (_logs.isNotEmpty)
                GestureDetector(
                  onTap: _clearLogs,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.red.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: const Text(
                      "Clear",
                      style: TextStyle(color: Colors.redAccent, fontSize: 10),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            height: 200,
            decoration: BoxDecoration(
              color: kBackgroundColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: _logs.isEmpty
                ? const Center(
                    child: Text(
                      "Belum ada aktivitas",
                      style: TextStyle(color: Colors.white38, fontSize: 12),
                    ),
                  )
                : ListView.builder(
                    controller: _logScrollController,
                    reverse: true,
                    padding: const EdgeInsets.all(8),
                    itemCount: _logs.length,
                    itemBuilder: (context, index) {
                      final log = _logs[index];
                      final isError = log.contains('❌') || log.contains('Error');
                      final isSuccess = log.contains('✅');
                      return Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4),
                        child: Text(
                          log,
                          style: TextStyle(
                            color: isError
                                ? Colors.redAccent
                                : isSuccess
                                    ? Colors.green
                                    : Colors.white70,
                            fontSize: 11,
                            fontFamily: 'monospace',
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}