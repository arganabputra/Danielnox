import 'chat_page.dart';
import 'collorsetting.dart';
import 'public_chat_page.dart';
import 'admin_control.dart';
import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:ui' as dart_ui;
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:http/http.dart' as http;

import 'owner_page.dart';
import 'home_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'motivasi.dart';

// ============================================================
// 🔥 WARNA MERAH ORANGE PEKAT
// ============================================================
class _C {
  static const bg      = Color(0xFF1A0A00);    // Merah kehitaman
  static const surface = Color(0xFF2A1100);    // Dark orange
  static const card    = Color(0xFF331500);    // Orange gelap
  static const line    = Color(0xFF4A1A00);    // Border orange gelap
  static const red     = Color(0xFFFF4500);    // Orange Merah (Primary)
  static const redGlow = Color(0xFFFF6600);    // Orange Terang
  static const redDeep = Color(0xFF8B1A00);    // Merah Tua
  static const muted   = Color(0xFFAA6633);    // Orange Redup
  static const dim     = Color(0xFF3D1500);    // Orange sangat gelap
  static const white   = Color(0xFFFFFFFF);
  static const green   = Color(0xFFFF8833);    // Orange Muda (pengganti hijau)
  static const gold    = Color(0xFFFFD700);
  static const purple  = Color(0xFF9C27B0);
  static const orangeLight = Color(0xFFFF8833);
}

const String API_BASE_URL = "http://nodeminzxzephyrine.sistems.my.id:2196";

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

class _DashboardPageState extends State<DashboardPage>
    with TickerProviderStateMixin {
  late AnimationController _fadeCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _orbitCtrl;
  late Animation<double> _fade;
  late Animation<double> _pulse;
  late Animation<double> _orbit;
  late WebSocketChannel channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  int onlineUsers       = 0;
  int activeConnections = 0;
  int _prevOnline       = 0;
  int _prevConnections  = 0;
  Timer? _statsTimer;
  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  late PageController _newsCtrl;
  double _currentNewsPage = 0.0;
  Timer? _newsTimer;

  // ============================================================
  // 🔥 JAM DIGITAL - STATE
  // ============================================================
  late Timer _clockTimer;
  String _timeWIB = "--:--:--";
  String _timeWITA = "--:--:--";
  String _timeWIT = "--:--:--";
  String _dateNow = "--/--/----";

  // ============================================================
  // 🔥 SENDER ACTIVE - STATE (API MURNI)
  // ============================================================
  List<Map<String, dynamic>> _senderList = [];
  bool _isLoadingSenders = false;
  String _senderError = '';

  // ============================================================
  // 🔥 JADWAL SHOLAT - STATE
  // ============================================================
  String _selectedSholatZone = "WIB";
  Map<String, dynamic> _jadwalSholat = {};
  bool _isLoadingSholat = false;

  @override
  void initState() {
    super.initState();

    sessionKey  = widget.sessionKey;
    username    = widget.username;
    password    = widget.password;
    role        = widget.role;
    expiredDate = widget.expiredDate;
    listBug     = widget.listBug;
    listDoos    = widget.listDoos;
    newsList    = widget.news;

    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 600))
      ..forward();
    _pulseCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 2000))
      ..repeat(reverse: true);
    _orbitCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 8))
      ..repeat();

    _fade  = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _pulse = Tween<double>(begin: 0.2, end: 1.0).animate(
        CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut));
    _orbit = Tween<double>(begin: 0.0, end: 1.0).animate(
        CurvedAnimation(parent: _orbitCtrl, curve: Curves.linear));

    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      try { channel.sink.add(jsonEncode({"type": "stats"})); } catch (_) {}
    });

    _initNewsBanner();
    _selectedPage = _buildHomePage();
    _initAndroidIdAndConnect();
    _loadProfileImage();

    // ============================================================
    // 🔥 START CLOCK
    // ============================================================
    _updateClock();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      _updateClock();
    });

    // ============================================================
    // 🔥 LOAD SENDERS DARI API
    // ============================================================
    _loadSendersFromApi();

    // ============================================================
    // 🔥 LOAD JADWAL SHOLAT
    // ============================================================
    _loadJadwalSholat();
  }

  // ============================================================
  // 🔥 LOAD SENDERS DARI API (MURNI)
  // ============================================================
  Future<void> _loadSendersFromApi() async {
    setState(() {
      _isLoadingSenders = true;
      _senderError = '';
    });

    try {
      final url = Uri.parse("$API_BASE_URL/mySender?key=$sessionKey");
      final res = await http.get(url).timeout(const Duration(seconds: 10));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['valid'] == true) {
          final connections = data['connections'] ?? [];
          setState(() {
            _senderList = connections.map<Map<String, dynamic>>((c) {
              return {
                'id': c['id'] ?? '',
                'phone': c['phone'] ?? '',
                'name': c['sessionName'] ?? 'Unknown',
                'status': c['connected'] == true ? 'active' : 'inactive',
                'country': _getCountryFromCode(c['phone'] ?? ''),
                'countryCode': _getCountryCode(c['phone'] ?? ''),
                'lastActive': c['lastSeen'] ?? '-',
              };
            }).toList();
            _isLoadingSenders = false;
          });
        } else {
          setState(() {
            _senderError = data['message'] ?? 'Gagal mengambil data sender';
            _isLoadingSenders = false;
          });
        }
      } else {
        setState(() {
          _senderError = 'Server error: ${res.statusCode}';
          _isLoadingSenders = false;
        });
      }
    } catch (e) {
      setState(() {
        _senderError = 'Koneksi gagal: $e';
        _isLoadingSenders = false;
      });
    }
  }

  String _getCountryFromCode(String phone) {
    final code = _getCountryCode(phone);
    switch (code) {
      case '+62': return 'Indonesia';
      case '+60': return 'Malaysia';
      case '+65': return 'Singapore';
      case '+63': return 'Philippines';
      case '+66': return 'Thailand';
      case '+84': return 'Vietnam';
      case '+1': return 'USA';
      case '+44': return 'UK';
      case '+81': return 'Japan';
      case '+82': return 'Korea';
      default: return 'Unknown';
    }
  }

  String _getCountryCode(String phone) {
    if (phone.startsWith('+62')) return '+62';
    if (phone.startsWith('+60')) return '+60';
    if (phone.startsWith('+65')) return '+65';
    if (phone.startsWith('+63')) return '+63';
    if (phone.startsWith('+66')) return '+66';
    if (phone.startsWith('+84')) return '+84';
    if (phone.startsWith('+1')) return '+1';
    if (phone.startsWith('+44')) return '+44';
    if (phone.startsWith('+81')) return '+81';
    if (phone.startsWith('+82')) return '+82';
    return '+00';
  }

  String _getCountryFlagFromCode(String code) {
    switch (code) {
      case '+62': return '🇮🇩';
      case '+60': return '🇲🇾';
      case '+65': return '🇸🇬';
      case '+63': return '🇵🇭';
      case '+66': return '🇹🇭';
      case '+84': return '🇻🇳';
      case '+1': return '🇺🇸';
      case '+44': return '🇬🇧';
      case '+81': return '🇯🇵';
      case '+82': return '🇰🇷';
      default: return '🌍';
    }
  }

  String _maskPhoneNumber(String phone) {
    if (phone.length <= 6) return phone;
    final prefix = phone.substring(0, 4);
    final suffix = phone.substring(phone.length - 4);
    return '$prefix****$suffix';
  }

  int get _activeSenderCount {
    return _senderList.where((s) => s['status'] == 'active').length;
  }

  // ============================================================
  // 🔥 LOAD JADWAL SHOLAT
  // ============================================================
  Future<void> _loadJadwalSholat() async {
    setState(() => _isLoadingSholat = true);
    try {
      final now = DateTime.now();
      final date = "${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}";
      final city = _selectedSholatZone == "WIB" ? "Jakarta" : 
                    _selectedSholatZone == "WITA" ? "Makassar" : "Jayapura";
      
      final url = Uri.parse("https://api.aladhan.com/v1/timingsByCity/$date?city=$city&country=Indonesia&method=2");
      final res = await http.get(url).timeout(const Duration(seconds: 10));
      
      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data['code'] == 200) {
          final timings = data['data']['timings'];
          setState(() {
            _jadwalSholat = {
              'Imsak': timings['Imsak'] ?? '--:--',
              'Fajr': timings['Fajr'] ?? '--:--',
              'Sunrise': timings['Sunrise'] ?? '--:--',
              'Dhuhr': timings['Dhuhr'] ?? '--:--',
              'Asr': timings['Asr'] ?? '--:--',
              'Maghrib': timings['Maghrib'] ?? '--:--',
              'Isha': timings['Isha'] ?? '--:--',
            };
            _isLoadingSholat = false;
          });
        } else {
          _useFallbackJadwal();
        }
      } else {
        _useFallbackJadwal();
      }
    } catch (e) {
      _useFallbackJadwal();
    }
  }

  void _useFallbackJadwal() {
    setState(() {
      _jadwalSholat = {
        'Imsak': '04:30',
        'Fajr': '04:40',
        'Sunrise': '05:55',
        'Dhuhr': '12:00',
        'Asr': '15:15',
        'Maghrib': '17:55',
        'Isha': '19:10',
      };
      _isLoadingSholat = false;
    });
  }

  void _showJadwalSholat() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => _JadwalSholatSheet(
        selectedZone: _selectedSholatZone,
        jadwal: _jadwalSholat,
        isLoading: _isLoadingSholat,
        onZoneChanged: (zone) {
          setState(() {
            _selectedSholatZone = zone;
          });
          _loadJadwalSholat();
        },
      ),
    );
  }

  // ============================================================
  // 🔥 WIDGET SENDER ACTIVE PAGE (DENGAN API MURNI)
  // ============================================================
  Widget _buildSenderActivePage() {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.red.withAlpha(26),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: _C.red.withAlpha(51)),
                ),
                child: Icon(Icons.satellite_alt_rounded, color: _C.red, size: 22),
              ),
              const SizedBox(width: 14),
              const Text(
                "SENDER ACTIVE",
                style: TextStyle(
                  color: _C.white,
                  fontFamily: 'Orbitron',
                  fontSize: 18,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _C.green.withAlpha(26),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _C.green.withAlpha(51)),
                ),
                child: Text(
                  "$_activeSenderCount Active",
                  style: TextStyle(
                    color: _C.green,
                    fontSize: 12,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),

          // Stats Row
          Row(
            children: [
              _buildSenderStat("Total", "${_senderList.length}", Icons.devices_rounded),
              const SizedBox(width: 10),
              _buildSenderStat("Online", "$_activeSenderCount", Icons.wifi_rounded),
              const SizedBox(width: 10),
              _buildSenderStat("Offline", "${_senderList.length - _activeSenderCount}", Icons.wifi_off_rounded),
            ],
          ),
          const SizedBox(height: 16),

          // Sender List
          Expanded(
            child: _isLoadingSenders
                ? const Center(
                    child: CircularProgressIndicator(
                      color: Color(0xFFFF4500),
                      strokeWidth: 2,
                    ),
                  )
                : _senderError.isNotEmpty
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.error_outline, color: _C.red, size: 48),
                            const SizedBox(height: 12),
                            Text(
                              _senderError,
                              style: TextStyle(
                                color: _C.muted,
                                fontFamily: 'ShareTechMono',
                                fontSize: 14,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            const SizedBox(height: 16),
                            ElevatedButton(
                              onPressed: _loadSendersFromApi,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: _C.red.withAlpha(26),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                  side: BorderSide(color: _C.red.withAlpha(51)),
                                ),
                              ),
                              child: const Text(
                                "RETRY",
                                style: TextStyle(color: _C.red),
                              ),
                            ),
                          ],
                        ),
                      )
                    : _senderList.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.sensors_off, color: _C.muted, size: 48),
                                const SizedBox(height: 12),
                                Text(
                                  "No senders found",
                                  style: TextStyle(
                                    color: _C.muted,
                                    fontFamily: 'ShareTechMono',
                                    fontSize: 14,
                                  ),
                                ),
                              ],
                            ),
                          )
                        : ListView.builder(
                            physics: const BouncingScrollPhysics(),
                            itemCount: _senderList.length,
                            itemBuilder: (context, index) {
                              final sender = _senderList[index];
                              final isActive = sender['status'] == 'active';
                              final flag = _getCountryFlagFromCode(sender['countryCode'] ?? '+00');
                              final maskedPhone = _maskPhoneNumber(sender['phone'] ?? '');

                              return Container(
                                margin: const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.all(14),
                                decoration: BoxDecoration(
                                  color: _C.card,
                                  borderRadius: BorderRadius.circular(14),
                                  border: Border.all(
                                    color: isActive ? _C.green.withAlpha(51) : _C.muted.withAlpha(25),
                                    width: 1,
                                  ),
                                ),
                                child: Row(
                                  children: [
                                    Container(
                                      width: 10,
                                      height: 10,
                                      decoration: BoxDecoration(
                                        color: isActive ? _C.green : _C.muted,
                                        shape: BoxShape.circle,
                                        boxShadow: isActive ? [
                                          BoxShadow(
                                            color: _C.green.withAlpha(128),
                                            blurRadius: 8,
                                          ),
                                        ] : [],
                                      ),
                                    ),
                                    const SizedBox(width: 14),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Row(
                                          children: [
                                            Text(
                                              flag,
                                              style: const TextStyle(fontSize: 18),
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              maskedPhone,
                                              style: TextStyle(
                                                color: isActive ? _C.white : _C.muted,
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                                fontFamily: 'ShareTechMono',
                                              ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 4),
                                        Row(
                                          children: [
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                              decoration: BoxDecoration(
                                                color: isActive ? _C.green.withAlpha(26) : _C.muted.withAlpha(26),
                                                borderRadius: BorderRadius.circular(6),
                                              ),
                                              child: Text(
                                                isActive ? "ONLINE" : "OFFLINE",
                                                style: TextStyle(
                                                  color: isActive ? _C.green : _C.muted,
                                                  fontSize: 8,
                                                  fontFamily: 'Orbitron',
                                                  fontWeight: FontWeight.w700,
                                                  letterSpacing: 0.5,
                                                ),
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              sender['country'] ?? 'Unknown',
                                              style: TextStyle(
                                                color: _C.muted,
                                                fontSize: 11,
                                                fontFamily: 'ShareTechMono',
                                              ),
                                            ),
                                            const SizedBox(width: 8),
                                            Text(
                                              sender['name'] ?? '',
                                              style: TextStyle(
                                                color: _C.muted.withAlpha(128),
                                                fontSize: 10,
                                                fontFamily: 'ShareTechMono',
                                              ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                    const Spacer(),
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.end,
                                      children: [
                                        Text(
                                          "Last active",
                                          style: TextStyle(
                                            color: _C.muted.withAlpha(128),
                                            fontSize: 9,
                                            fontFamily: 'ShareTechMono',
                                          ),
                                        ),
                                        const SizedBox(height: 2),
                                        Text(
                                          sender['lastActive'] ?? '-',
                                          style: TextStyle(
                                            color: _C.muted,
                                            fontSize: 10,
                                            fontFamily: 'ShareTechMono',
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              );
                            },
                          ),
          ),
        ],
      ),
    );
  }

  Widget _buildSenderStat(String label, String value, IconData icon) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
        decoration: BoxDecoration(
          color: _C.card,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.line),
        ),
        child: Column(
          children: [
            Icon(icon, color: _C.red, size: 16),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(
                color: _C.white,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w700,
                fontSize: 16,
              ),
            ),
            Text(
              label,
              style: TextStyle(
                color: _C.muted,
                fontSize: 8,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔥 FUNGSI UPDATE JAM
  // ============================================================
  void _updateClock() {
    final now = DateTime.now().toLocal();
    
    final wib = now.add(const Duration(hours: 0));
    final wita = now.add(const Duration(hours: 1));
    final wit = now.add(const Duration(hours: 2));

    setState(() {
      _timeWIB = _formatTime(wib);
      _timeWITA = _formatTime(wita);
      _timeWIT = _formatTime(wit);
      _dateNow = _formatDate(wib);
    });
  }

  String _formatTime(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    final s = dt.second.toString().padLeft(2, '0');
    return '$h:$m:$s';
  }

  String _formatDate(DateTime dt) {
    final d = dt.day.toString().padLeft(2, '0');
    final m = dt.month.toString().padLeft(2, '0');
    final y = dt.year.toString();
    return '$d/$m/$y';
  }

  // ─── INIT ─────────────────────────────────────────────────
  void _initNewsBanner() {
    _newsCtrl = PageController(initialPage: 0, viewportFraction: 0.9);
    _newsCtrl.addListener(() {
      if (_newsCtrl.hasClients && _newsCtrl.page != null) {
        setState(() => _currentNewsPage = _newsCtrl.page!);
      }
    });
    if (newsList.isNotEmpty) {
      _newsTimer = Timer.periodic(const Duration(seconds: 5), (_) {
        if (_newsCtrl.hasClients) {
          int next = (_currentNewsPage + 1).round() % newsList.length;
          _newsCtrl.animateToPage(next,
              duration: const Duration(milliseconds: 700),
              curve: Curves.easeInOutCubic);
        }
      });
    }
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final path  = prefs.getString('profile_image_$username');
    if (path != null && path.isNotEmpty && mounted) {
      setState(() => _profileImage = File(path));
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
        Uri.parse('http://nodeminzxzephyrine.sistems.my.id:2196/ping'));

    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));

    channel.stream.listen(
      (event) {
        final data = jsonDecode(event);
        if (data['type'] == 'myInfo') {
          if (data['valid'] == false) {
            final msg = data['reason'] == 'androidIdMismatch'
                ? "Your account has logged on another device."
                : "Key is not valid. Please login again.";
            _handleInvalidSession(msg);
          } else {
            channel.sink.add(jsonEncode({"type": "stats"}));
          }
        }
        if (data['type'] == 'stats' && mounted) {
          setState(() {
            _prevOnline       = onlineUsers;
            _prevConnections  = activeConnections;
            onlineUsers       = data['onlineUsers']       ?? 0;
            activeConnections = data['activeConnections'] ?? 0;
          });
        }
      },
      onError: (e) => print('❌ WS Error: $e'),
      onDone:  () => print('🔌 WS Closed'),
    );
  }

  Future<void> _openUrl(String url) async {
    final uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withAlpha(230),
      builder: (_) => _SessionDialog(
        message: message,
        onOk: () => Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const LoginPage()),
          (r) => false,
        ),
      ),
    );
  }

  // ─── NAV ──────────────────────────────────────────────────
  void _onNavTapped(int index) {
    if (index == 1) { _showWhatsAppSheet(); return; }
    
    if (index == 5) {
      _openAdminPanel();
      return;
    }
    
    setState(() {
      _bottomNavIndex = index;
      switch (index) {
        case 0: _selectedPage = _buildHomePage(); break;
        case 2: _selectedPage = InfoPage(sessionKey: sessionKey); break;
        case 3: _selectedPage = MotivationPage(); break;
        case 4: _selectedPage = ToolsPage(
            sessionKey: sessionKey,
            userRole: role,
            listDoos: listDoos); break;
      }
    });
  }

  void _openAdminPanel() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => AdminControlPage(
          sessionKey: sessionKey,
          username: username,
          role: role,
        ),
      ),
    );
  }

  void _handleQuickAction(String label) {
    switch (label) {
      case 'History':
        Navigator.push(context, MaterialPageRoute(
            builder: (_) => RiwayatPage(sessionKey: sessionKey, role: role)));
        break;
      case 'Profile':
        Navigator.push(context, MaterialPageRoute(
            builder: (_) => ProfilePage(
              username: username, password: password,
              role: role, expiredDate: expiredDate, sessionKey: sessionKey,
            )));
        break;
      case 'Support':
        Navigator.push(context, MaterialPageRoute(
            builder: (_) => const ContactPage()));
        break;
      case 'Owner':
        setState(() => _selectedPage = OwnerPage(
          sessionKey: sessionKey, username: username));
        break;
      case 'Sender Active':
        setState(() => _selectedPage = _buildSenderActivePage());
        break;
      case 'Chat Public':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const PublicChatPage(),
          ),
        );
        break;
      case 'Chat Page':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChatPage(
              sessionKey: sessionKey,
            ),
          ),
        );
        break;
      case 'Color Setting':
        showColorSettingsSheet(context);
        break;
    }
  }

  // ============================================================
  // 🔥 FUNGSI BUKA COLOR SETTING
  // ============================================================
  void showColorSettingsSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => const ColorSettingsSheet(),
    );
  }

  void _showWhatsAppSheet() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withAlpha(190),
      builder: (_) => _WhatsAppSheet(
        onCrash: () {
          Navigator.pop(context);
          setState(() {
            _bottomNavIndex = 1;
            _selectedPage = HomePage(
              username: username,
              password: password,
              listBug: listBug,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            );
          });
        },
        onSender: () {
          Navigator.pop(context);
          Navigator.push(context, MaterialPageRoute(
            builder: (_) => BugSenderPage(
              sessionKey: sessionKey,
              username: username,
              role: role,
            ),
          ));
        },
      ),
    );
  }

  // ─── HOME PAGE CONTENT ────────────────────────────────────
  Widget _buildHomePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: 16),
          _buildHeroCard(),
          const SizedBox(height: 12),
          _buildLiveBar(),
          const SizedBox(height: 16),
          _buildQuickActions(),
          const SizedBox(height: 18),
          _buildNewsBanner(),
          const SizedBox(height: 16),
          _buildTelegramBtn(),
          const SizedBox(height: 28),
        ],
      ),
    );
  }

  // ─── HERO CARD ─────────────────────────────────────────────
  Widget _buildHeroCard() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(26),
          color: _C.card,
          border: Border.all(color: _C.line),
          boxShadow: [
            BoxShadow(
              color: _C.red.withAlpha(33),
              blurRadius: 40,
              offset: const Offset(0, 12),
            ),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          children: [
            AnimatedBuilder(
              animation: _orbit,
              builder: (ctx, _) {
                final w = MediaQuery.of(ctx).size.width;
                return Positioned(
                  left: -120 + (_orbit.value * (w + 240)),
                  top: 0, bottom: 0,
                  child: Container(
                    width: 100,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.centerLeft,
                        end: Alignment.centerRight,
                        colors: [
                          Colors.transparent,
                          _C.red.withAlpha(23),
                          Colors.transparent,
                        ],
                      ),
                    ),
                  ),
                );
              },
            ),
            Positioned(
              left: 0, top: 0, bottom: 0,
              child: AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Container(
                  width: 3,
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [
                        Colors.transparent,
                        _C.red.withAlpha((_pulse.value * 0.6 + 0.4) * 255 ~/ 1),
                        _C.red,
                        _C.red.withAlpha((_pulse.value * 0.6 + 0.4) * 255 ~/ 1),
                        Colors.transparent,
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: Container(
                height: 1,
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                    Colors.transparent,
                    _C.red.withAlpha(163),
                    Colors.transparent,
                  ]),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 22, 20, 22),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _Avatar(image: _profileImage, pulse: _pulse, size: 64),
                  const SizedBox(width: 18),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 16, height: 1.5,
                              color: _C.red,
                              margin: const EdgeInsets.only(right: 8),
                            ),
                            Text(
                              "WELCOME BACK",
                              style: TextStyle(
                                color: _C.muted,
                                fontFamily: 'ShareTechMono',
                                fontSize: 9,
                                letterSpacing: 2.5,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 7),
                        Text(
                          username.toUpperCase(),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(
                            color: _C.white,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 22,
                            letterSpacing: 0.8,
                          ),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            _RoleBadge(role: role),
                            const SizedBox(width: 8),
                            _ExpBadge(date: expiredDate),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(child: _buildDigitalClock()),
                            const SizedBox(width: 8),
                            _buildSholatButton(),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔥 BUTTON JADWAL SHOLAT
  // ============================================================
  Widget _buildSholatButton() {
    return GestureDetector(
      onTap: _showJadwalSholat,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
        decoration: BoxDecoration(
          color: _C.surface.withAlpha(200),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: _C.gold.withAlpha(40)),
          boxShadow: [
            BoxShadow(
              color: _C.gold.withAlpha(20),
              blurRadius: 10,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.mosque_rounded, color: _C.gold, size: 20),
            const SizedBox(height: 2),
            Text(
              "SHOLAT",
              style: TextStyle(
                color: _C.gold,
                fontSize: 7,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.w700,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // 🔥 WIDGET JAM DIGITAL
  // ============================================================
  Widget _buildDigitalClock() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: _C.surface.withAlpha(200),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _C.red.withAlpha(40)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.calendar_today_rounded, color: _C.muted, size: 12),
              const SizedBox(width: 6),
              Text(
                _dateNow,
                style: TextStyle(
                  color: _C.muted,
                  fontSize: 10,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Container(
                width: 4, height: 4,
                decoration: BoxDecoration(
                  color: _C.red,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                "WIB",
                style: TextStyle(
                  color: _C.muted,
                  fontSize: 9,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                _timeWIB,
                style: TextStyle(
                  color: _C.white,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const Spacer(),
              AnimatedBuilder(
                animation: _pulse,
                builder: (_, __) => Container(
                  width: 4, height: 4,
                  decoration: BoxDecoration(
                    color: _C.red.withAlpha((_pulse.value * 255).toInt()),
                    shape: BoxShape.circle,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Container(
                width: 4, height: 4,
                decoration: BoxDecoration(
                  color: _C.red.withAlpha(180),
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                "WITA",
                style: TextStyle(
                  color: _C.muted,
                  fontSize: 9,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                _timeWITA,
                style: TextStyle(
                  color: _C.white,
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const Spacer(),
              Container(
                width: 4, height: 4,
                decoration: BoxDecoration(
                  color: _C.muted.withAlpha(100),
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Container(
                width: 4, height: 4,
                decoration: BoxDecoration(
                  color: _C.muted,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                "WIT",
                style: TextStyle(
                  color: _C.muted,
                  fontSize: 9,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w700,
                  letterSpacing: 1,
                ),
              ),
              const SizedBox(width: 12),
              Text(
                _timeWIT,
                style: TextStyle(
                  color: _C.white.withAlpha(200),
                  fontSize: 14,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
              const Spacer(),
              Container(
                width: 4, height: 4,
                decoration: BoxDecoration(
                  color: _C.muted.withAlpha(60),
                  shape: BoxShape.circle,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ─── LIVE STATS BAR ─────────────────────────────────────────
  Widget _buildLiveBar() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                child: _BigStatCard(
                  label: 'ONLINE',
                  numValue: onlineUsers,
                  prevValue: _prevOnline,
                  accent: _C.green,
                  icon: Icons.people_rounded,
                  pulse: _pulse,
                  showPulse: true,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _BigStatCard(
                  label: 'LINKED',
                  numValue: activeConnections,
                  prevValue: _prevConnections,
                  accent: _C.red,
                  icon: Icons.link_rounded,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          _TierCard(role: role),
        ],
      ),
    );
  }

  // ─── QUICK ACTIONS STRIP ──────────────────────────────────
  Widget _buildQuickActions() {
    final actions = <Map<String, dynamic>>[
      {'icon': Icons.history_rounded,           'label': 'History', 'color': _C.red},
      {'icon': Icons.chat_rounded,              'label': 'Chat Page', 'color': const Color(0xFF00BCD4)},
      {'icon': Icons.palette_rounded,           'label': 'Color Setting', 'color': const Color(0xFFFF6B6B)},
      {'icon': Icons.balance_rounded,           'label': 'Chat Public', 'color': _C.purple},
      {'icon': Icons.person_rounded,            'label': 'Profile', 'color': _C.white},
      {'icon': Icons.headset_mic_rounded,       'label': 'Support', 'color': _C.white},
      {'icon': Icons.satellite_alt_rounded,     'label': 'Sender Active', 'color': _C.green},
      if (role == 'owner')
        {'icon': Icons.workspace_premium_rounded, 'label': 'Owner', 'color': _C.gold},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, bottom: 12),
          child: Row(children: [
            Container(
              width: 3, height: 14,
              decoration: BoxDecoration(
                color: _C.red,
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: _C.red.withAlpha(128), blurRadius: 8),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Text(
              "QUICK ACCESS",
              style: TextStyle(
                color: _C.muted,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
          ]),
        ),
        SizedBox(
          height: 82,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16),
            itemCount: actions.length,
            separatorBuilder: (_, __) => const SizedBox(width: 10),
            itemBuilder: (_, i) {
              final a = actions[i];
              final color = a['color'] as Color;
              return GestureDetector(
                onTap: () => _handleQuickAction(a['label'] as String),
                child: Container(
                  width: 86,
                  decoration: BoxDecoration(
                    color: _C.card,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: _C.line),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 36, height: 36,
                        decoration: BoxDecoration(
                          color: color.withAlpha(20),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: color.withAlpha(38)),
                        ),
                        child: Icon(a['icon'] as IconData,
                            color: color, size: 18),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        a['label'] as String,
                        style: TextStyle(
                          color: _C.muted,
                          fontFamily: 'ShareTechMono',
                          fontSize: 9,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  // ─── NEWS BANNER ──────────────────────────────────────────
  Widget _buildNewsBanner() {
    if (newsList.isEmpty) return const SizedBox();
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 20, bottom: 12),
          child: Row(children: [
            Container(
              width: 3, height: 14,
              decoration: BoxDecoration(
                color: _C.red,
                borderRadius: BorderRadius.circular(2),
                boxShadow: [
                  BoxShadow(color: _C.red.withAlpha(128), blurRadius: 8),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Text(
              "LATEST NEWS",
              style: TextStyle(
                color: _C.muted,
                fontFamily: 'ShareTechMono',
                fontSize: 10,
                letterSpacing: 2,
              ),
            ),
          ]),
        ),
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: _newsCtrl,
            itemCount: newsList.length,
            itemBuilder: (_, i) {
              final item = newsList[i];
              return AnimatedBuilder(
                animation: _newsCtrl,
                builder: (_, child) {
                  double diff = (_newsCtrl.hasClients && _newsCtrl.page != null)
                      ? (_newsCtrl.page! - i).abs()
                      : 0.0;
                  double scale = (1 - diff * 0.04).clamp(0.96, 1.0);
                  return Transform.scale(scale: scale, child: child);
                },
                child: _NewsCard(item: item),
              );
            },
          ),
        ),
        const SizedBox(height: 10),
        AnimatedBuilder(
          animation: _newsCtrl,
          builder: (_, __) {
            double page = _newsCtrl.hasClients && _newsCtrl.page != null
                ? _newsCtrl.page!
                : _currentNewsPage;
            return Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(newsList.length, (i) {
                double diff = (i - page).abs();
                return AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  width: diff < 0.5 ? 20 : 5,
                  height: 4,
                  decoration: BoxDecoration(
                    color: diff < 0.5
                        ? _C.red
                        : _C.muted.withAlpha(77),
                    borderRadius: BorderRadius.circular(3),
                  ),
                );
              }),
            );
          },
        ),
      ],
    );
  }

  // ─── TELEGRAM BUTTON ─────────────────────────────────────────
  Widget _buildTelegramBtn() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GestureDetector(
        onTap: () => _openUrl("https://t.me/ikyfamouss"),
        child: Container(
          height: 64,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            color: _C.card,
            border: Border.all(color: _C.red.withAlpha(46)),
            gradient: LinearGradient(
              begin: Alignment.centerLeft,
              end: Alignment.centerRight,
              colors: [
                _C.red.withAlpha(33),
                _C.card,
              ],
            ),
            boxShadow: [
              BoxShadow(
                color: _C.red.withAlpha(18),
                blurRadius: 24,
                offset: const Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: [
              const SizedBox(width: 18),
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: _C.red.withAlpha(26),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: _C.red.withAlpha(51)),
                ),
                child: const Center(
                  child: Icon(FontAwesomeIcons.telegram,
                      color: _C.red, size: 17),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      "DarkCrasher Channel",
                      style: TextStyle(
                        color: _C.white,
                        fontWeight: FontWeight.w800,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      "Join the community",
                      style: TextStyle(
                        color: _C.muted,
                        fontFamily: 'ShareTechMono',
                        fontSize: 10,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.arrow_forward_ios_rounded,
                  color: _C.red, size: 13),
              const SizedBox(width: 18),
            ],
          ),
        ),
      ),
    );
  }

  // ─── DRAWER ───────────────────────────────────────────────
  Widget _buildDrawer() {
    return Drawer(
      backgroundColor: Colors.transparent,
      width: MediaQuery.of(context).size.width * 0.8,
      child: Container(
        decoration: BoxDecoration(
          color: _C.surface,
          borderRadius: const BorderRadius.only(
            topRight: Radius.circular(30),
            bottomRight: Radius.circular(30),
          ),
          border: Border(
            right:  BorderSide(color: _C.line),
            top:    BorderSide(color: _C.line),
            bottom: BorderSide(color: _C.line),
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.fromLTRB(24, 52, 24, 28),
              decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: _C.line)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      _Avatar(image: _profileImage, pulse: _pulse,
                          size: 70, borderWidth: 2),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              username,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                color: _C.white,
                                fontSize: 18,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            const SizedBox(height: 6),
                            _RoleBadge(role: role),
                          ],
                        ),
                      ),
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Container(
                          padding: const EdgeInsets.all(8),
                          decoration: BoxDecoration(
                            color: _C.dim.withAlpha(128),
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.close_rounded,
                              color: _C.muted, size: 16),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 10),
                    decoration: BoxDecoration(
                      color: _C.card,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: _C.line),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.schedule_rounded,
                            color: _C.muted, size: 14),
                        const SizedBox(width: 10),
                        Text(
                          "Expires $expiredDate",
                          style: TextStyle(
                            color: _C.muted,
                            fontSize: 12,
                            fontFamily: 'ShareTechMono',
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(
                    vertical: 16, horizontal: 16),
                children: [
                  if (role == "owner")
                    _DrawerItem(
                      icon: Icons.workspace_premium_rounded,
                      iconColor: _C.gold,
                      label: "Owner Panel",
                      badge: "OWNER",
                      onTap: () {
                        Navigator.pop(context);
                        setState(() => _selectedPage = OwnerPage(
                          sessionKey: sessionKey,
                          username: username,
                        ));
                      },
                    ),
                  _DrawerItem(
                    icon: Icons.history_rounded,
                    iconColor: _C.red,
                    label: "Activity History",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => RiwayatPage(
                              sessionKey: sessionKey, role: role)));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.person_rounded,
                    iconColor: _C.white,
                    label: "My Profile",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => ProfilePage(
                            username: username,
                            password: password,
                            role: role,
                            expiredDate: expiredDate,
                            sessionKey: sessionKey,
                          )));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.headset_mic_rounded,
                    iconColor: _C.white,
                    label: "Customer Service",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => const ContactPage()));
                    },
                  ),
                  _DrawerItem(
                    icon: Icons.satellite_alt_rounded,
                    iconColor: _C.green,
                    label: "Sender Active",
                    onTap: () {
                      Navigator.pop(context);
                      setState(() => _selectedPage = _buildSenderActivePage());
                    },
                  ),
                  const SizedBox(height: 16),
                  _DrawerItem(
                    icon: Icons.logout_rounded,
                    iconColor: Colors.redAccent,
                    label: "Log Out",
                    isDestructive: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                            builder: (_) => const LoginPage()),
                        (r) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.fromLTRB(24, 14, 24, 32),
              decoration: BoxDecoration(
                border: Border(top: BorderSide(color: _C.line)),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.shield_rounded, color: _C.dim, size: 13),
                  const SizedBox(width: 8),
                  Text(
                    "DarkCrasher",
                    style: TextStyle(
                      color: _C.dim,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── BOTTOM NAV ───────────────────────────────────────────
  Widget _buildBottomNav() {
    final List<_NavItem> items = [
      _NavItem(Icons.home_rounded,          "Home"),
      _NavItem(FontAwesomeIcons.whatsapp,   "WA"),
      _NavItem(Icons.notifications_rounded, "Info"),
      _NavItem(Icons.music_note_rounded,    "Vibes"),
      _NavItem(Icons.grid_view_rounded,     "Tools"),
      _NavItem(Icons.desktop_windows_rounded, "RAT"),
    ];

    return Container(
      margin: const EdgeInsets.fromLTRB(20, 0, 20, 20),
      height: 68,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        color: _C.card.withAlpha(230),
        border: Border.all(color: _C.line),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withAlpha(153),
              blurRadius: 30,
              offset: const Offset(0, 10)),
          BoxShadow(
              color: _C.red.withAlpha(20),
              blurRadius: 20),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: dart_ui.ImageFilter.blur(sigmaX: 24, sigmaY: 24),
          child: Row(
            children: List.generate(items.length, (i) {
              final active = _bottomNavIndex == i;
              final isRat = i == 5;
              final ratColor = isRat ? const Color(0xFFFF6D00) : _C.red;
              
              return Expanded(
                child: GestureDetector(
                  behavior: HitTestBehavior.opaque,
                  onTap: () => _onNavTapped(i),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 280),
                    curve: Curves.easeOutCubic,
                    margin: const EdgeInsets.symmetric(
                        vertical: 8, horizontal: 5),
                    decoration: BoxDecoration(
                      color: active
                          ? (isRat ? const Color(0xFFFF6D00).withAlpha(33) : _C.red.withAlpha(33))
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(16),
                      border: active
                          ? Border.all(
                              color: isRat ? const Color(0xFFFF6D00).withAlpha(71) : _C.red.withAlpha(71),
                              width: 1)
                          : null,
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        AnimatedScale(
                          scale: active ? 1.12 : 1.0,
                          duration: const Duration(milliseconds: 280),
                          child: Icon(
                            items[i].icon,
                            size: 20,
                            color: active
                                ? (isRat ? const Color(0xFFFF6D00) : _C.red)
                                : _C.muted.withAlpha(153),
                          ),
                        ),
                        const SizedBox(height: 3),
                        AnimatedDefaultTextStyle(
                          duration: const Duration(milliseconds: 280),
                          style: TextStyle(
                            color: active
                                ? (isRat ? const Color(0xFFFF6D00) : _C.red)
                                : _C.muted.withAlpha(153),
                            fontSize: active ? 9 : 8,
                            fontWeight: active
                                ? FontWeight.w800
                                : FontWeight.w500,
                            fontFamily: 'ShareTechMono',
                            letterSpacing: active ? 0.8 : 0,
                          ),
                          child: Text(items[i].label),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  // ─── BUILD ────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      backgroundColor: _C.bg,
      extendBodyBehindAppBar: true,
      extendBody: true,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: Stack(
        children: [
          const Positioned.fill(child: _DotGrid()),
          Positioned(
            top: -80,
            left: MediaQuery.of(context).size.width * 0.5 - 100,
            child: Container(
              width: 200, height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  _C.red.withAlpha(38),
                  Colors.transparent,
                ]),
              ),
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 88),
              child: FadeTransition(
                opacity: _fade,
                child: _selectedPage,
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNav(),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(1),
        child: Container(
          height: 1,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [
              Colors.transparent,
              _C.red.withAlpha(46),
              Colors.transparent,
            ]),
          ),
        ),
      ),
      flexibleSpace: ClipRect(
        child: BackdropFilter(
          filter: dart_ui.ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  _C.bg.withAlpha(217),
                  _C.bg.withAlpha(0),
                ],
              ),
            ),
          ),
        ),
      ),
      leading: IconButton(
        icon: Icon(Icons.tune_rounded, color: _C.red, size: 22),
        onPressed: () => _scaffoldKey.currentState?.openDrawer(),
      ),
      title: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Container(
              width: 6, height: 6,
              decoration: BoxDecoration(
                color: _C.red,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: _C.red.withAlpha((_pulse.value * 0.7 * 255).toInt()),
                    blurRadius: 10,
                    spreadRadius: 1,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 10),
          const Text(
            "DarkCrasher",
            style: TextStyle(
              color: _C.white,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w900,
              fontSize: 17,
              letterSpacing: 3,
            ),
          ),
        ],
      ),
      actions: [
        IconButton(
          icon: Icon(Icons.headset_mic_outlined,
              color: _C.white.withAlpha(140), size: 20),
          onPressed: () => Navigator.push(context,
              MaterialPageRoute(builder: (_) => const ContactPage())),
        ),
        Padding(
          padding: const EdgeInsets.only(right: 6),
          child: IconButton(
            icon: Icon(FontAwesomeIcons.userCircle,
                color: _C.white.withAlpha(140), size: 20),
            onPressed: () => Navigator.push(context,
                MaterialPageRoute(
                  builder: (_) => ProfilePage(
                    username: username,
                    password: password,
                    role: role,
                    expiredDate: expiredDate,
                    sessionKey: sessionKey,
                  ),
                )),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    _newsTimer?.cancel();
    _newsCtrl.dispose();
    _statsTimer?.cancel();
    _clockTimer.cancel();
    channel.sink.close(status.goingAway);
    _fadeCtrl.dispose();
    _pulseCtrl.dispose();
    _orbitCtrl.dispose();
    super.dispose();
  }
}

// ════════════════════════════════════════════════════════════
// JADWAL SHOLAT SHEET
// ════════════════════════════════════════════════════════════
class _JadwalSholatSheet extends StatefulWidget {
  final String selectedZone;
  final Map<String, dynamic> jadwal;
  final bool isLoading;
  final Function(String) onZoneChanged;

  const _JadwalSholatSheet({
    required this.selectedZone,
    required this.jadwal,
    required this.isLoading,
    required this.onZoneChanged,
  });

  @override
  State<_JadwalSholatSheet> createState() => _JadwalSholatSheetState();
}

class _JadwalSholatSheetState extends State<_JadwalSholatSheet> {
  final List<String> _zones = ['WIB', 'WITA', 'WIT'];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.black.withAlpha(240),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
        border: Border(
          top: BorderSide(color: _C.red.withAlpha(51)),
          left: BorderSide(color: _C.red.withAlpha(51)),
          right: BorderSide(color: _C.red.withAlpha(51)),
        ),
      ),
      padding: const EdgeInsets.fromLTRB(20, 14, 20, 32),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 36, height: 3,
            margin: const EdgeInsets.only(bottom: 22),
            decoration: BoxDecoration(
              color: _C.dim,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: _C.gold.withAlpha(26),
                  borderRadius: BorderRadius.circular(13),
                  border: Border.all(color: _C.gold.withAlpha(51)),
                ),
                child: Icon(Icons.mosque_rounded, color: _C.gold, size: 20),
              ),
              const SizedBox(width: 14),
              const Text(
                "JADWAL SHOLAT",
                style: TextStyle(
                  color: _C.gold,
                  fontFamily: 'Orbitron',
                  fontSize: 15,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
          const SizedBox(height: 18),
          // Zone Selector
          Row(
            children: _zones.map((zone) {
              final isSelected = zone == widget.selectedZone;
              return Expanded(
                child: GestureDetector(
                  onTap: () {
                    HapticFeedback.selectionClick();
                    widget.onZoneChanged(zone);
                  },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                    decoration: BoxDecoration(
                      color: isSelected ? _C.gold.withAlpha(26) : _C.surface,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isSelected ? _C.gold.withAlpha(51) : _C.line,
                        width: 1,
                      ),
                    ),
                    child: Text(
                      zone,
                      style: TextStyle(
                        color: isSelected ? _C.gold : _C.muted,
                        fontFamily: 'Orbitron',
                        fontWeight: isSelected ? FontWeight.w700 : FontWeight.normal,
                        fontSize: 13,
                        letterSpacing: 1,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 18),
          // Jadwal List
          if (widget.isLoading)
            const Padding(
              padding: EdgeInsets.all(24),
              child: CircularProgressIndicator(color: _C.gold),
            )
          else
            Container(
              decoration: BoxDecoration(
                color: _C.surface,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: _C.line),
              ),
              child: Column(
                children: [
                  _buildSholatRow("🌙 Imsak", widget.jadwal['Imsak'] ?? '--:--'),
                  _buildSholatRow("🕌 Subuh", widget.jadwal['Fajr'] ?? '--:--'),
                  _buildSholatRow("☀️ Terbit", widget.jadwal['Sunrise'] ?? '--:--'),
                  _buildSholatRow("🌤️ Dhuha", widget.jadwal['Sunrise'] ?? '--:--'),
                  _buildSholatRow("🌞 Dzuhur", widget.jadwal['Dhuhr'] ?? '--:--'),
                  _buildSholatRow("🌅 Ashar", widget.jadwal['Asr'] ?? '--:--'),
                  _buildSholatRow("🌆 Maghrib", widget.jadwal['Maghrib'] ?? '--:--'),
                  _buildSholatRow("🌙 Isya", widget.jadwal['Isha'] ?? '--:--'),
                ],
              ),
            ),
          const SizedBox(height: 16),
          Text(
            "🕋 Zona: ${widget.selectedZone}",
            style: TextStyle(
              color: _C.muted,
              fontFamily: 'ShareTechMono',
              fontSize: 12,
            ),
          ),
          const SizedBox(height: 12),
          GestureDetector(
            onTap: () => Navigator.pop(context),
            child: Container(
              width: double.infinity,
              height: 46,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: _C.gold.withAlpha(51)),
                color: _C.gold.withAlpha(10),
              ),
              alignment: Alignment.center,
              child: Text(
                "TUTUP",
                style: TextStyle(
                  color: _C.gold,
                  fontFamily: 'Orbitron',
                  fontSize: 12,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 2,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSholatRow(String label, String time) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(color: _C.line.withAlpha(128), width: 0.5),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              color: _C.white.withAlpha(200),
              fontFamily: 'ShareTechMono',
              fontSize: 13,
            ),
          ),
          Text(
            time,
            style: TextStyle(
              color: _C.gold,
              fontFamily: 'Orbitron',
              fontSize: 14,
              fontWeight: FontWeight.bold,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ─── REUSABLE WIDGETS ────────────────────────────────────────────
// (Semua widget reusable dengan warna sudah dirombak)
// ─── DotGrid, Avatar, RoleBadge, ExpBadge, AnimatedCounter, BigStatCard, TierCard, NewsCard, WhatsAppSheet, SheetItem, DrawerItem, SessionDialog, NavItem, NewsMedia ───