import 'dart:convert';
import 'dart:math' as math;
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

// ============================================================
// 🔥 WARNA MERAH ORANGE PEKAT
// ============================================================
const Color _void     = Color(0xFF1A0A00);    // Merah kehitaman
const Color _ink      = Color(0xFF2A1100);    // Dark orange
const Color _plate    = Color(0xFF331500);    // Orange gelap
const Color _surface  = Color(0xFF3D1800);    // Orange medium
const Color _rim      = Color(0xFF4A1A00);    // Border orange gelap
const Color _rimHi    = Color(0xFF662200);    // Orange terang gelap
const Color _red      = Color(0xFFFF4500);    // Orange Merah (Primary)
const Color _redDim   = Color(0xFFCC3300);    // Merah Orange Pekat
const Color _redGhost = Color(0xFF8B1A00);    // Merah Tua
const Color _ash      = Color(0xFFAA6633);    // Orange Redup
const Color _slate    = Color(0xFF663300);    // Orange gelap
const Color _snow     = Color(0xFFFFFFFF);    // Putih

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final _targetCtrl = TextEditingController();
  late AnimationController _pulse;
  late AnimationController _enter;
  late AnimationController _scanCtrl;
  late AnimationController _armedCtrl;
  late VideoPlayerController _video;

  String _selectedBugId  = '';
  String _bugMode        = 'number';
  String _senderMode     = 'private';

  int    _privateCount   = 0;
  int    _globalCount    = 0;
  bool   _isSending      = false;
  bool   _videoReady     = false;

  // ============================================================
  // 🔥 COOLDOWN - STATE
  // ============================================================
  bool   _isCooldown     = false;
  int    _cooldownRemaining = 0;
  Timer? _cooldownTimer;
  static const int COOLDOWN_DURATION = 15;

  @override
  void initState() {
    super.initState();

    _pulse = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1800))
      ..repeat(reverse: true);

    _enter = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000))
      ..forward();

    _scanCtrl = AnimationController(
        vsync: this, duration: const Duration(seconds: 6))
      ..repeat();

    _armedCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 900))
      ..repeat(reverse: true);

    _video = VideoPlayerController.asset('assets/videos/bug.mp4')
      ..initialize().then((_) {
        if (mounted) setState(() => _videoReady = true);
        _video.setLooping(true);
        _video.setVolume(1.0);
        _video.play();
      }).catchError((_) {});

    final bugs = _filteredBugs();
    if (bugs.isNotEmpty) _selectedBugId = bugs[0]['bug_id'];
    _fetchSenderStats();
  }

  @override
  void dispose() {
    _pulse.dispose();
    _enter.dispose();
    _scanCtrl.dispose();
    _armedCtrl.dispose();
    _video.dispose();
    _targetCtrl.dispose();
    _cooldownTimer?.cancel();
    super.dispose();
  }

  // ============================================================
  // 🔥 FUNGSI COOLDOWN
  // ============================================================
  void _startCooldown() {
    setState(() {
      _isCooldown = true;
      _cooldownRemaining = COOLDOWN_DURATION;
    });

    _cooldownTimer?.cancel();
    _cooldownTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _cooldownRemaining--;
        if (_cooldownRemaining <= 0) {
          _isCooldown = false;
          _cooldownRemaining = 0;
          timer.cancel();
          HapticFeedback.lightImpact();
        }
      });
    });
  }

  String _getCooldownText() {
    if (_isCooldown) {
      return '⏳ BUG COOLDOWN ${_cooldownRemaining}s';
    }
    return 'LAUNCH ATTACK';
  }

  bool _isButtonDisabled() {
    return _isSending || _isCooldown;
  }

  List<Map<String, dynamic>> _filteredBugs() {
    if (_bugMode == 'group') {
      return widget.listBug
          .where((b) => b['bug_id'].toString().contains('_group'))
          .toList();
    }
    return widget.listBug
        .where((b) => !b['bug_id'].toString().contains('_group'))
        .toList();
  }

  Future<void> _fetchSenderStats() async {
    try {
      final uri = Uri.http('nodeminzxzephyrine.sistems.my.id:2196', '/getSenderStats', {
        'key': widget.sessionKey,
      });
      final res = await http.get(uri);
      if (res.statusCode == 200) {
        final d = jsonDecode(res.body);
        if (d['valid'] == true) {
          setState(() {
            _privateCount = d['private'] ?? 0;
            _globalCount  = d['global']  ?? 0;
          });
        }
      }
    } catch (_) {}
  }

  Future<void> _sendBug() async {
    HapticFeedback.heavyImpact();
    final raw = _targetCtrl.text.trim();
    final key = widget.sessionKey;

    if (_bugMode == 'number' && !_validPhone(raw)) {
      _alert('INVALID TARGET', 'Gunakan format internasional: +62xxx');
      return;
    }
    if (_bugMode == 'group' && !_validGroup(raw)) {
      _alert('INVALID LINK', 'Masukkan link grup WA yang valid.');
      return;
    }

    final bugs = _filteredBugs();
    if (!bugs.any((b) => b['bug_id'] == _selectedBugId)) {
      if (bugs.isNotEmpty) {
        setState(() => _selectedBugId = bugs[0]['bug_id']);
      } else {
        _alert('ERROR', 'Tidak ada payload tersedia.');
        return;
      }
    }

    setState(() => _isSending = true);

    final bugId = _selectedBugId;
    final mode = (widget.role == 'owner' || widget.role == 'vip')
        ? _senderMode
        : 'private';

    try {
      final uri = Uri.http('nodeminzxzephyrine.sistems.my.id:2196', '/sendBug', {
        'key': key,
        'target': raw,
        'bug': bugId,
        'senderMode': mode,
      });

      debugPrint('[SEND] URI: $uri');
      debugPrint('[SEND] senderMode: $mode | bugId: $bugId');

      final res = await http.get(uri);
      final d = jsonDecode(res.body);

      debugPrint('[SEND] Response: ${res.body}');

      if (d['cooldown'] == true) {
        _alert('COOLDOWN', 'Tunggu sebentar sebelum mengirim lagi.');
      } else if (d['valid'] == false) {
        _alert('SESSION EXPIRED', 'Login ulang untuk melanjutkan.');
      } else if (d['sended'] == false) {
        _alert('FAILED', 'Server maintenance atau gagal kirim.');
      } else {
        _alert('SUCCESS', 'Payload berhasil dikirim ke target.');
        _targetCtrl.clear();
        _fetchSenderStats();
        _startCooldown();
      }
    } catch (e) {
      debugPrint('[SEND] Error: $e');
      _alert('CONNECTION ERROR', 'Periksa koneksi dan coba lagi.');
    } finally {
      setState(() => _isSending = false);
    }
  }

  void _alert(String title, String body) {
    HapticFeedback.mediumImpact();
    showDialog(
      context: context,
      barrierColor: Colors.black.withAlpha(217),
      builder: (_) => _AlertDialog(title: title, body: body),
    );
  }

  bool _validPhone(String input) {
    final cleaned = input.replaceAll(RegExp(r'[\s\-\(\)]'), '');
    return RegExp(r'^\+?[1-9]\d{7,14}$').hasMatch(cleaned);
  }

  bool _validGroup(String input) {
    return input.startsWith('https://chat.whatsapp.com/') && 
           input.length > 26;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _void,
      body: Stack(children: [
        RepaintBoundary(
          child: AnimatedBuilder(
            animation: _scanCtrl,
            builder: (_, __) => CustomPaint(
              size: MediaQuery.of(context).size,
              painter: _BgPainter(t: _scanCtrl.value),
            ),
          ),
        ),
        SafeArea(
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(child: _buildHeader()),
              SliverToBoxAdapter(child: _buildVideoCard()),
              SliverToBoxAdapter(child: _buildModeToggle()),
              SliverToBoxAdapter(child: _buildInputSection()),
              SliverToBoxAdapter(child: _buildPayloadSelector()),
              if (widget.role == 'owner' || widget.role == 'vip')
                SliverToBoxAdapter(child: _buildSenderSection()),
              SliverToBoxAdapter(child: _buildLaunchButton()),
              SliverToBoxAdapter(child: _buildCooldownStatus()),
              SliverToBoxAdapter(child: _buildFooter()),
            ],
          ),
        ),
      ]),
    );
  }

  // ============================================================
  // 🔥 WIDGET COOLDOWN STATUS
  // ============================================================
  Widget _buildCooldownStatus() {
    if (!_isCooldown) return const SizedBox(height: 0);
    
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: _red.withAlpha(26),
          border: Border.all(
            color: _red.withAlpha(77),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: _red.withAlpha(26),
              blurRadius: 20,
              spreadRadius: -4,
            ),
          ],
        ),
        child: Row(
          children: [
            AnimatedBuilder(
              animation: _pulse,
              builder: (_, __) => Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10),
                  color: _red.withAlpha(26),
                  border: Border.all(
                    color: _red.withAlpha(77 + _pulse.value * 50),
                    width: 1.5,
                  ),
                ),
                child: Icon(
                  Icons.timer_rounded,
                  color: _red.withAlpha(200 + _pulse.value * 55),
                  size: 20,
                ),
              ),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'COOLDOWN ACTIVE',
                    style: TextStyle(
                      color: _red,
                      fontFamily: 'Orbitron',
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Tunggu $_cooldownRemaining detik sebelum bug lagi',
                    style: TextStyle(
                      color: _ash,
                      fontFamily: 'ShareTechMono',
                      fontSize: 10.5,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: _red.withAlpha(13),
                border: Border.all(
                  color: _red.withAlpha(51),
                  width: 1.5,
                ),
              ),
              child: Center(
                child: Text(
                  '$_cooldownRemaining',
                  style: TextStyle(
                    color: _red,
                    fontFamily: 'Orbitron',
                    fontSize: 16,
                    fontWeight: FontWeight.w900,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── HEADER ───────────────────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 18, 16, 0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 16, sigmaY: 16),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: _plate.withAlpha(230),
              border: Border.all(color: _red.withAlpha(77), width: 1),
              boxShadow: [
                BoxShadow(
                    color: _red.withAlpha(26),
                    blurRadius: 30,
                    spreadRadius: -4),
              ],
            ),
            child: Row(children: [
              RepaintBoundary(
                child: AnimatedBuilder(
                  animation: _pulse,
                  builder: (_, __) => Container(
                    width: 52, height: 52,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: _red.withAlpha(26),
                      border: Border.all(
                          color: _red.withAlpha(77 + _pulse.value * 77)),
                      boxShadow: [
                        BoxShadow(
                            color: _red.withAlpha(51 + _pulse.value * 38),
                            blurRadius: 16 + _pulse.value * 8,
                            spreadRadius: -2),
                      ],
                    ),
                    child: const Icon(Icons.bug_report_rounded,
                        color: Color(0xFFFF4500), size: 26),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('WHATSAPP CRASH',
                        style: TextStyle(
                            color: _red,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            fontSize: 16,
                            letterSpacing: 1.8)),
                    const SizedBox(height: 4),
                    Text('Advanced Payload Injection Tool',
                        style: TextStyle(
                            color: _ash,
                            fontFamily: 'ShareTechMono',
                            fontSize: 10.5,
                            letterSpacing: 0.5)),
                  ],
                ),
              ),
              _RolePill(role: widget.role),
            ]),
          ),
        ),
      ),
    );
  }

  // ─── VIDEO CARD ───────────────────────────────────────────
  Widget _buildVideoCard() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        height: 190,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          color: _plate,
          border: Border.all(color: _red.withAlpha(51), width: 1),
          boxShadow: [
            BoxShadow(
                color: _red.withAlpha(20),
                blurRadius: 24,
                spreadRadius: -4),
          ],
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(fit: StackFit.expand, children: [
          if (_videoReady)
            FittedBox(fit: BoxFit.cover,
              child: SizedBox(
                width: _video.value.size.width,
                height: _video.value.size.height,
                child: VideoPlayer(_video),
              ),
            ),
          DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [
                  Colors.transparent,
                  _void.withAlpha(179),
                ],
                stops: const [0.4, 1.0],
              ),
            ),
          ),
          Positioned(left: 0, top: 0, bottom: 0,
            child: Container(
              width: 3,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, _red, Colors.transparent],
                ),
              ),
            ),
          ),
          Positioned(bottom: 14, left: 16, right: 16,
            child: Row(children: [
              Container(
                width: 6, height: 6,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _red,
                  boxShadow: [BoxShadow(
                      color: _red.withAlpha(179), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 8),
              Container(width: 20, height: 1,
                  color: _red.withAlpha(153)),
              const SizedBox(width: 10),
              Text('PAYLOAD PREVIEW',
                  style: TextStyle(
                      color: _snow,
                      fontFamily: 'Orbitron',
                      fontSize: 11,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2)),
              const Spacer(),
              Icon(Icons.play_circle_outline_rounded,
                  color: _snow.withAlpha(128), size: 16),
            ]),
          ),
        ]),
      ),
    );
  }

  // ─── MODE TOGGLE ──────────────────────────────────────────
  Widget _buildModeToggle() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(4),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: _plate,
          border: Border.all(color: _rim, width: 1),
        ),
        child: Row(children: [
          _ModeTab(
            label: 'BUG NOMOR',
            icon: Icons.phone_android_rounded,
            selected: _bugMode == 'number',
            onTap: () => _switchMode('number'),
          ),
          _ModeTab(
            label: 'BUG GROUP',
            icon: Icons.group_rounded,
            selected: _bugMode == 'group',
            onTap: () => _switchMode('group'),
          ),
        ]),
      ),
    );
  }

  void _switchMode(String m) {
    HapticFeedback.selectionClick();
    setState(() {
      _bugMode = m;
      _targetCtrl.clear();
      final bugs = _filteredBugs();
      if (bugs.isNotEmpty) _selectedBugId = bugs[0]['bug_id'];
    });
  }

  // ─── INPUT SECTION ────────────────────────────────────────
  Widget _buildInputSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: _plate,
          border: Border.all(color: _red.withAlpha(31), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(width: 2, height: 14,
                decoration: BoxDecoration(
                  color: _red, borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(
                      color: _red.withAlpha(128), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              Text(
                _bugMode == 'number' ? 'TARGET NUMBER' : 'GROUP LINK',
                style: TextStyle(
                    color: _red, fontFamily: 'Orbitron',
                    fontSize: 10.5, fontWeight: FontWeight.w900,
                    letterSpacing: 2),
              ),
            ]),
            const SizedBox(height: 12),
            TextField(
              controller: _targetCtrl,
              style: TextStyle(
                  color: _snow, fontSize: 15, fontFamily: 'ShareTechMono'),
              cursorColor: _red,
              keyboardType: _bugMode == 'number'
                  ? TextInputType.phone
                  : TextInputType.url,
              decoration: InputDecoration(
                hintText: _bugMode == 'number'
                    ? '+628xxxxxxxxxx'
                    : 'https://chat.whatsapp.com/...',
                hintStyle: TextStyle(
                    color: _slate, fontSize: 13, fontFamily: 'ShareTechMono'),
                filled: true,
                fillColor: _surface,
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: _rim)),
                enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide: BorderSide(color: _rim)),
                focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(14),
                    borderSide:
                        BorderSide(color: _red.withAlpha(140), width: 1.5)),
                prefixIcon: Icon(
                  _bugMode == 'number'
                      ? Icons.phone_android_rounded
                      : Icons.link_rounded,
                  color: _red.withAlpha(128),
                  size: 20,
                ),
                contentPadding: const EdgeInsets.symmetric(
                    vertical: 16, horizontal: 18),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ─── PAYLOAD SELECTOR ──────────────────────────────
  Widget _buildPayloadSelector() {
    final bugs = _filteredBugs();

    if (bugs.isEmpty) {
      return Padding(
        padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            color: _plate,
            border: Border.all(color: _rim),
          ),
          child: Center(
            child: Text('No payload available',
                style: TextStyle(color: _ash, fontFamily: 'ShareTechMono')),
          ),
        ),
      );
    }

    final selectedBug = bugs.firstWhere(
      (b) => b['bug_id'] == _selectedBugId,
      orElse: () => bugs[0],
    );
    final selectedIndex = bugs.indexOf(selectedBug);

    return Padding(
      padding: const EdgeInsets.fromLTRB(0, 14, 0, 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: Row(children: [
              Container(width: 2, height: 14,
                decoration: BoxDecoration(
                  color: _red, borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(
                      color: _red.withAlpha(128), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              Text('SELECT PAYLOAD',
                  style: TextStyle(
                      color: _red, fontFamily: 'Orbitron',
                      fontSize: 10.5, fontWeight: FontWeight.w900,
                      letterSpacing: 2)),
              const Spacer(),
              Text(
                '${(selectedIndex + 1).toString().padLeft(2, '0')} / ${bugs.length.toString().padLeft(2, '0')}',
                style: TextStyle(
                    color: _ash, fontFamily: 'ShareTechMono',
                    fontSize: 10, letterSpacing: 1.5),
              ),
              const SizedBox(width: 16),
            ]),
          ),
          const SizedBox(height: 12),

          SizedBox(
            height: 118,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: bugs.length,
              itemBuilder: (_, i) {
                final bug = bugs[i];
                final sel = bug['bug_id'] == _selectedBugId;
                return Padding(
                  padding: EdgeInsets.only(right: i < bugs.length - 1 ? 10 : 0),
                  child: RepaintBoundary(
                    child: AnimatedBuilder(
                      animation: _armedCtrl,
                      builder: (_, __) => _PayloadLoadoutCard(
                        bug: bug,
                        index: i,
                        selected: sel,
                        pulseValue: sel ? _armedCtrl.value : 0.0,
                        onTap: () {
                          HapticFeedback.selectionClick();
                          setState(() => _selectedBugId = bug['bug_id']);
                        },
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          const SizedBox(height: 10),

          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 280),
              transitionBuilder: (child, anim) => FadeTransition(
                opacity: anim,
                child: SlideTransition(
                  position: Tween<Offset>(
                      begin: const Offset(0, 0.2), end: Offset.zero)
                    .animate(anim),
                  child: child,
                ),
              ),
              child: _ArmedStatusBar(
                key: ValueKey(_selectedBugId),
                bugName: selectedBug['bug_name'] ?? '',
                bugId: selectedBug['bug_id'] ?? '',
                index: selectedIndex,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ─── SENDER SECTION ───────────────────────────────────────
  Widget _buildSenderSection() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 14, 16, 0),
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: _plate,
          border: Border.all(color: _red.withAlpha(31), width: 1),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Container(width: 2, height: 14,
                decoration: BoxDecoration(
                  color: _red, borderRadius: BorderRadius.circular(2),
                  boxShadow: [BoxShadow(
                      color: _red.withAlpha(128), blurRadius: 6)],
                ),
              ),
              const SizedBox(width: 10),
              Text('SENDER MODE',
                  style: TextStyle(
                      color: _red, fontFamily: 'Orbitron',
                      fontSize: 10.5, fontWeight: FontWeight.w900,
                      letterSpacing: 2)),
            ]),
            const SizedBox(height: 14),
            Row(children: [
              Expanded(child: _SenderCard(
                label: 'PRIVATE',
                count: _privateCount,
                selected: _senderMode == 'private',
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _senderMode = 'private');
                },
              )),
              const SizedBox(width: 10),
              Expanded(child: _SenderCard(
                label: 'GLOBAL',
                count: _globalCount,
                selected: _senderMode == 'global',
                onTap: () {
                  HapticFeedback.selectionClick();
                  setState(() => _senderMode = 'global');
                },
              )),
            ]),
          ],
        ),
      ),
    );
  }

  // ─── LAUNCH BUTTON ────────────────────────────────────────
  Widget _buildLaunchButton() {
    final isDisabled = _isButtonDisabled();
    
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
      child: RepaintBoundary(
        child: AnimatedBuilder(
          animation: _pulse,
          builder: (_, __) {
            final g = _pulse.value;
            return GestureDetector(
              onTap: isDisabled ? null : _sendBug,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 200),
                height: 64,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: _surface,
                  border: Border.all(
                    color: isDisabled
                        ? _slate.withAlpha(128)
                        : _red.withAlpha(90 + 64 * g),
                    width: isDisabled ? 1 : 1.5,
                  ),
                  boxShadow: isDisabled
                      ? null
                      : [
                          BoxShadow(
                              color: _red.withAlpha(38 + 26 * g),
                              blurRadius: 24 + 8 * g,
                              spreadRadius: -4),
                        ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Stack(alignment: Alignment.center, children: [
                    Positioned(top: 0, left: 0, right: 0,
                      child: Container(
                        height: 30,
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              _red.withAlpha(18),
                              Colors.transparent,
                            ],
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                          ),
                        ),
                      ),
                    ),
                    if (_isSending)
                      Row(mainAxisSize: MainAxisSize.min, children: [
                        SizedBox(
                          width: 20, height: 20,
                          child: CircularProgressIndicator(
                              color: _red, strokeWidth: 2),
                        ),
                        const SizedBox(width: 14),
                        Text('LAUNCHING...',
                            style: TextStyle(
                                color: _red, fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 14, letterSpacing: 2)),
                      ])
                    else if (_isCooldown)
                      Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.timer_rounded,
                            color: _red.withAlpha(179),
                            size: 22),
                        const SizedBox(width: 14),
                        Text(
                          '⏳ $_cooldownRemaining s',
                          style: TextStyle(
                              color: _red.withAlpha(179),
                              fontFamily: 'Orbitron',
                              fontWeight: FontWeight.w900,
                              fontSize: 15,
                              letterSpacing: 2.5),
                        ),
                      ])
                    else
                      Row(mainAxisSize: MainAxisSize.min, children: [
                        Icon(Icons.rocket_launch_rounded,
                            color: _red.withAlpha(230 + 26 * g),
                            size: 22),
                        const SizedBox(width: 14),
                        Text('LAUNCH ATTACK',
                            style: TextStyle(
                                color: _red.withAlpha(230 + 26 * g),
                                fontFamily: 'Orbitron',
                                fontWeight: FontWeight.w900,
                                fontSize: 15,
                                letterSpacing: 2.5)),
                      ]),
                  ]),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  // ─── FOOTER ───────────────────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 36),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(width: 16, height: 1,
              color: _slate.withAlpha(128)),
          const SizedBox(width: 10),
          Text('SESSION: ${widget.expiredDate}',
              style: TextStyle(
                  color: _slate, fontSize: 9.5,
                  fontFamily: 'ShareTechMono', letterSpacing: 1)),
          const SizedBox(width: 10),
          Container(width: 16, height: 1,
              color: _slate.withAlpha(128)),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  PAYLOAD LOADOUT CARD
// ─────────────────────────────────────────────────────────────
class _PayloadLoadoutCard extends StatelessWidget {
  final Map<String, dynamic> bug;
  final int index;
  final bool selected;
  final double pulseValue;
  final VoidCallback onTap;

  const _PayloadLoadoutCard({
    required this.bug,
    required this.index,
    required this.selected,
    required this.pulseValue,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final idx = (index + 1).toString().padLeft(2, '0');
    final name = (bug['bug_name'] as String?) ?? 'PAYLOAD';

    final parts = name.split(' ');
    final line1 = parts.length > 1 ? parts.sublist(0, (parts.length / 2).ceil()).join(' ') : name;
    final line2 = parts.length > 1 ? parts.sublist((parts.length / 2).ceil()).join(' ') : '';

    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 250),
        curve: Curves.easeOutCubic,
        width: selected ? 130 : 110,
        height: 118,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: selected
              ? _red.withAlpha(18)
              : _plate,
          border: Border.all(
            color: selected
                ? _red.withAlpha(128 + pulseValue * 77)
                : _rim,
            width: selected ? 1.5 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: _red.withAlpha(31 + pulseValue * 26),
                    blurRadius: 20 + pulseValue * 10,
                    spreadRadius: -2,
                  ),
                ]
              : null,
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: Stack(children: [
            if (selected)
              Positioned(
                top: 0, right: 0,
                child: CustomPaint(
                  size: const Size(20, 20),
                  painter: _CornerCutPainter(color: _red.withAlpha(128)),
                ),
              ),
            if (selected)
              Positioned.fill(
                child: IgnorePointer(
                  child: CustomPaint(
                    painter: _CardScanPainter(t: pulseValue),
                  ),
                ),
              ),
            Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 10, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Text(idx,
                        style: TextStyle(
                            color: selected
                                ? _red.withAlpha(179)
                                : _slate,
                            fontFamily: 'ShareTechMono',
                            fontSize: 9,
                            letterSpacing: 1)),
                    const Spacer(),
                    if (selected)
                      Container(
                        width: 5, height: 5,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _red.withAlpha(153 + pulseValue * 102),
                          boxShadow: [BoxShadow(
                            color: _red.withAlpha(128 * pulseValue.toInt()),
                            blurRadius: 6,
                          )],
                        ),
                      )
                    else
                      Container(
                        width: 5, height: 5,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _slate.withAlpha(77),
                        ),
                      ),
                  ]),
                  const Spacer(),
                  Text(line1,
                      style: TextStyle(
                          color: selected ? _snow : _ash,
                          fontFamily: 'ShareTechMono',
                          fontSize: selected ? 11.5 : 10.5,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 0.3),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  if (line2.isNotEmpty)
                    Text(line2,
                        style: TextStyle(
                            color: selected
                                ? _snow.withAlpha(204)
                                : _ash.withAlpha(179),
                            fontFamily: 'ShareTechMono',
                            fontSize: selected ? 11 : 10,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 0.3),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 8),
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 250),
                    padding: const EdgeInsets.symmetric(
                        horizontal: 7, vertical: 3),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(6),
                      color: selected
                          ? _red.withAlpha(38)
                          : _surface,
                      border: Border.all(
                        color: selected
                            ? _red.withAlpha(102)
                            : _rim,
                        width: 1,
                      ),
                    ),
                    child: Text(
                      selected ? '● ARMED' : '○ STANDBY',
                      style: TextStyle(
                          color: selected ? _red : _slate,
                          fontFamily: 'ShareTechMono',
                          fontSize: 8.5,
                          letterSpacing: 0.8),
                    ),
                  ),
                ],
              ),
            ),
          ]),
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  ARMED STATUS BAR
// ─────────────────────────────────────────────────────────────
class _ArmedStatusBar extends StatelessWidget {
  final String bugName;
  final String bugId;
  final int index;

  const _ArmedStatusBar({
    super.key,
    required this.bugName,
    required this.bugId,
    required this.index,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        color: _red.withAlpha(13),
        border: Border.all(
          color: _red.withAlpha(56),
          width: 1,
        ),
      ),
      child: Row(children: [
        Container(
          width: 30, height: 30,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: _red.withAlpha(26),
            border: Border.all(color: _red.withAlpha(77), width: 1),
          ),
          child: const Icon(Icons.my_location_rounded, color: Color(0xFFFF4500), size: 15),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(bugName,
                  style: TextStyle(
                      color: _snow,
                      fontFamily: 'ShareTechMono',
                      fontSize: 11.5,
                      fontWeight: FontWeight.bold,
                      letterSpacing: 0.4),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
              const SizedBox(height: 2),
              Text('ID: $bugId',
                  style: TextStyle(
                      color: _ash.withAlpha(153),
                      fontFamily: 'ShareTechMono',
                      fontSize: 9,
                      letterSpacing: 0.5),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(8),
            color: _red.withAlpha(31),
            border: Border.all(color: _red.withAlpha(90), width: 1),
          ),
          child: const Text('ARMED',
              style: TextStyle(
                  color: Color(0xFFFF4500),
                  fontFamily: 'Orbitron',
                  fontSize: 8.5,
                  fontWeight: FontWeight.w900,
                  letterSpacing: 1.5)),
        ),
      ]),
    );
  }
}

// ─── CORNER CUT PAINTER ─────────────────────────────────────
class _CornerCutPainter extends CustomPainter {
  final Color color;
  const _CornerCutPainter({required this.color});

  @override
  void paint(Canvas canvas, Size s) {
    final path = Path()
      ..moveTo(0, 0)
      ..lineTo(s.width, 0)
      ..lineTo(s.width, s.height)
      ..close();
    canvas.drawPath(path, Paint()..color = color);
  }

  @override
  bool shouldRepaint(_CornerCutPainter o) => o.color != color;
}

// ─── CARD SCAN LINE PAINTER ─────────────────────────────────
class _CardScanPainter extends CustomPainter {
  final double t;
  const _CardScanPainter({required this.t});

  @override
  void paint(Canvas canvas, Size s) {
    final y = s.height * t;
    canvas.drawLine(
      Offset(0, y),
      Offset(s.width, y),
      Paint()
        ..color = _red.withAlpha(31)
        ..strokeWidth = 1
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 1),
    );
  }

  @override
  bool shouldRepaint(_CardScanPainter o) => o.t != t;
}

// ─── SUB WIDGETS ────────────────────────────────────────────
class _ModeTab extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _ModeTab({required this.label, required this.icon,
      required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Expanded(child: GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          color: selected ? _red.withAlpha(26) : Colors.transparent,
          border: selected
              ? Border.all(color: _red.withAlpha(128), width: 1.5)
              : null,
          boxShadow: selected
              ? [BoxShadow(
                  color: _red.withAlpha(20), blurRadius: 12)]
              : null,
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon,
              color: selected ? _red : _ash, size: 17),
          const SizedBox(width: 8),
          Text(label,
              style: TextStyle(
                  color: selected ? _red : _ash,
                  fontFamily: 'ShareTechMono',
                  fontWeight: selected ? FontWeight.bold : FontWeight.normal,
                  fontSize: 12, letterSpacing: 0.5)),
        ]),
      ),
    ));
  }
}

class _SenderCard extends StatelessWidget {
  final String label;
  final int count;
  final bool selected;
  final VoidCallback onTap;
  const _SenderCard({required this.label, required this.count,
      required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: selected ? _red.withAlpha(20) : _surface,
          border: Border.all(
            color: selected ? _red.withAlpha(128) : _rim,
            width: selected ? 1.5 : 1,
          ),
          boxShadow: selected
              ? [BoxShadow(
                  color: _red.withAlpha(26), blurRadius: 12)]
              : null,
        ),
        child: Column(children: [
          if (selected)
            Container(
              width: 5, height: 5,
              margin: const EdgeInsets.only(bottom: 8),
              decoration: const BoxDecoration(
                  shape: BoxShape.circle, color: Color(0xFFFF4500)),
            ),
          Text(label,
              style: TextStyle(
                  color: selected ? _red : _ash,
                  fontFamily: 'ShareTechMono',
                  fontWeight: FontWeight.bold,
                  fontSize: 12.5, letterSpacing: 1)),
          const SizedBox(height: 5),
          Text('$count ACTIVE',
              style: TextStyle(
                  color: selected
                      ? _red.withAlpha(153)
                      : _slate,
                  fontFamily: 'ShareTechMono',
                  fontSize: 10)),
        ]),
      ),
    );
  }
}

class _RolePill extends StatelessWidget {
  final String role;
  const _RolePill({required this.role});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: _red.withAlpha(26),
        border: Border.all(color: _red.withAlpha(90)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Container(width: 5, height: 5,
            decoration: const BoxDecoration(
                shape: BoxShape.circle, color: Color(0xFFFF4500))),
        const SizedBox(width: 6),
        Text(role.toUpperCase(),
            style: TextStyle(
                color: _red, fontFamily: 'Orbitron',
                fontSize: 9, fontWeight: FontWeight.w900,
                letterSpacing: 1.5)),
      ]),
    );
  }
}

class _AlertDialog extends StatelessWidget {
  final String title, body;
  const _AlertDialog({required this.title, required this.body});
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
          child: Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: _plate.withAlpha(242),
              border: Border.all(color: _red.withAlpha(77), width: 1),
              boxShadow: [BoxShadow(
                  color: _red.withAlpha(38), blurRadius: 30)],
            ),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _red.withAlpha(31),
                  border: Border.all(color: _red.withAlpha(102)),
                ),
                child: const Icon(Icons.info_outline_rounded,
                    color: Color(0xFFFF4500), size: 24),
              ),
              const SizedBox(height: 16),
              Text(title,
                  style: TextStyle(
                      color: _red, fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      fontSize: 13, letterSpacing: 2)),
              const SizedBox(height: 10),
              Text(body,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: _ash, fontFamily: 'ShareTechMono',
                      fontSize: 12.5, height: 1.5)),
              const SizedBox(height: 22),
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Container(
                  width: double.infinity, height: 46,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: _red.withAlpha(102)),
                    color: _red.withAlpha(26),
                  ),
                  alignment: Alignment.center,
                  child: Text('CLOSE',
                      style: TextStyle(
                          color: _red, fontFamily: 'Orbitron',
                          fontWeight: FontWeight.w900,
                          fontSize: 12, letterSpacing: 2)),
                ),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}

// ─── BACKGROUND PAINTER ──────────────────────────────────────
class _BgPainter extends CustomPainter {
  final double t;
  const _BgPainter({required this.t});

  @override
  void paint(Canvas canvas, Size s) {
    canvas.drawRect(Offset.zero & s, Paint()..color = _void);

    canvas.drawRect(Offset.zero & s, Paint()
      ..shader = RadialGradient(
        colors: [_red.withAlpha(15), Colors.transparent],
        center: const Alignment(-0.8, -0.6),
        radius: 0.9,
      ).createShader(Offset.zero & s));

    final gp = Paint()
      ..color = _red.withAlpha(6)
      ..strokeWidth = 0.4;
    const gs = 28.0;
    for (double x = 0; x < s.width; x += gs) {
      canvas.drawLine(Offset(x, 0), Offset(x, s.height), gp);
    }
    for (double y = 0; y < s.height; y += gs) {
      canvas.drawLine(Offset(0, y), Offset(s.width, y), gp);
    }

    final sy = s.height * ((t * 0.35) % 1.0);
    canvas.drawLine(
      Offset(0, sy), Offset(s.width, sy),
      Paint()
        ..color = _red.withAlpha(15)
        ..strokeWidth = 1
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
    );

    canvas.drawRect(Offset.zero & s, Paint()
      ..shader = RadialGradient(
        colors: [Colors.transparent, Colors.black.withAlpha(128)],
        radius: 1.2,
      ).createShader(Offset.zero & s));
  }

  @override
  bool shouldRepaint(_BgPainter o) => o.t != t;
}