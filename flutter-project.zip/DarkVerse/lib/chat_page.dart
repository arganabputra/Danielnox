import 'package:flutter/material.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'dart:convert';
import 'package:http/http.dart' as http;

class ChatPage extends StatefulWidget {
  final String username;

  const ChatPage({Key? key, required this.username}) : super(key: key);

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  late IO.Socket socket;
  List<String> onlineUsers = [];
  String? selectedUser;
  List<Message> messages = [];
  TextEditingController messageController = TextEditingController();
  bool isTyping = false;
  bool isConnected = false;

  @override
  void initState() {
    super.initState();
    connectSocket();
  }

  void connectSocket() {
    socket = IO.io('http://nodeminzxzephyrine.sistems.my.id:2196', <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': true,
    });

    socket.onConnect((_) {
      print('Connected to server');
      setState(() {
        isConnected = true;
      });
      socket.emit('register', widget.username);
    });

    socket.on('user_list', (data) {
      setState(() {
        onlineUsers = List<String>.from(data);
        onlineUsers.remove(widget.username);
      });
    });

    socket.on('user_online', (username) {
      if (!onlineUsers.contains(username) && username != widget.username) {
        setState(() {
          onlineUsers.add(username);
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('$username is online')),
        );
      }
    });

    socket.on('user_offline', (username) {
      setState(() {
        onlineUsers.remove(username);
        if (selectedUser == username) {
          selectedUser = null;
          messages.clear();
        }
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$username is offline')),
      );
    });

    socket.on('private_message', (data) {
      setState(() {
        messages.add(Message.fromJson(data));
      });
    });

    socket.on('message_sent', (data) {
      setState(() {
        messages.add(Message.fromJson(data));
      });
    });

    socket.on('user_typing', (data) {
      setState(() {
        isTyping = true;
      });
      Future.delayed(const Duration(seconds: 2), () {
        setState(() {
          isTyping = false;
        });
      });
    });

    socket.onDisconnect((_) {
      setState(() {
        isConnected = false;
      });
    });

    socket.onError((error) {
      print('Socket error: $error');
    });
  }

  void sendMessage() {
    if (messageController.text.isEmpty || selectedUser == null) return;

    final message = messageController.text;
    socket.emit('send_private_message', {
      'to': selectedUser,
      'message': message,
      'from': widget.username,
    });

    messageController.clear();
  }

  void loadChatHistory(String username) async {
    try {
      final response = await http.get(
        Uri.parse('http://nodeminzxzephyrine.sistems.my.id:2196/api/messages/$username'),
      );
      
      if (response.statusCode == 200) {
        List<dynamic> data = json.decode(response.body);
        setState(() {
          messages = data
              .where((msg) =>
                  msg['from'] == widget.username && msg['to'] == username ||
                  msg['from'] == username && msg['to'] == widget.username)
              .map((msg) => Message.fromJson(msg))
              .toList();
        });
      }
    } catch (e) {
      print('Error loading chat history: $e');
    }
  }

  void selectUser(String username) {
    setState(() {
      selectedUser = username;
      messages.clear();
    });
    loadChatHistory(username);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chat App'),
        backgroundColor: Colors.green,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () {
              socket.emit('register', widget.username);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Refreshed!')),
              );
            },
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Icon(
                  isConnected ? Icons.circle : Icons.circle_outlined,
                  color: isConnected ? Colors.green : Colors.red,
                  size: 12,
                ),
                const SizedBox(width: 4),
                Text(
                  isConnected ? 'Online' : 'Offline',
                  style: const TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
      body: Row(
        children: [
          // Left Panel - User List
          SizedBox(
            width: 300,
            child: Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade100,
                    border: Border(
                      bottom: BorderSide(color: Colors.grey.shade300),
                    ),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.person),
                      const SizedBox(width: 8),
                      Text(
                        'Online Users (${onlineUsers.length})',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: onlineUsers.isEmpty
                      ? const Center(
                          child: Text(
                            'No online users',
                            style: TextStyle(color: Colors.grey),
                          ),
                        )
                      : ListView.builder(
                          itemCount: onlineUsers.length,
                          itemBuilder: (context, index) {
                            final user = onlineUsers[index];
                            final isSelected = selectedUser == user;
                            return ListTile(
                              selected: isSelected,
                              selectedTileColor: Colors.green.shade50,
                              leading: CircleAvatar(
                                backgroundColor: isSelected
                                    ? Colors.green
                                    : Colors.grey.shade300,
                                child: Text(
                                  user[0].toUpperCase(),
                                  style: TextStyle(
                                    color: isSelected
                                        ? Colors.white
                                        : Colors.grey.shade700,
                                  ),
                                ),
                              ),
                              title: Text(
                                user,
                                style: TextStyle(
                                  fontWeight: isSelected
                                      ? FontWeight.bold
                                      : FontWeight.normal,
                                ),
                              ),
                              trailing: const Icon(
                                Icons.circle,
                                color: Colors.green,
                                size: 10,
                              ),
                              onTap: () => selectUser(user),
                            );
                          },
                        ),
                ),
              ],
            ),
          ),
          
          // Right Panel - Chat Area
          Expanded(
            child: selectedUser == null
                ? const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.chat_bubble_outline,
                          size: 64,
                          color: Colors.grey,
                        ),
                        SizedBox(height: 16),
                        Text(
                          'Select a user to start chatting',
                          style: TextStyle(
                            color: Colors.grey,
                            fontSize: 16,
                          ),
                        ),
                      ],
                    ),
                  )
                : Column(
                    children: [
                      // Chat Header
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.green.shade50,
                          border: Border(
                            bottom: BorderSide(color: Colors.grey.shade300),
                          ),
                        ),
                        child: Row(
                          children: [
                            CircleAvatar(
                              backgroundColor: Colors.green,
                              child: Text(
                                selectedUser![0].toUpperCase(),
                                style: const TextStyle(color: Colors.white),
                              ),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    selectedUser!,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    ),
                                  ),
                                  if (isTyping)
                                    const Text(
                                      'Typing...',
                                      style: TextStyle(
                                        color: Colors.green,
                                        fontSize: 12,
                                        fontStyle: FontStyle.italic,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      
                      // Messages List
                      Expanded(
                        child: messages.isEmpty
                            ? const Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.message_outlined,
                                      size: 48,
                                      color: Colors.grey,
                                    ),
                                    SizedBox(height: 12),
                                    Text(
                                      'No messages yet',
                                      style: TextStyle(
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : ListView.builder(
                                reverse: true,
                                padding: const EdgeInsets.all(16),
                                itemCount: messages.length,
                                itemBuilder: (context, index) {
                                  final message = messages[messages.length - 1 - index];
                                  final isMe = message.from == widget.username;
                                  
                                  return Align(
                                    alignment: isMe
                                        ? Alignment.centerRight
                                        : Alignment.centerLeft,
                                    child: Container(
                                      margin: EdgeInsets.only(
                                        bottom: 8,
                                        left: isMe ? 50 : 0,
                                        right: isMe ? 0 : 50,
                                      ),
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 16,
                                        vertical: 10,
                                      ),
                                      decoration: BoxDecoration(
                                        color: isMe
                                            ? Colors.green
                                            : Colors.grey.shade200,
                                        borderRadius: BorderRadius.circular(12),
                                      ),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(
                                            message.message,
                                            style: TextStyle(
                                              color: isMe
                                                  ? Colors.white
                                                  : Colors.black,
                                            ),
                                          ),
                                          const SizedBox(height: 4),
                                          Text(
                                            _formatTime(message.timestamp),
                                            style: TextStyle(
                                              fontSize: 10,
                                              color: isMe
                                                  ? Colors.white70
                                                  : Colors.grey.shade600,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );
                                },
                              ),
                      ),
                      
                      // Message Input
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.grey.shade50,
                          border: Border(
                            top: BorderSide(color: Colors.grey.shade300),
                          ),
                        ),
                        child: Row(
                          children: [
                            Expanded(
                              child: TextField(
                                controller: messageController,
                                decoration: InputDecoration(
                                  hintText: 'Type a message...',
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(30),
                                  ),
                                  contentPadding: const EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 8,
                                  ),
                                ),
                                onChanged: (text) {
                                  if (text.isNotEmpty && selectedUser != null) {
                                    socket.emit('typing', {
                                      'to': selectedUser,
                                      'from': widget.username,
                                    });
                                  }
                                },
                              ),
                            ),
                            const SizedBox(width: 8),
                            CircleAvatar(
                              backgroundColor: Colors.green,
                              child: IconButton(
                                icon: const Icon(
                                  Icons.send,
                                  color: Colors.white,
                                ),
                                onPressed: sendMessage,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
          ),
        ],
      ),
    );
  }

  String _formatTime(String timestamp) {
    try {
      final date = DateTime.parse(timestamp);
      return '${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return '';
    }
  }

  @override
  void dispose() {
    socket.disconnect();
    messageController.dispose();
    super.dispose();
  }
}

class Message {
  final String from;
  final String to;
  final String message;
  final String timestamp;
  final String type;

  const Message({
    required this.from,
    required this.to,
    required this.message,
    required this.timestamp,
    required this.type,
  });

  factory Message.fromJson(Map<String, dynamic> json) {
    return Message(
      from: json['from'] ?? '',
      to: json['to'] ?? '',
      message: json['message'] ?? '',
      timestamp: json['timestamp'] ?? '',
      type: json['type'] ?? 'private',
    );
  }
}