/*

   BASE INI FREE NO SALE
   JIKA MENEMUKAN YANG MENJUAL BELIKAN
   HARAP LAPORKAN KE 
   DEVELOPER : https://t.me/angkasanybobo
   CHANNEL : https://t.me/angkasalagibobo
   ROOMPUBLIC : https://t.me/roomangkasa
   KEBUTUHAN HOSTING : https://angkasalagijajan.vercel.app

*/

module.exports = {
  VERSION: "0.6",
  TOKEN: "8484552910:AAFjOB0fJE8qTjkt7COpCPPs_dZvC3Mny2Q",
  OWNER: 6736986837,
  NAMA_OWNER: "ANGKASALAGIBOBO",
  USERNAME_BOT: "angkasanyobabot",
  NAMA_BOT: "BOT GACHA ANGKASA",
  APIKEY: "ANGKASALAGIBOBO",
  CHANNEL_ID: "-1003096799018",
  CHANNEL_LINK: "https://t.me/angkasalagibobo",
  GETCHANNELID_USERNAME: "@angkasalagibobo"
  
};

/*

   GROUP_ID SESUAI KAN DENGAN GROUP MASING MASING

*/