// lib/config.dart
// Configuration file - Hardcoded API BaseUrl

const String BASE_URL = "http://panelbinbokep.kalzhost.web.id:3536";

// API Endpoints
class ApiEndpoints {
  static const String login = "$BASE_URL/login";
  static const String register = "$BASE_URL/register";
  static const String getUserInfo = "$BASE_URL/getUserInfo";
  static const String getSenderStats = "$BASE_URL/getSenderStats";
  static const String sendBug = "$BASE_URL/sendBug";
  static const String myServer = "$BASE_URL/myServer";
  static const String addServer = "$BASE_URL/addServer";
  static const String delServer = "$BASE_URL/delServer";
  static const String listUsers = "$BASE_URL/listUsers";
  static const String deleteUser = "$BASE_URL/deleteUser";
  static const String userAdd = "$BASE_URL/userAdd";
  static const String editUser = "$BASE_URL/editUser";
  static const String mySender = "$BASE_URL/mySender";
  static const String getPairing = "$BASE_URL/getPairing";
  static const String deleteSender = "$BASE_URL/deleteSender";
  static const String killWifi = "$BASE_URL/killWifi";
}
