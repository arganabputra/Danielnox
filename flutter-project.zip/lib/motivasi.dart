import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';

class MotivationPage extends StatefulWidget {
  const MotivationPage({super.key});

  @override
  State<MotivationPage> createState() => _MotivationPageState();
}

class _MotivationPageState extends State<MotivationPage>
    with TickerProviderStateMixin {
  // ─── PALETTE ──────────────────────────────────────────────
  static const Color _bg     = Color(0xFF040B14);
  static const Color _red    = Color(0xFFFF0040);
  static const Color _redLow = Color(0x22FF0040);
  static const Color _white  = Color(0xFFF2F2F2);
  static const Color _muted  = Color(0xFF4D7C9E);
  static const Color _dim    = Color(0xFF13283C);
  static const Color _dimMid = Color(0xFF081420);

  final AudioPlayer _audioPlayer = AudioPlayer();
  final Random _random = Random();

  // ─── QUOTES ───────────────────────────────────────────────
  final List<Map<String, String>> _quotes = [
    // ── Orisinal ──
    {
      "text": "Berhenti berharap pada orang yang bahkan\ntak peduli kamu ada.",
      "author": "",
      "tag": "WIANZ",
    },
    {
      "text": "Kamu lelah, tapi menyerah bukan pilihan.\nItu harga dari mimpimu.",
      "author": "",
      "tag": "BERTAHAN",
    },
    {
      "text": "Diam-diam kamu bertahan,\nmeski hatimu sudah remuk berkali-kali.",
      "author": "",
      "tag": "KUAT",
    },
    {
      "text": "Mereka hanya melihat hasil, bukan proses\nberdarah yang kamu lewati.",
      "author": "",
      "tag": "PROSES",
    },
    {
      "text": "Tak apa jika hari ini kamu kalah,\nbesok masih ada kesempatan untuk menang.",
      "author": "",
      "tag": "BANGKIT",
    },
    {
      "text": "Kadang, orang yang paling terlihat bahagia\njustru paling sering menangis sendiri.",
      "author": "",
      "tag": "REALITA",
    },
    {
      "text": "Mimpimu besar, makanya ujiannya juga besar.\nBertahanlah.",
      "author": "",
      "tag": "BY WIANZ",
    },
    {
      "text": "Kamu tidak gagal, kamu hanya menemukan\ncara yang belum berhasil.",
      "author": "",
      "tag": "WIANZ",
    },
    {
      "text": "Hidup ini keras, tapi kamu\njauh lebih keras dari itu.",
      "author": "",
      "tag": "KUAT",
    },
    {
      "text": "Rasa sakit ini sementara, tapi kebanggaan\nsetelah melewatinya akan abadi.",
      "author": "",
      "tag": "SAKIT",
    },
    {
      "text": "Kamu layak bahagia,\nmeski dunia seolah berkata lain.",
      "author": "",
      "tag": "LAYAK",
    },
    {
      "text": "Sabar. Prosesmu tidak akan\nmengkhianati hasil.",
      "author": "",
      "tag": "PROSES",
    },
    {
      "text": "Jangan bandingkan perjalananmu dengan orang lain,\nsetiap orang punya waktunya sendiri.",
      "author": "",
      "tag": "PERJALANAN",
    },
    {
      "text": "Air mata malam ini akan menjadi\nkekuatan esok pagi.",
      "author": "",
      "tag": "MALAM",
    },
    {
      "text": "Bekerja keras dalam diam,\nbiarkan kesuksesanmu yang berbicara.",
      "author": "",
      "tag": "DIAM",
    },
    {
      "text": "Ketika kamu ingin menyerah,\ningatlah alasan mengapa kamu mulai.",
      "author": "",
      "tag": "ALASAN",
    },
    {
      "text": "Tidak apa-apa istirahat,\nasal jangan berhenti sepenuhnya.",
      "author": "",
      "tag": "ISTIRAHAT",
    },
    {
      "text": "Senyummu menyembunyikan ribuan luka\nyang tak seorang pun tahu.",
      "author": "",
      "tag": "TERSEMBUNYI",
    },
    {
      "text": "Jadilah versi terbaik dari dirimu,\nbukan tiruan orang lain.",
      "author": "",
      "tag": "DIRI",
    },
    {
      "text": "Percayalah pada dirimu sendiri\nketika tidak ada yang percaya.",
      "author": "",
      "tag": "PERCAYA",
    },

    // ── Filosofi & Genius ──
    {
      "text": "Hiduplah seolah kamu akan mati besok.\nBelajarlah seolah kamu akan hidup selamanya.",
      "author": "Mahatma Gandhi",
      "tag": "HIDUP",
    },
    {
      "text": "Imajinasi lebih penting dari pengetahuan.\nPengetahuan terbatas, imajinasi melingkupi dunia.",
      "author": "Albert Einstein",
      "tag": "GENIUS",
    },
    {
      "text": "Di tengah kesulitan,\nsitulah kesempatan tersembunyi.",
      "author": "Albert Einstein",
      "tag": "GENIUS",
    },
    {
      "text": "Orang yang tidak pernah melakukan kesalahan\nadalah orang yang tidak pernah mencoba hal baru.",
      "author": "Albert Einstein",
      "tag": "GENIUS",
    },
    {
      "text": "Apa yang tidak membunuhku\nhanya membuatku lebih kuat.",
      "author": "Friedrich Nietzsche",
      "tag": "FILSAFAT",
    },
    {
      "text": "Tanpa musik, hidup ini\nakan menjadi sebuah kesalahan.",
      "author": "Friedrich Nietzsche",
      "tag": "FILSAFAT",
    },
    {
      "text": "Satu-satunya cara untuk keluar dari labirin penderitaan\nadalah dengan memaafkan.",
      "author": "John Green",
      "tag": "LUKA",
    },
    {
      "text": "Keberanian bukan berarti tidak takut.\nKeberanian adalah melangkah meskipun takut.",
      "author": "C.S. Lewis",
      "tag": "BERANI",
    },
    {
      "text": "Kamu tidak bisa kembali dan mengubah awal cerita,\ntapi kamu bisa mulai dari sekarang dan mengubah akhirnya.",
      "author": "C.S. Lewis",
      "tag": "WAKTU",
    },
    {
      "text": "Dua hal yang tak terbatas: alam semesta\ndan kebodohan manusia — tapi aku tidak yakin tentang alam semesta.",
      "author": "Albert Einstein",
      "tag": "GENIUS",
    },
    {
      "text": "Kesuksesan adalah kemampuan untuk melangkah\ndari satu kegagalan ke kegagalan berikutnya tanpa kehilangan semangat.",
      "author": "Winston Churchill",
      "tag": "SUKSES",
    },
    {
      "text": "Jika kamu sedang melewati neraka,\nteruslah berjalan.",
      "author": "Winston Churchill",
      "tag": "BERTAHAN",
    },
    {
      "text": "Anda tidak bisa menghubungkan titik-titik dengan melihat ke depan;\nhanya bisa dengan menoleh ke belakang.",
      "author": "Steve Jobs",
      "tag": "PROSES",
    },
    {
      "text": "Waktu kamu terbatas, jadi jangan sia-siakan\ndengan menjalani hidup orang lain.",
      "author": "Steve Jobs",
      "tag": "WAKTU",
    },
    {
      "text": "Tetap lapar, tetap bodoh.",
      "author": "Steve Jobs",
      "tag": "HUNGER",
    },
    {
      "text": "Jika kamu tidak bisa terbang maka larilah,\njika tidak bisa lari maka berjalanlah.",
      "author": "Martin Luther King Jr.",
      "tag": "MAJU",
    },
    {
      "text": "Kegelapan tidak bisa mengusir kegelapan;\nhanya cahaya yang bisa. Kebencian tidak bisa mengusir kebencian; hanya cinta yang bisa.",
      "author": "Martin Luther King Jr.",
      "tag": "CAHAYA",
    },
    {
      "text": "Kita menghabiskan lebih banyak waktu untuk bermimpi tentang hidup\ndaripada benar-benar menjalaninya.",
      "author": "Paulo Coelho",
      "tag": "HIDUP",
    },
    {
      "text": "Ketika kamu menginginkan sesuatu,\nseluruh alam semesta bersekongkol untuk membantumu mendapatkannya.",
      "author": "Paulo Coelho",
      "tag": "MIMPI",
    },
    {
      "text": "Orang-orang terhebat di dunia adalah mereka\nyang selalu bisa menemukan keceriaan dalam diri sendiri.",
      "author": "Ralph Waldo Emerson",
      "tag": "JIWA",
    },
    {
      "text": "Jangan pergi ke tempat jalan telah ada,\npergilah ke tempat belum ada jalan dan tinggalkan jejak.",
      "author": "Ralph Waldo Emerson",
      "tag": "PIONEER",
    },
    {
      "text": "Hidup yang tidak diuji\ntidak layak untuk dijalani.",
      "author": "Socrates",
      "tag": "FILSAFAT",
    },
    {
      "text": "Kekayaan yang sesungguhnya bukan pada emas,\ntapi pada kemampuan untuk berpuas diri.",
      "author": "Socrates",
      "tag": "FILSAFAT",
    },
    {
      "text": "Kita menderita lebih banyak dalam imajinasi\ndaripada dalam kenyataan.",
      "author": "Seneca",
      "tag": "STOIK",
    },
    {
      "text": "Mulailah di mana kamu berada.\nGunakan apa yang kamu miliki. Lakukan apa yang kamu bisa.",
      "author": "Arthur Ashe",
      "tag": "MULAI",
    },
    {
      "text": "Kesulitan besar datang sebelum kesempatan besar.\nBertahanlah.",
      "author": "Napoleon Hill",
      "tag": "PELUANG",
    },
    {
      "text": "Sakit itu tidak bisa dihindari.\nPenderitaan adalah pilihan.",
      "author": "Haruki Murakami",
      "tag": "RASA SAKIT",
    },
    {
      "text": "Dan sekali badai itu berlalu, kamu tidak akan ingat\nbagaimana kamu melewatinya, atau bagaimana kamu bertahan.",
      "author": "Haruki Murakami",
      "tag": "BADAI",
    },
    {
      "text": "Tidaklah penting seberapa lambat kamu pergi,\nselama kamu tidak berhenti.",
      "author": "Konfusius",
      "tag": "PERJALANAN",
    },
    {
      "text": "Pilih pekerjaan yang kamu cintai,\nmaka kamu tidak akan bekerja sehari pun dalam hidupmu.",
      "author": "Konfusius",
      "tag": "CINTA",
    },
    {
      "text": "Satu-satunya hal yang harus kita takuti\nadalah rasa takut itu sendiri.",
      "author": "Franklin D. Roosevelt",
      "tag": "TAKUT",
    },
    {
      "text": "Kejeniusan adalah satu persen inspirasi\ndan sembilan puluh sembilan persen keringat.",
      "author": "Thomas Edison",
      "tag": "KERJA KERAS",
    },
    {
      "text": "Aku tidak gagal. Aku hanya menemukan\nsepuluh ribu cara yang tidak berhasil.",
      "author": "Thomas Edison",
      "tag": "GAGAL",
    },
    {
      "text": "Hal termewah yang bisa kamu kenakan\nadalah kepercayaan diri.",
      "author": "Coco Chanel",
      "tag": "PERCAYA DIRI",
    },
    {
      "text": "Di dalam setiap kesulitan terdapat benih\ndari manfaat yang setara atau lebih besar.",
      "author": "Napoleon Hill",
      "tag": "HIKMAH",
    },
    {
      "text": "Dunia memberi jalan kepada mereka\nyang tahu ke mana mereka akan pergi.",
      "author": "Ralph Waldo Emerson",
      "tag": "TUJUAN",
    },
    {
      "text": "Jangan pernah membiarkan rasa takut akan kegagalan\nmenghambatmu untuk mencoba hal baru.",
      "author": "Michael Jordan",
      "tag": "TAKUT",
    },
    {
      "text": "Aku sudah gagal berkali-kali dalam hidupku.\nItulah mengapa aku berhasil.",
      "author": "Michael Jordan",
      "tag": "GAGAL",
    },
    {
      "text": "Hal paling berbahaya yang bisa kamu lakukan\nadalah bermain aman.",
      "author": "Nick Offerman",
      "tag": "BERANI",
    },
    {
      "text": "Bukan karena sesuatu itu sulit\nmaka kita tidak berani. Karena kita tidak berani, hal itu menjadi sulit.",
      "author": "Seneca",
      "tag": "STOIK",
    },
    {
      "text": "Pikiran yang tenang mengalahkan semua rintangan.\nDia yang sabar, menang.",
      "author": "Marcus Aurelius",
      "tag": "STOIK",
    },
    {
      "text": "Kamu memiliki kekuatan atas pikiranmu, bukan atas kejadian di luar.\nSadari ini, dan kamu akan menemukan kekuatan.",
      "author": "Marcus Aurelius",
      "tag": "STOIK",
    },
    {
      "text": "Kerugian terbesar dalam hidup\nadalah apa yang bisa kita lakukan tapi tidak pernah kita coba.",
      "author": "Marcus Aurelius",
      "tag": "STOIK",
    },
    {
      "text": "Rahasia untuk maju\nadalah dengan mulai.",
      "author": "Mark Twain",
      "tag": "MULAI",
    },
    {
      "text": "Dua tanggal terpenting dalam hidupmu: hari lahirmu,\ndan hari kamu menemukan alasan keberadaanmu.",
      "author": "Mark Twain",
      "tag": "TUJUAN",
    },
    {
      "text": "Jadilah perubahan yang ingin kamu lihat\ndi dunia ini.",
      "author": "Mahatma Gandhi",
      "tag": "PERUBAHAN",
    },
    {
      "text": "Pertama mereka mengabaikanmu, lalu mereka menertawakanmu,\nlalu mereka melawanmu, lalu kamu menang.",
      "author": "Mahatma Gandhi",
      "tag": "MENANG",
    },
    {
      "text": "Kamu tidak akan pernah menyeberangi lautan\njika kamu takut kehilangan pandangan terhadap pantai.",
      "author": "Christopher Columbus",
      "tag": "BERANI",
    },
    {
      "text": "Seorang pemenang adalah pemimpi\nyang tidak pernah menyerah.",
      "author": "Nelson Mandela",
      "tag": "MIMPI",
    },
    {
      "text": "Terlihat mustahil sampai semuanya\nterbukti mungkin.",
      "author": "Nelson Mandela",
      "tag": "MUNGKIN",
    },
    {
      "text": "Jangan menunggu kesempatan yang sempurna.\nAmbil kesempatan dan buat sempurna.",
      "author": "Zoey Sayward",
      "tag": "KESEMPATAN",
    },
    {
      "text": "Hidup bukan tentang menemukan dirimu.\nHidup adalah tentang menciptakan dirimu.",
      "author": "George Bernard Shaw",
      "tag": "DIRI",
    },
    {
      "text": "Orang yang berpikir mereka bisa\ndan orang yang berpikir mereka tidak bisa — keduanya benar.",
      "author": "Henry Ford",
      "tag": "PIKIRAN",
    },
    {
      "text": "Kegagalan hanya kesempatan\nuntuk memulai lagi dengan lebih cerdas.",
      "author": "Henry Ford",
      "tag": "GAGAL",
    },
    {
      "text": "Di antara stimulus dan respons, ada ruang.\nDi ruang itulah kekuatan dan kebebasanmu berada.",
      "author": "Viktor Frankl",
      "tag": "JIWA",
    },
    {
      "text": "Segalanya bisa direnggut dari manusia\nkecuali satu hal: kebebasan untuk memilih sikapnya.",
      "author": "Viktor Frankl",
      "tag": "KEBEBASAN",
    },
    {
      "text": "Bukan gunung yang kita taklukkan,\nmelainkan diri kita sendiri.",
      "author": "Sir Edmund Hillary",
      "tag": "DIRI",
    },
    {
      "text": "Masa depan milik mereka yang percaya\npada keindahan mimpi-mimpi mereka.",
      "author": "Eleanor Roosevelt",
      "tag": "MIMPI",
    },
    {
      "text": "Tak seorang pun bisa membuatmu merasa rendah\ntanpa persetujuanmu.",
      "author": "Eleanor Roosevelt",
      "tag": "HARGA DIRI",
    },
    {
      "text": "Anda hanya hidup sekali, tapi jika kamu melakukannya dengan benar,\nsekali saja sudah cukup.",
      "author": "Mae West",
      "tag": "HIDUP",
    },
    {
      "text": "Karakter tidak dibentuk dalam ketenangan dan kesenangan.\nJiwa diperkuat hanya melalui cobaan dan penderitaan.",
      "author": "Helen Keller",
      "tag": "KARAKTER",
    },
    {
      "text": "Meskipun dunia penuh penderitaan,\ndunia juga penuh dengan cara mengatasinya.",
      "author": "Helen Keller",
      "tag": "HARAPAN",
    },
    {
      "text": "Orang yang paling bahagia tidak selalu\nmemiliki hal-hal terbaik. Mereka hanya membuat yang terbaik dari apa yang ada.",
      "author": "Anonim",
      "tag": "SYUKUR",
    },
    {
      "text": "Jika kamu terlahir miskin itu bukan salahmu.\nTapi jika kamu mati miskin, itu sudah menjadi salahmu.",
      "author": "Bill Gates",
      "tag": "AMBISI",
    },
    {
      "text": "Kesabaran bukan kemampuan untuk menunggu,\nmelainkan kemampuan untuk tetap baik saat menunggu.",
      "author": "Joyce Meyer",
      "tag": "SABAR",
    },
    {
      "text": "Mereka yang gila cukup untuk berpikir\nbisa mengubah dunia, adalah mereka yang melakukannya.",
      "author": "Steve Jobs",
      "tag": "GILA",
    },
    {
      "text": "Keberhasilan bukan milik orang yang tidak pernah jatuh,\nmelainkan milik mereka yang selalu bangkit setelah jatuh.",
      "author": "Vince Lombardi",
      "tag": "BANGKIT",
    },
    {
      "text": "Percaya pada proses.\nHasil butuh waktu.",
      "author": "Anonim",
      "tag": "PROSES",
    },
    {
      "text": "Luka-lukamu adalah tempat di mana\ncahaya masuk ke dalam dirimu.",
      "author": "Rumi",
      "tag": "LUKA",
    },
    {
      "text": "Kamu dilahirkan bersayap,\nmengapa memilih merangkak seumur hidup?",
      "author": "Rumi",
      "tag": "JIWA",
    },
    {
      "text": "Jangan pernah menyesal atas hari kemarin.\nHidup ada di dalam dirimu hari ini, dan kamu membangun hari esokmu.",
      "author": "L. Ron Hubbard",
      "tag": "WAKTU",
    },
    {
      "text": "Ketika satu pintu tertutup, pintu lain terbuka;\ntapi sering kali kita menatap terlalu lama pada pintu yang tertutup.",
      "author": "Alexander Graham Bell",
      "tag": "PELUANG",
    },
    {
      "text": "Kita tidak bisa memilih angin,\nnamun kita bisa mengatur layar.",
      "author": "Aristoteles",
      "tag": "FILSAFAT",
    },
    {
      "text": "Kita adalah apa yang kita lakukan berulang kali.\nKeunggulan, dengan demikian, adalah kebiasaan, bukan tindakan.",
      "author": "Aristoteles",
      "tag": "FILSAFAT",
    },
    {
      "text": "Bukan tentang seberapa keras kamu memukul.\nIni tentang seberapa keras kamu bisa dipukul dan terus melangkah.",
      "author": "Rocky Balboa",
      "tag": "TANGGUH",
    },
  ];

  int _currentIndex = 0;
  bool _isMusicPlaying = true;

  // Animasi
  late AnimationController _slideCtrl;
  late AnimationController _pulseCtrl;
  late AnimationController _breathCtrl;
  late AnimationController _glowCtrl;
  late AnimationController _scanCtrl;
  late AnimationController _particleCtrl;

  late Animation<double> _fadeAnim;
  late Animation<Offset> _slideAnim;
  late Animation<double> _pulseAnim;
  late Animation<double> _breathAnim;
  late Animation<double> _glowAnim;
  late Animation<double> _scanAnim;
  late Animation<double> _particleAnim;

  // Particle positions (dekorasi)
  late List<_Particle> _particles;

  @override
  void initState() {
    super.initState();
    _currentIndex = _random.nextInt(_quotes.length);

    _particles = List.generate(18, (_) => _Particle(_random));

    // Quote slide-in
    _slideCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _fadeAnim = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _slideCtrl, curve: const Interval(0.0, 0.7, curve: Curves.easeOut)),
    );
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 0.14),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOutCubic));

    // Red dot pulse
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat(reverse: true);
    _pulseAnim = Tween<double>(begin: 0.3, end: 1.0).animate(
      CurvedAnimation(parent: _pulseCtrl, curve: Curves.easeInOut),
    );

    // Tap hint breathing
    _breathCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _breathAnim = Tween<double>(begin: 0.2, end: 0.7).animate(
      CurvedAnimation(parent: _breathCtrl, curve: Curves.easeInOut),
    );

    // Ambient glow
    _glowCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 3000),
    )..repeat(reverse: true);
    _glowAnim = Tween<double>(begin: 0.04, end: 0.14).animate(
      CurvedAnimation(parent: _glowCtrl, curve: Curves.easeInOut),
    );

    // Scanline sweep
    _scanCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 5),
    )..repeat();
    _scanAnim = Tween<double>(begin: -0.1, end: 1.1).animate(
      CurvedAnimation(parent: _scanCtrl, curve: Curves.linear),
    );

    // Particle drift
    _particleCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 8),
    )..repeat();
    _particleAnim = Tween<double>(begin: 0.0, end: 1.0).animate(_particleCtrl);

    _initAudio();
  }

  Future<void> _initAudio() async {
    try {
      await _audioPlayer.play(AssetSource('audio/blue_yungkai.mp3'));
      _audioPlayer.onPlayerComplete.listen((_) {
        if (_isMusicPlaying && mounted) {
          _audioPlayer.play(AssetSource('audio/blue_yungkai.mp3'));
        }
      });
    } catch (_) {}
  }

  void _nextQuote() {
    HapticFeedback.lightImpact();
    int next;
    do {
      next = _random.nextInt(_quotes.length);
    } while (next == _currentIndex && _quotes.length > 1);
    setState(() => _currentIndex = next);
    _slideCtrl.reset();
    _slideCtrl.forward();
  }

  void _toggleMusic() async {
    HapticFeedback.selectionClick();
    if (_isMusicPlaying) {
      await _audioPlayer.pause();
    } else {
      await _audioPlayer.resume();
    }
    if (mounted) setState(() => _isMusicPlaying = !_isMusicPlaying);
  }

  @override
  void dispose() {
    _slideCtrl.dispose();
    _pulseCtrl.dispose();
    _breathCtrl.dispose();
    _glowCtrl.dispose();
    _scanCtrl.dispose();
    _particleCtrl.dispose();
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = _quotes[_currentIndex];
    final hasAuthor = (q['author'] ?? '').isNotEmpty;

    return Container(
      color: _bg,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // ── Scanline sweep ───────────────────────────
          AnimatedBuilder(
            animation: _scanAnim,
            builder: (_, __) {
              return CustomPaint(
                painter: _ScanlinePainter(_scanAnim.value, _red),
              );
            },
          ),

          // ── Ambient radial glow ──────────────────────
          AnimatedBuilder(
            animation: _glowAnim,
            builder: (_, __) => Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, 0.1),
                  radius: 0.9,
                  colors: [
                    _red.withValues(alpha: _glowAnim.value),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
          ),

          // ── Floating particles ───────────────────────
          AnimatedBuilder(
            animation: _particleAnim,
            builder: (_, __) => CustomPaint(
              painter: _ParticlePainter(_particles, _particleAnim.value, _red),
            ),
          ),

          // ── Grid overlay (subtle) ────────────────────
          Opacity(
            opacity: 0.03,
            child: CustomPaint(
              painter: _GridPainter(_muted),
            ),
          ),

          // ── Tap area ─────────────────────────────────
          GestureDetector(
            behavior: HitTestBehavior.opaque,
            onTap: _nextQuote,
            child: Column(
              children: [
                const Spacer(flex: 2),

                // ── Tag ──────────────────────────────
                AnimatedBuilder(
                  animation: _fadeAnim,
                  builder: (_, child) => Opacity(
                    opacity: _fadeAnim.value,
                    child: child,
                  ),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 5),
                    decoration: BoxDecoration(
                      color: _redLow,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          color: _red.withValues(alpha: 0.3), width: 1),
                    ),
                    child: Text(
                      q['tag'] ?? '',
                      style: const TextStyle(
                        color: _red,
                        fontFamily: 'Orbitron',
                        fontWeight: FontWeight.w900,
                        fontSize: 9,
                        letterSpacing: 2.5,
                      ),
                    ),
                  ),
                ),

                const SizedBox(height: 28),
                _RedLine(),
                const SizedBox(height: 36),

                // ── Quote ────────────────────────────
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 28),
                  child: AnimatedBuilder(
                    animation: _slideCtrl,
                    builder: (_, child) => FadeTransition(
                      opacity: _fadeAnim,
                      child: SlideTransition(
                        position: _slideAnim,
                        child: child,
                      ),
                    ),
                    child: Column(
                      children: [
                        // Opening quote mark
                        Text(
                          '\u201C',
                          style: TextStyle(
                            fontSize: 52,
                            fontWeight: FontWeight.w900,
                            color: _red.withValues(alpha: 0.18),
                            height: 0.6,
                            fontFamily: 'Georgia',
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          q['text'] ?? '',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                            fontSize: 21,
                            fontWeight: FontWeight.w300,
                            fontStyle: FontStyle.italic,
                            color: _white,
                            height: 1.75,
                            letterSpacing: 0.3,
                            shadows: [
                              Shadow(
                                color: Color(0x55FF0040),
                                blurRadius: 30,
                                offset: Offset(0, 6),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                const SizedBox(height: 36),
                _RedLine(),
                const SizedBox(height: 20),

                // ── Author ───────────────────────────
                AnimatedBuilder(
                  animation: _fadeAnim,
                  builder: (_, child) => Opacity(
                    opacity: _fadeAnim.value,
                    child: child,
                  ),
                  child: hasAuthor
                      ? Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Container(
                              width: 16,
                              height: 1,
                              color: _red.withValues(alpha: 0.5),
                            ),
                            const SizedBox(width: 8),
                            Text(
                              q['author']!,
                              style: TextStyle(
                                color: _red.withValues(alpha: 0.8),
                                fontFamily: 'ShareTechMono',
                                fontSize: 10,
                                letterSpacing: 2.0,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                            const SizedBox(width: 8),
                            Container(
                              width: 16,
                              height: 1,
                              color: _red.withValues(alpha: 0.5),
                            ),
                          ],
                        )
                      : const SizedBox(height: 14),
                ),

                const SizedBox(height: 16),

                // ── Counter ──────────────────────────
                AnimatedBuilder(
                  animation: _fadeAnim,
                  builder: (_, child) => Opacity(
                    opacity: _fadeAnim.value * 0.4,
                    child: child,
                  ),
                  child: Text(
                    "${_currentIndex + 1} / ${_quotes.length}",
                    style: const TextStyle(
                      color: _muted,
                      fontFamily: 'ShareTechMono',
                      fontSize: 10,
                      letterSpacing: 1.5,
                    ),
                  ),
                ),

                const Spacer(flex: 2),

                // ── Tap hint ─────────────────────────
                AnimatedBuilder(
                  animation: _breathAnim,
                  builder: (_, __) => Opacity(
                    opacity: _breathAnim.value,
                    child: Column(
                      children: [
                        Icon(Icons.touch_app_rounded,
                            color: _muted, size: 16),
                        const SizedBox(height: 6),
                        Text(
                          "TAP UNTUK LANJUT",
                          style: const TextStyle(
                            color: _muted,
                            fontFamily: 'ShareTechMono',
                            fontSize: 9,
                            letterSpacing: 2.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
              ],
            ),
          ),

          // ── Music toggle ─────────────────────────────
          Positioned(
            top: 12,
            right: 12,
            child: GestureDetector(
              onTap: _toggleMusic,
              child: AnimatedBuilder(
                animation: _pulseAnim,
                builder: (_, child) => Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: _dim,
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: _isMusicPlaying
                          ? _red.withValues(alpha: _pulseAnim.value * 0.5)
                          : _muted.withValues(alpha: 0.2),
                      width: 1.5,
                    ),
                    boxShadow: _isMusicPlaying
                        ? [
                            BoxShadow(
                              color: _red.withValues(
                                  alpha: _pulseAnim.value * 0.2),
                              blurRadius: 16,
                            )
                          ]
                        : [],
                  ),
                  child: Icon(
                    _isMusicPlaying
                        ? Icons.music_note_rounded
                        : Icons.music_off_rounded,
                    color: _isMusicPlaying ? _red : _muted,
                    size: 18,
                  ),
                ),
              ),
            ),
          ),

          // ── Red dot pulse (top left) ──────────────────
          Positioned(
            top: 22,
            left: 20,
            child: AnimatedBuilder(
              animation: _pulseAnim,
              builder: (_, __) => Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  color: _red,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: _red.withValues(alpha: _pulseAnim.value * 0.7),
                      blurRadius: 10,
                      spreadRadius: 2,
                    ),
                  ],
                ),
              ),
            ),
          ),

          // ── Corner accents ────────────────────────────
          Positioned(
            top: 8, left: 8,
            child: _CornerAccent(isTop: true, isLeft: true),
          ),
          Positioned(
            top: 8, right: 8,
            child: _CornerAccent(isTop: true, isLeft: false),
          ),
          Positioned(
            bottom: 8, left: 8,
            child: _CornerAccent(isTop: false, isLeft: true),
          ),
          Positioned(
            bottom: 8, right: 8,
            child: _CornerAccent(isTop: false, isLeft: false),
          ),
        ],
      ),
    );
  }
}

// ── Corner accent ─────────────────────────────────────────────
class _CornerAccent extends StatelessWidget {
  final bool isTop;
  final bool isLeft;
  const _CornerAccent({required this.isTop, required this.isLeft});

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      size: const Size(20, 20),
      painter: _CornerPainter(
        isTop: isTop,
        isLeft: isLeft,
        color: const Color(0xFFFF0040).withValues(alpha: 0.25),
      ),
    );
  }
}

class _CornerPainter extends CustomPainter {
  final bool isTop;
  final bool isLeft;
  final Color color;
  _CornerPainter({required this.isTop, required this.isLeft, required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final double x = isLeft ? 0 : size.width;
    final double y = isTop ? 0 : size.height;
    final double dx = isLeft ? size.width * 0.5 : -size.width * 0.5;
    final double dy = isTop ? size.height * 0.5 : -size.height * 0.5;

    canvas.drawLine(Offset(x, y), Offset(x + dx, y), paint);
    canvas.drawLine(Offset(x, y), Offset(x, y + dy), paint);
  }

  @override
  bool shouldRepaint(_CornerPainter old) => false;
}

// ── Red line divider ──────────────────────────────────────────
class _RedLine extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 48,
      height: 1,
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            const Color(0xFFFF0040).withValues(alpha: 0.0),
            const Color(0xFFFF0040).withValues(alpha: 0.9),
            const Color(0xFFFF0040).withValues(alpha: 0.0),
          ],
        ),
      ),
    );
  }
}

// ── Scanline painter ──────────────────────────────────────────
class _ScanlinePainter extends CustomPainter {
  final double progress;
  final Color color;
  _ScanlinePainter(this.progress, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final y = size.height * progress;
    final paint = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [
          color.withValues(alpha: 0.0),
          color.withValues(alpha: 0.04),
          color.withValues(alpha: 0.0),
        ],
        stops: const [0.0, 0.5, 1.0],
      ).createShader(Rect.fromLTWH(0, y - 60, size.width, 120));

    canvas.drawRect(
      Rect.fromLTWH(0, y - 60, size.width, 120),
      paint,
    );
  }

  @override
  bool shouldRepaint(_ScanlinePainter old) => old.progress != progress;
}

// ── Grid painter ──────────────────────────────────────────────
class _GridPainter extends CustomPainter {
  final Color color;
  _GridPainter(this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = color
      ..strokeWidth = 0.5;

    const spacing = 40.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }
  }

  @override
  bool shouldRepaint(_GridPainter old) => false;
}

// ── Particle data ─────────────────────────────────────────────
class _Particle {
  final double x;
  final double baseY;
  final double size;
  final double speed;
  final double opacity;

  _Particle(Random r)
      : x = r.nextDouble(),
        baseY = r.nextDouble(),
        size = r.nextDouble() * 2.0 + 0.5,
        speed = r.nextDouble() * 0.3 + 0.05,
        opacity = r.nextDouble() * 0.3 + 0.05;
}

class _ParticlePainter extends CustomPainter {
  final List<_Particle> particles;
  final double t;
  final Color color;
  _ParticlePainter(this.particles, this.t, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    for (final p in particles) {
      final y = (p.baseY - p.speed * t) % 1.0;
      final paint = Paint()
        ..color = color.withValues(alpha: p.opacity * (1 - (y - 0.5).abs() * 2).clamp(0, 1))
        ..style = PaintingStyle.fill;
      canvas.drawCircle(
        Offset(p.x * size.width, y * size.height),
        p.size,
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_ParticlePainter old) => old.t != t;
}