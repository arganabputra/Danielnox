import 'dart:ui';
import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'anime.dart';
import 'hentai_page.dart' as hentai;

// ─────────────────────────────────────────────
//  ToolsPage  —  Tactical Dark UI  v3.0
// ─────────────────────────────────────────────
class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  // ── Palette ──────────────────────────────────
  static const Color _bg      = Color(0xFF040B14);
  static const Color _surface = Color(0xFF081420);
  static const Color _card    = Color(0xFF0D1B2A);
  static const Color _line    = Color(0xFF13283C);
  static const Color _red     = Color(0xFFFF0040);
  static const Color _redDim  = Color(0xFF6B0020);
  static const Color _white   = Color(0xFFFFFFFF);
  static const Color _muted   = Color(0xFF4D7C9E);
  static const Color _subtle  = Color(0xFF1C3A52);

  late final AnimationController _pulseCtrl;
  late final AnimationController _slideCtrl;
  late final Animation<double> _slideAnim;

  // Track which categories are expanded
  final Map<int, bool> _expanded = {};

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _slideCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..forward();

    _slideAnim = CurvedAnimation(
      parent: _slideCtrl,
      curve: Curves.easeOutCubic,
    );
  }

  @override
  void dispose() {
    _pulseCtrl.dispose();
    _slideCtrl.dispose();
    super.dispose();
  }

  // ── Categories data ───────────────────────────
  List<_Category> get _categories => [
    _Category(
      id: 0,
      icon: Icons.bolt_rounded,
      label: "DDOS",
      sublabel: "Attack & Server",
      accentColor: _red,
      items: [
        _ToolEntry(
          icon: Icons.bolt_rounded,
          label: "Attack Panel",
          tag: _Tag.live,
          onTap: () => Navigator.push(context, _route(
            AttackPanel(sessionKey: widget.sessionKey, listDoos: widget.listDoos),
          )),
        ),
        _ToolEntry(
          icon: Icons.dns_rounded,
          label: "Manage Server",
          onTap: () => Navigator.push(context, _route(
            ManageServerPage(keyToken: widget.sessionKey),
          )),
        ),
      ],
    ),
    _Category(
      id: 1,
      icon: Icons.wifi_rounded,
      label: "NETWORK",
      sublabel: "WiFi & Spam",
      accentColor: _red,
      items: [
        _ToolEntry(
          icon: Icons.mark_email_unread_rounded,
          label: "Spam NGL",
          tag: _Tag.newTag,
          onTap: () => Navigator.push(context, _route(NglPage())),
        ),
        _ToolEntry(
          icon: Icons.wifi_off_rounded,
          label: "WiFi Killer (Internal)",
          onTap: () => Navigator.push(context, _route(WifiKillerPage())),
        ),
        if (widget.userRole == "vip" || widget.userRole == "owner")
          _ToolEntry(
            icon: Icons.router_rounded,
            label: "WiFi Killer (External)",
            tag: _Tag.vip,
            onTap: () => Navigator.push(context, _route(
              WifiInternalPage(sessionKey: widget.sessionKey),
            )),
          ),
      ],
    ),
    _Category(
      id: 2,
      icon: Icons.manage_search_rounded,
      label: "OSINT",
      sublabel: "Investigation",
      accentColor: _red,
      items: [
        _ToolEntry(
          icon: Icons.badge_rounded,
          label: "NIK Detail",
          onTap: () => Navigator.push(context, _route(const NikCheckerPage())),
        ),
        _ToolEntry(
          icon: Icons.language_rounded,
          label: "Domain OSINT",
          onTap: () => Navigator.push(context, _route(const DomainOsintPage())),
        ),
        _ToolEntry(
          icon: Icons.person_search_rounded,
          label: "Phone Lookup",
          locked: true,
          onTap: () => _showComingSoon(),
        ),
        _ToolEntry(
          icon: Icons.alternate_email_rounded,
          label: "Email OSINT",
          locked: true,
          onTap: () => _showComingSoon(),
        ),
      ],
    ),
    _Category(
      id: 3,
      icon: Icons.download_rounded,
      label: "DOWNLOADER",
      sublabel: "Social Media",
      accentColor: _red,
      items: [
        _ToolEntry(
          icon: Icons.music_video_rounded,
          label: "TikTok Downloader",
          onTap: () => Navigator.push(context, _route(const TiktokDownloaderPage())),
        ),
        _ToolEntry(
          icon: Icons.photo_camera_back_rounded,
          label: "Instagram Downloader",
          onTap: () => Navigator.push(context, _route(const InstagramDownloaderPage())),
        ),
      ],
    ),
    _Category(
      id: 4,
      icon: Icons.construction_rounded,
      label: "UTILITIES",
      sublabel: "Extra Tools",
      accentColor: _red,
      items: [
        _ToolEntry(
          icon: Icons.qr_code_2_rounded,
          label: "QR Generator",
          onTap: () => Navigator.push(context, _route(const QrGeneratorPage())),
        ),
        _ToolEntry(
          icon: Icons.radar_rounded,
          label: "IP Scanner",
          locked: true,
          onTap: () => _showComingSoon(),
        ),
        _ToolEntry(
          icon: Icons.network_check_rounded,
          label: "Port Scanner",
          locked: true,
          onTap: () => _showComingSoon(),
        ),
      ],
    ),
    _Category(
      id: 5,
      icon: Icons.play_circle_rounded,
      label: "WATCH",
      sublabel: "Entertainment",
      accentColor: _red,
      items: [
        _ToolEntry(
          icon: Icons.live_tv_rounded,
          label: "Anime Streaming",
          onTap: () => Navigator.push(context, _route(const HomeAnimePage())),
        ),
        _ToolEntry(
          icon: Icons.local_fire_department_rounded,
          label: "Hentai Media",
          tag: _Tag.adult,
          onTap: () => Navigator.push(context, _route(const hentai.HomeScreen())),
        ),
      ],
    ),
  ];

  PageRoute _route(Widget page) => PageRouteBuilder(
    pageBuilder: (_, a, __) => page,
    transitionsBuilder: (_, a, __, child) {
      return FadeTransition(
        opacity: CurvedAnimation(parent: a, curve: Curves.easeOut),
        child: SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(0.04, 0),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
          child: child,
        ),
      );
    },
    transitionDuration: const Duration(milliseconds: 280),
  );

  // ── Build ─────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: _bg,
        body: Stack(
          children: [
            // Ambient glow background
            Positioned(
              top: -120,
              right: -80,
              child: AnimatedBuilder(
                animation: _pulseCtrl,
                builder: (_, __) => Opacity(
                  opacity: 0.06 + _pulseCtrl.value * 0.04,
                  child: Container(
                    width: 320,
                    height: 320,
                    decoration: const BoxDecoration(
                      shape: BoxShape.circle,
                      color: _red,
                    ),
                  ),
                ),
              ),
            ),

            SafeArea(
              child: FadeTransition(
                opacity: _slideAnim,
                child: SlideTransition(
                  position: Tween<Offset>(
                    begin: const Offset(0, 0.03),
                    end: Offset.zero,
                  ).animate(_slideAnim),
                  child: CustomScrollView(
                    physics: const BouncingScrollPhysics(),
                    slivers: [
                      // ── Top padding
                      const SliverToBoxAdapter(child: SizedBox(height: 20)),

                      // ── Header
                      SliverToBoxAdapter(child: _buildHeader()),
                      const SliverToBoxAdapter(child: SizedBox(height: 20)),

                      // ── Stats Row
                      SliverToBoxAdapter(child: _buildStatsRow()),
                      const SliverToBoxAdapter(child: SizedBox(height: 28)),

                      // ── Section label
                      SliverToBoxAdapter(child: _buildSectionLabel()),
                      const SliverToBoxAdapter(child: SizedBox(height: 12)),

                      // ── Categories
                      SliverPadding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        sliver: SliverList(
                          delegate: SliverChildBuilderDelegate(
                            (context, i) {
                              final cat = _categories[i];
                              return Padding(
                                padding: const EdgeInsets.only(bottom: 8),
                                child: _buildCategoryCard(cat),
                              );
                            },
                            childCount: _categories.length,
                          ),
                        ),
                      ),

                      // ── Footer
                      SliverToBoxAdapter(child: _buildFooter()),
                      const SliverToBoxAdapter(child: SizedBox(height: 32)),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Header ───────────────────────────────────
  Widget _buildHeader() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: _card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _line),
        ),
        child: Row(
          children: [
            // Icon stack with pulse ring
            AnimatedBuilder(
              animation: _pulseCtrl,
              builder: (_, __) => SizedBox(
                width: 52,
                height: 52,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    // Outer pulse ring
                    Container(
                      width: 52,
                      height: 52,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: _red.withOpacity(0.1 + _pulseCtrl.value * 0.15),
                          width: 1,
                        ),
                      ),
                    ),
                    // Inner icon box
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: _red.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: _red.withOpacity(0.25)),
                      ),
                      child: const Icon(
                        Icons.shield_rounded,
                        color: _red,
                        size: 22,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "TOOLS",
                    style: TextStyle(
                      color: _red,
                      fontSize: 22,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w900,
                      letterSpacing: 4,
                      height: 1,
                    ),
                  ),
                  const SizedBox(height: 5),
                  Text(
                    "Security & OSINT Suite",
                    style: TextStyle(
                      color: _muted,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                      letterSpacing: 1,
                    ),
                  ),
                ],
              ),
            ),
            // Role pill
            _RolePill(role: widget.userRole, red: _red),
          ],
        ),
      ),
    );
  }

  // ── Stats Row ────────────────────────────────
  Widget _buildStatsRow() {
    final stats = [
      _StatItem(value: "${widget.listDoos.length}", label: "METHODS", icon: Icons.bolt_rounded),
      _StatItem(value: "${_categories.length}", label: "MODULES", icon: Icons.grid_view_rounded),
      _StatItem(value: widget.userRole.toUpperCase(), label: "ACCESS", icon: Icons.verified_user_rounded),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: stats.map((s) => Expanded(
          child: Padding(
            padding: EdgeInsets.only(
              right: s == stats.last ? 0 : 8,
            ),
            child: _buildStatCard(s),
          ),
        )).toList(),
      ),
    );
  }

  Widget _buildStatCard(_StatItem stat) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 10),
      decoration: BoxDecoration(
        color: _surface,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: _line),
      ),
      child: Column(
        children: [
          Icon(stat.icon, color: _red.withOpacity(0.6), size: 16),
          const SizedBox(height: 6),
          Text(
            stat.value,
            style: const TextStyle(
              color: _red,
              fontSize: 14,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            stat.label,
            style: TextStyle(
              color: _muted,
              fontSize: 8,
              fontFamily: 'ShareTechMono',
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }

  // ── Section label ────────────────────────────
  Widget _buildSectionLabel() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          Container(
            width: 3,
            height: 14,
            decoration: BoxDecoration(
              color: _red,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(width: 10),
          Text(
            "ALL MODULES",
            style: TextStyle(
              color: _muted,
              fontSize: 10,
              fontFamily: 'ShareTechMono',
              letterSpacing: 2,
            ),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_line, Colors.transparent],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ── Category Card ────────────────────────────
  Widget _buildCategoryCard(_Category cat) {
    final isOpen = _expanded[cat.id] ?? false;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeOutCubic,
      decoration: BoxDecoration(
        color: _card,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isOpen ? _red.withOpacity(0.25) : _line,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: Column(
          children: [
            // ── Header row
            _buildCategoryHeader(cat, isOpen),

            // ── Items (animated expand)
            AnimatedSize(
              duration: const Duration(milliseconds: 280),
              curve: Curves.easeOutCubic,
              child: isOpen
                  ? Padding(
                      padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
                      child: Column(
                        children: cat.items
                            .map((item) => _buildToolRow(item))
                            .toList(),
                      ),
                    )
                  : const SizedBox.shrink(),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCategoryHeader(_Category cat, bool isOpen) {
    return InkWell(
      onTap: () {
        HapticFeedback.selectionClick();
        setState(() => _expanded[cat.id] = !isOpen);
      },
      borderRadius: BorderRadius.circular(16),
      splashColor: _red.withOpacity(0.05),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            // Category icon
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: isOpen
                    ? _red.withOpacity(0.12)
                    : _subtle,
                borderRadius: BorderRadius.circular(11),
                border: Border.all(
                  color: isOpen
                      ? _red.withOpacity(0.25)
                      : _line,
                ),
              ),
              child: Icon(
                cat.icon,
                color: isOpen ? _red : _muted,
                size: 20,
              ),
            ),
            const SizedBox(width: 14),

            // Labels
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    cat.label,
                    style: TextStyle(
                      color: isOpen ? _red : _white,
                      fontSize: 13,
                      fontFamily: 'Orbitron',
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    cat.sublabel,
                    style: TextStyle(
                      color: _muted,
                      fontSize: 11,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ],
              ),
            ),

            // Item count chip
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: _subtle,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                "${cat.items.length}",
                style: TextStyle(
                  color: _muted,
                  fontSize: 11,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
            const SizedBox(width: 8),

            // Chevron
            AnimatedRotation(
              turns: isOpen ? 0.5 : 0,
              duration: const Duration(milliseconds: 250),
              curve: Curves.easeOutCubic,
              child: Icon(
                Icons.keyboard_arrow_down_rounded,
                color: isOpen ? _red : _muted,
                size: 20,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Tool Row ─────────────────────────────────
  Widget _buildToolRow(_ToolEntry item) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            HapticFeedback.lightImpact();
            item.onTap();
          },
          borderRadius: BorderRadius.circular(12),
          splashColor: _red.withOpacity(0.08),
          highlightColor: _red.withOpacity(0.04),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
            decoration: BoxDecoration(
              color: _surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _line),
            ),
            child: Row(
              children: [
                // Icon
                Container(
                  width: 34,
                  height: 34,
                  decoration: BoxDecoration(
                    color: item.locked
                        ? _subtle
                        : _red.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(9),
                    border: Border.all(
                      color: item.locked
                          ? _line
                          : _red.withOpacity(0.15),
                    ),
                  ),
                  child: Icon(
                    item.icon,
                    color: item.locked ? _muted.withOpacity(0.4) : _red.withOpacity(0.85),
                    size: 17,
                  ),
                ),
                const SizedBox(width: 12),

                // Label
                Expanded(
                  child: Text(
                    item.label,
                    style: TextStyle(
                      color: item.locked
                          ? _muted.withOpacity(0.5)
                          : _white.withOpacity(0.88),
                      fontSize: 13,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.2,
                    ),
                  ),
                ),

                // Tag
                if (item.tag != null) ...[
                  _buildTag(item.tag!),
                  const SizedBox(width: 8),
                ],

                // Arrow / lock
                item.locked
                    ? Icon(Icons.lock_rounded, color: _subtle, size: 14)
                    : Icon(Icons.chevron_right_rounded, color: _muted.withOpacity(0.5), size: 18),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Tag ──────────────────────────────────────
  Widget _buildTag(_Tag tag) {
    late Color bg;
    late Color fg;
    late String text;

    switch (tag) {
      case _Tag.live:
        bg = Colors.red.withOpacity(0.12);
        fg = const Color(0xFFFF4444);
        text = "LIVE";
        break;
      case _Tag.newTag:
        bg = _red.withOpacity(0.12);
        fg = _red;
        text = "NEW";
        break;
      case _Tag.vip:
        bg = Colors.amber.withOpacity(0.10);
        fg = Colors.amber;
        text = "VIP";
        break;
      case _Tag.adult:
        bg = Colors.pink.withOpacity(0.10);
        fg = Colors.pinkAccent;
        text = "18+";
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: fg.withOpacity(0.2)),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: fg,
          fontSize: 8,
          fontFamily: 'Orbitron',
          fontWeight: FontWeight.w900,
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // ── Footer ───────────────────────────────────
  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 24),
      child: Column(
        children: [
          Container(height: 1, color: _line),
          const SizedBox(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.info_outline_rounded, color: _muted.withOpacity(0.4), size: 12),
              const SizedBox(width: 6),
              Text(
                "v3.0 · FOR EDUCATIONAL USE ONLY",
                style: TextStyle(
                  color: _muted.withOpacity(0.4),
                  fontSize: 9,
                  fontFamily: 'ShareTechMono',
                  letterSpacing: 1.5,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Coming Soon Dialog ───────────────────────
  void _showComingSoon() {
    HapticFeedback.mediumImpact();
    showDialog(
      context: context,
      barrierColor: _line.withOpacity(0.75),
      builder: (_) => _ComingSoonDialog(red: _red, card: _card, muted: _muted),
    );
  }
}

// ─────────────────────────────────────────────
//  Helpers / Sub-widgets
// ─────────────────────────────────────────────

enum _Tag { live, newTag, vip, adult }

class _Category {
  final int id;
  final IconData icon;
  final String label;
  final String sublabel;
  final Color accentColor;
  final List<_ToolEntry> items;

  const _Category({
    required this.id,
    required this.icon,
    required this.label,
    required this.sublabel,
    required this.accentColor,
    required this.items,
  });
}

class _ToolEntry {
  final IconData icon;
  final String label;
  final _Tag? tag;
  final bool locked;
  final VoidCallback onTap;

  const _ToolEntry({
    required this.icon,
    required this.label,
    this.tag,
    this.locked = false,
    required this.onTap,
  });
}

class _StatItem {
  final String value;
  final String label;
  final IconData icon;
  const _StatItem({required this.value, required this.label, required this.icon});
}

// ── Role Pill ────────────────────────────────
class _RolePill extends StatelessWidget {
  final String role;
  final Color red;
  const _RolePill({required this.role, required this.red});

  @override
  Widget build(BuildContext context) {
    final isOwner = role.toLowerCase() == "owner";
    final isVip   = role.toLowerCase() == "vip";

    Color bg   = red.withOpacity(0.10);
    Color fg   = red;
    Color border = red.withOpacity(0.25);

    if (isOwner) {
      bg = Colors.amber.withOpacity(0.10);
      fg = Colors.amber;
      border = Colors.amber.withOpacity(0.25);
    } else if (isVip) {
      bg = Colors.purple.withOpacity(0.10);
      fg = const Color(0xFFBF7FFF);
      border = Colors.purple.withOpacity(0.25);
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: border),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(
            isOwner
                ? Icons.military_tech_rounded
                : isVip
                    ? Icons.star_rounded
                    : Icons.person_rounded,
            color: fg,
            size: 12,
          ),
          const SizedBox(width: 5),
          Text(
            role.toUpperCase(),
            style: TextStyle(
              color: fg,
              fontSize: 10,
              fontFamily: 'Orbitron',
              fontWeight: FontWeight.w700,
              letterSpacing: 1,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Coming Soon Dialog ───────────────────────
class _ComingSoonDialog extends StatelessWidget {
  final Color red;
  final Color card;
  final Color muted;
  const _ComingSoonDialog({
    required this.red,
    required this.card,
    required this.muted,
  });

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: card,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: red.withOpacity(0.2)),
          boxShadow: [
            BoxShadow(
              color: red.withOpacity(0.08),
              blurRadius: 40,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: red.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: red.withOpacity(0.2)),
                  ),
                  child: Icon(Icons.lock_clock_rounded, color: red, size: 18),
                ),
                const SizedBox(width: 14),
                Text(
                  "COMING SOON",
                  style: TextStyle(
                    color: red,
                    fontFamily: 'Orbitron',
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              width: double.infinity,
              height: 1,
              color: const Color(0xFF13283C),
            ),
            const SizedBox(height: 16),
            Text(
              "Fitur ini masih dalam pengembangan.\nNantikan update selanjutnya.",
              style: TextStyle(
                color: muted,
                fontSize: 13,
                height: 1.6,
                fontFamily: 'ShareTechMono',
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: TextButton(
                style: TextButton.styleFrom(
                  backgroundColor: red.withOpacity(0.10),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: BorderSide(color: red.withOpacity(0.2)),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: 13),
                ),
                onPressed: () => Navigator.pop(context),
                child: Text(
                  "OK",
                  style: TextStyle(
                    color: red,
                    fontFamily: 'Orbitron',
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
